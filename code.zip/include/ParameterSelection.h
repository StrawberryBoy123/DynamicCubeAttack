#pragma once
#include "Poly.h"
#include <bitset>
#include <map>
#include <cstdint>
#include <iomanip>
#include <random>
#include <iterator>
#include <omp.h>
#include <thread>
#include <condition_variable>
#include <atomic>
#include <unistd.h>


#ifndef PARAMETERSELECTION_H_
#define PARAMETERSELECTION_H_


typedef bitset< 96> IvGterm;
typedef bitset<128> Keyterm;
typedef set<int > BTerm;



// ------------------------------------------------------------------------------------------------------
namespace SecParaG{
    extern int REDUCEROUND;
    extern int MODIVLEN;
    extern int ACTKEYLEN;
    extern int ACTIVLEN;
    extern int MODELVARLEN;
    extern int WrongLocation;
    extern bool DyVarShiftFlag;
    extern Arr1Int WrongIV;
    extern Arr3Int NewIVANFs;
    extern Arr3Int XKEYs;
    extern Arr1Int IVCOUNT;
    extern Arr2Int IVCOUNTs;
    extern Arr3Int ANFS;
    extern Arr1Int VARCOUNT;
    extern Arr3Int VTOK;
    extern Arr3Int CONDITIONS;
    extern Arr4Int MODELXV;
    extern Arr4Int NewIVANFsARR;
    extern vector<string> STRPOLY;
    extern vector<vector<string>> STRPOLYARR;

    void ParameterClear();
    void ParameterSelection(IvGterm Cube = 0, int LOOP = 1, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, int worryiv = 0, string ofile1 = "ModelRequired.txt", string ofile2 = "NewState(Grain128AEAD).txt", bool AEAD_FLAG = true);
    void ParameterGenerator(IvGterm Cube, Arr3Int& xS, Arr4Int& xIv, int LOOP = 1, bool outputflag = false, string file = "NewState(Grain128AEAD).txt", bool AEAD_FLAG = true);
    void ParameterGenerator(IvGterm Cube, IvGterm DCube, Arr3Int& xS, Arr4Int& xIv, int LOOP = 1, bool guassflag = true, int guassloc = 0, bool outputflag = false, string file = "NewState(Grain128AEAD).txt", bool AEAD_FLAG = true);
    void xGrain128AEAD_32R(IvGterm Cube, xPoly* s, xPoly* b, xPoly* g, xPoly* f, xPoly* z, int Round, string file, bool initflag = false, int BlockSize = 32);
    void xGrain128_32R(IvGterm Cube, xPoly* s, xPoly* b, xPoly* g, xPoly* f, xPoly* z, int Round, string file, bool initflag = false, int BlockSize = 32);
  

    class MGTerm {
    private:
        BTerm Bterm;

    public:
        bool operator<(const MGTerm& t2) const {
            if (Bterm.size() < t2.Bterm.size())
                return true;
            if (Bterm.size() > t2.Bterm.size())
                return false;

            BTerm::iterator pt1 = Bterm.begin();
            BTerm::iterator pt2 = t2.Bterm.begin();

            while( (pt1 != Bterm.end()) && (pt2 != t2.Bterm.end()) ){
                if (*pt1 < *pt2)
                    return true;
                else if (*pt1 > *pt2)
                    return false; 
                pt1++; pt2++;
            }
            return false;
        }

        bool operator==(const MGTerm& t2) const {
            if (Bterm.size() != t2.Bterm.size())
                return false;

            BTerm::iterator pt1 = Bterm.begin();
            BTerm::iterator pt2 = t2.Bterm.begin();

            while( (pt1 != Bterm.end()) && (pt2 != t2.Bterm.end()) ){
                if (*pt1 != *pt2)
                    return false;
            }
            return true;
        }
        
        MGTerm operator&(const MGTerm& t2) const {
            MGTerm ret;
            set_union(Bterm.begin(), Bterm.end(), t2.Bterm.begin(), t2.Bterm.end(), inserter(ret.Bterm, ret.Bterm.begin()));
            return ret;
        }

        MGTerm And(const BTerm& t2) const {
            MGTerm ret;
            set_union(Bterm.begin(), Bterm.end(), t2.begin(), t2.end(), inserter(ret.Bterm, ret.Bterm.begin()));
            return ret;
        }

        int size() const {
            return (int) Bterm.size();
        }

        void show() const {
            if (!Bterm.size()) {
                cout << 1 << " ";
                return;
            }
            bool flag = false;

            for (BTerm::iterator pt = Bterm.begin(); pt != Bterm.end(); pt++) {
                if (flag)
                    cout << "*";
                if (*pt < ACTKEYLEN)
                    cout << "k" << *pt;
                else
                    cout << "v" << *pt - ACTKEYLEN;
                flag = true;
            }
            cout << " ";
        }

        void clear() {
            Bterm.clear();
        }

        bool empty() const {
            return Bterm.empty();
        }

        BTerm::iterator begin() const {
            return Bterm.begin();
        }

        BTerm::iterator end() const {
            return Bterm.end();
        }
        
        void insert(int loc) {
            Bterm.insert(loc);
        }

        void erase(int loc){
            Bterm.erase(loc);
        }

        void erase(BTerm::iterator pt){
            Bterm.erase(pt);
        }

        void erase(BTerm::iterator pt, BTerm::iterator pd){
            Bterm.erase(pt, pd);
        }

        BTerm::iterator find(int value) const {
            return Bterm.find(value);
        }

        BTerm::iterator lower_bound(int value) {
            return Bterm.lower_bound(value);
        }

        BTerm::iterator upper_bound(int value) {
            return Bterm.upper_bound(value);
        }

        MGTerm() {
            Bterm.clear();
        }

        MGTerm(int loc) {
            Bterm.insert(loc);
        }

        MGTerm(int Locs[], int len) {
            Bterm.insert(Locs, Locs+len);
        }

        MGTerm(const MGTerm& t1) {
            Bterm = t1.Bterm;
        }

        ~MGTerm() {
            Bterm.clear();
        }

        BTerm get() const {
            return Bterm;
        }
    
    };

    typedef pair<const MGTerm, unsigned int> MapGPair;
    typedef map<MGTerm, unsigned int> MapGTerm;

    class MapGPoly {
    public:
        MapGTerm Mapterm;

        MapGPoly() {
            Mapterm.clear();
        }

        MapGPoly(MapGPoly& p1) {
            Mapterm.insert(p1.Mapterm.begin(), p1.Mapterm.end());
        }

        ~MapGPoly() {
            Mapterm.clear();
        }

        MapGTerm::reverse_iterator rbegin() {
            return Mapterm.rbegin();
        }

        MapGTerm::reverse_iterator rend() {
            return Mapterm.rend();
        }

        bool InSert(const MapGPair& t1) {
            MapGTerm::iterator it;
            it = Mapterm.find(t1.first);
            if (it != Mapterm.end()) {
                it->second += t1.second;
                return false;
            }
            else {
                Mapterm.insert(t1);
                return true;
            }
        }

        bool InSert(const MGTerm& t1) {
            MapGTerm::iterator it;
            it = Mapterm.find(t1);
            if (it != Mapterm.end()) {
                it->second += 1;
                return false;
            }
            else {
                Mapterm.insert(MapGPair(t1, 1));
                return true;
            }
        }

        bool Merge(MapGPoly& p1) {
            for (MapGTerm::iterator pt = p1.Mapterm.begin(); pt != p1.Mapterm.end(); pt++)
                this->InSert(*pt);
            return true;
        }

        bool MergeMod2(MapGPoly& p1) {
            for (MapGTerm::iterator pt = p1.Mapterm.begin(); pt != p1.Mapterm.end(); pt++){
                if (pt->second & 1)
                    this->InSert(*pt);
            }
            return true;
        }

        bool show() {
            cout << "The Constent of this dictionary: " << endl;
            if (!Mapterm.size()) {
                cout << "NULL!";
                return false;
            }

            for (MapGTerm::iterator pt = Mapterm.begin(); pt != Mapterm.end(); pt++) {
                (pt->first).show();
                cout << " => " << pt->second << endl;
            }
            return true;
        }

        
        double TestBalanced(string file, string message = "") {
            const int ThreadNum = 32;
            int shift = 20;

            unordered_set< Keyterm> keysets;
            vector< Keyterm> keyvalues;

            // int* keyvalue = new int [ACTKEYLEN];
            int* count = new int [ThreadNum];
            for (int i = 0; i < ThreadNum; i++)
                count[i] = 0;
            
            Keyterm keyflag(0);

            Arr2Int Poly; Poly.clear();
            for (auto pt = Mapterm.begin(); pt != Mapterm.end(); pt++) {
                if (pt->second & 1) {
                    Arr1Int term;
                    for (auto pr = pt->first.begin(); pr != pt->first.end(); pr++)
                        term.push_back(*pr);
                    Poly.push_back(term);

                    for (auto pr = pt->first.begin(); pr != pt->first.end(); pr++)
                        keyflag.set(*pr, 1);
                }
            }

            // for (int i = 0; i < 128; i++)
            //     cout << 'k' << i << "(" << keyflag[i] << "), ";
            // cout << endl;

            if (keyflag.count() == 0){
                fstream fout; fout.open(file, ios_base::app);
                fout << endl << message << endl << "Balancedness: 0" << endl << endl;
                fout.close();

                cout << "Balancedness: 0" << endl;
                return 0;
            }
            else if (keyflag.count() < shift)
                shift = keyflag.count();

            int totalnum = (1 << shift);

            while (keyvalues.size() < totalnum){
                random_device rd;
                uniform_int_distribution<int > u(0, 1);
                Keyterm tmpkey(0);
                for (int i = 0; i < tmpkey.size(); i++)
                    tmpkey[i] = u(rd);

                tmpkey &= keyflag;
                auto it = keysets.find(tmpkey);

                if (it == keysets.end()) {
                    keysets.insert(tmpkey);
                    keyvalues.push_back(tmpkey);
                }
            }
            keysets.clear();
            cout << "Random Keys have been completed!" << endl;

            #pragma omp parallel for num_threads (ThreadNum)
            for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++) {
                int polyvalue = 0;
                for (auto pt = Poly.begin(); pt != Poly.end(); pt++){
                    int termvalue = 1;
                    for (auto pr = pt->begin(); pr != pt->end(); pr++){
                        termvalue &= (*PPT)[*pr];
                    }
                    polyvalue ^= termvalue;
                }
                
                int id = omp_get_thread_num();
                count[id] += polyvalue;
            }
            keyvalues.clear();

            int ret = 0;
            for (int i = 0; i < ThreadNum; i++)
                ret += count[i];

            fstream fout; fout.open(file, ios_base::app);
            fout << endl << message << endl << "Balancedness: " << double ( (double) ret / (double) totalnum ) << endl << endl;
            fout.close();

            cout << "Balancedness: " << double ( (double) ret / (double) totalnum ) << endl;
            return (double )ret / (double ) totalnum;
        }


        double TestBalanced3(string file, string message = "", bool flag = true) {
            const int ThreadNum = 32;
            int shift = 20;
            int maxk = 0;

            // key variables find
            bitset<160> keyexist(0);    // 128bit-key and 32bit-newkey
            Arr2Int Poly; Poly.clear();
            for (auto pt = Mapterm.begin(); pt != Mapterm.end(); pt++) {
                if (pt->second & 1) {
                    Arr1Int term;
                    for (auto pr = pt->first.begin(); pr != pt->first.end(); pr++){
                        term.push_back(*pr); 
                        keyexist.set(*pr, 1); 
                        if (maxk < *pr) 
                            maxk = *pr;
                    }
                    Poly.push_back(term);
                }
            }
            maxk += 1;

            if (true) {
                cout << "include key variables("<< maxk <<"):";
                for (int i = 0; i < 160; i++)
                    if(keyexist.test(i))
                        cout << " k" << i;
                cout << endl;
            }

            if (keyexist.count() == 0){
                fstream fout; fout.open(file, ios_base::app);
                fout << endl << message << endl << "Pr[f = 1] = 0" << endl << endl;
                fout.close();

                cout << "Pr[f = 1] = 0" << endl;
                return 0;
            }
            else if (keyexist.count() < shift)
                shift = keyexist.count();

            int alltotal = 1 << shift;
            unordered_set< bitset<160>> keysets;
            vector< bitset<160>> keyvalues;

            int singlethreadnum = 1 << (shift - 4);
            vector<unordered_set< bitset<160>>> threadkeysets(ThreadNum);
            #pragma omp parallel for num_threads (ThreadNum)
            for (int thr = 0; thr < ThreadNum; thr++) {

                threadkeysets[thr].clear();
                // sleep(thr);

                while (threadkeysets[thr].size() < singlethreadnum){
                    
                    random_device rd;
                    uniform_int_distribution<int > u(0, 1);
                    bitset<160> tmpkey(0);

                    if (flag) // bias of new key: 0
                    for (int i = 0; i < maxk; i++)
                        tmpkey[i] = u(rd);
                    
                    if (!flag){ // bias of new key: 1/4
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);
                        for (int i = 128; i < maxk; i++)
                            tmpkey[i] = u(rd) * u(rd);
                    }

                    tmpkey &= keyexist;
                    auto it = threadkeysets[thr].find(tmpkey);
                    if (it == threadkeysets[thr].end())
                        threadkeysets[thr].insert(tmpkey);
                }
                cout << "ThreadNum " << thr << " OK!" << endl;
            }

            for (int thr = 0; thr < ThreadNum; thr++){
                keysets.merge(threadkeysets[thr]);
                // keysets.insert(threadkeysets[thr].begin(), threadkeysets[thr].end());
            }

            if (keysets.size() < alltotal) {
                while (keysets.size() < alltotal) {
                    random_device rd;
                    uniform_int_distribution<int > u(0, 1);
                    bitset<160> tmpkey(0);
                    for (int i = 0; i < maxk; i++)
                        tmpkey[i] = u(rd);
                    tmpkey &= keyexist;

                    auto it = keysets.find(tmpkey);
                    if (it == keysets.end()) {
                        keysets.insert(tmpkey);
                    }
                }
            }

            for (auto ppt = keysets.begin(); ppt != keysets.end(); ppt++){
                keyvalues.push_back(*ppt);
                if (keyvalues.size() >= alltotal)
                    break;
            }
            cout << "Random Keys(" << keysets.size() << ", " << keyvalues.size() <<  ") have been completed!" << endl;
            keysets.clear();


            Arr1Int count(ThreadNum, 0);
            #pragma omp parallel for num_threads (ThreadNum)
            for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++) {
                int polyvalue = 0;
                for (auto pt = Poly.begin(); pt != Poly.end(); pt++){
                    int termvalue = 1;
                    for (auto pr = pt->begin(); pr != pt->end(); pr++){
                        termvalue &= (*PPT)[*pr];
                    }
                    polyvalue ^= termvalue;
                }
                count[omp_get_thread_num()] += polyvalue;
            }
            keyvalues.clear();

            int ret = 0;
            for (int i = 0; i < ThreadNum; i++)
                ret += count[i];
            double pr_feqto1 = (double) ret / (double) alltotal;

            fstream fout; fout.open(file, ios_base::app);
            fout << endl << message << endl << "Pr[f = 1] = " << pr_feqto1 << endl << endl;
            fout.close();

            cout << "Pr[f = 1] = " << pr_feqto1 << endl;
            return pr_feqto1;
        }


        double TestBalanced2(string file, string message = "", bool flag = true) {
            const int ThreadNum = 32;
            int shift = 20;
            int maxk = 0;
            const int bitsetlen = 350;

            int xKLEN = XKEYs.size();
            vector<MGTerm>* sk = new vector<MGTerm>[xKLEN];
            for (int i1 = 0; i1 < xKLEN; i1++) {
                sk[i1].clear();
                for (int i2 = 0; i2 < XKEYs[i1].size(); i2++) {
                    MGTerm temp;
                    for (int i3 = 0; i3 < XKEYs[i1][i2].size(); i3++)
                        temp.insert(XKEYs[i1][i2][i3]);
                    sk[i1].push_back(temp);
                }
            }

            // key variables find
            int first128bitcount = 0;
            bitset<bitsetlen> keyexist(0);    // 128bit-key and 32bit-newkey
            Arr2Int Poly; Poly.clear();
            for (auto pt = Mapterm.begin(); pt != Mapterm.end(); pt++) {
                if (pt->second & 1) {
                    Arr1Int term;
                    for (auto pr = pt->first.begin(); pr != pt->first.end(); pr++){
                        term.push_back(*pr); 
                        keyexist.set(*pr, 1); 
                        if (maxk < *pr) 
                            maxk = *pr;
                    }
                    Poly.push_back(term);
                }
            }
            maxk += 1;

            for (int loc = 128; loc < ACTKEYLEN; loc++) {
                if (keyexist.test(loc)){
                    for (auto pt = sk[loc - 128].begin(); pt != sk[loc - 128].end(); pt++){
                        for (auto pd = pt->begin(); pd != pt->end(); pd++)
                            keyexist.set(*pd, 1);
                    }
                }
            }

            for (int i = 0; i < 128; i++)
                if (keyexist.test(i))
                    first128bitcount += 1;

            if (true) {
                cout << "include key variables("<< maxk <<"):";
                for (int i = 0; i < bitsetlen; i++)
                    if(keyexist.test(i))
                        cout << " k" << i;
                cout << endl;
            }

            if (keyexist.count() == 0) {
                fstream fout; fout.open(file, ios_base::app);
                fout << endl << message << endl << "Pr[f = 1] = 0" << endl << endl;
                fout.close();

                cout << "Pr[f = 1] = 0" << endl;
                return 0;
            }
            else if (first128bitcount < shift)
                shift = first128bitcount;

            int alltotal = 1 << shift;
            unordered_set< bitset<bitsetlen>> keysets;
            vector< bitset<bitsetlen>> keyvalues;

            int singlethreadnum = 1 << (shift - 4);
            vector<unordered_set< bitset<bitsetlen>>> threadkeysets(ThreadNum);
            #pragma omp parallel for num_threads (ThreadNum)
            for (int thr = 0; thr < ThreadNum; thr++) {

                threadkeysets[thr].clear();
                // sleep(thr);

                while (threadkeysets[thr].size() < singlethreadnum){
                    
                    random_device rd;
                    uniform_int_distribution<int > u(0, 1);
                    bitset<bitsetlen> tmpkey(0);

                    if (flag) { // bias of new key: 0
                   
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++)
                            tmpkey[i] = u(rd);
                    }
                    else { // bias of new key: 1/4
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++)
                            tmpkey[i] = u(rd) * u(rd);
                    }

                    tmpkey &= keyexist;
                    auto it = threadkeysets[thr].find(tmpkey);
                    if (it == threadkeysets[thr].end())
                        threadkeysets[thr].insert(tmpkey);
                }
                cout << "ThreadNum " << thr << " OK!" << endl;
            }

            for (int thr = 0; thr < ThreadNum; thr++) {
                keysets.merge(threadkeysets[thr]);
                // keysets.insert(threadkeysets[thr].begin(), threadkeysets[thr].end());
            }

            if (keysets.size() < alltotal) {
                while (keysets.size() < alltotal) {
                    random_device rd;
                    uniform_int_distribution<int > u(0, 1);
                    bitset<bitsetlen> tmpkey(0);

                    if (flag) // bias of new key: 0
                    {
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++)
                            tmpkey[i] = u(rd);
                    }
                    else { // bias of new key: 1/4
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++)
                            tmpkey[i] = u(rd) * u(rd);
                    }

                    tmpkey &= keyexist;

                    auto it = keysets.find(tmpkey);
                    if (it == keysets.end()) {
                        keysets.insert(tmpkey);
                    }
                }
            }

            for (auto ppt = keysets.begin(); ppt != keysets.end(); ppt++) {
                keyvalues.push_back(*ppt);
                if (keyvalues.size() >= alltotal)
                    break;
            }

            #pragma omp parallel for num_threads (ThreadNum)
            for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++){
                bitset<bitsetlen> tmp = *PPT;

                for (int loc = 128; loc < ACTKEYLEN; loc++){
                    int polyvalue = 0;
                    if (keyexist.test(loc)){
                        for (auto pt = sk[loc - 128].begin(); pt != sk[loc - 128].end(); pt++){
                            int termvalue = 1;
                            for (auto pr = pt->begin(); pr != pt->end(); pr++)
                                termvalue &= tmp[*pr];
                            polyvalue ^= termvalue;
                        }
                        (*PPT).set(loc, polyvalue);
                    }
                }
            }

            cout << "Random Keys(" << keysets.size() << ", " << keyvalues.size() <<  ") have been completed!" << endl;
            keysets.clear();
            delete []sk;

            Arr1Int count(ThreadNum, 0);
            #pragma omp parallel for num_threads (ThreadNum)
            for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++) {
                int polyvalue = 0;
                for (auto pt = Poly.begin(); pt != Poly.end(); pt++){
                    int termvalue = 1;
                    for (auto pr = pt->begin(); pr != pt->end(); pr++){
                        termvalue &= (*PPT)[*pr];
                    }
                    polyvalue ^= termvalue;
                }
                count[omp_get_thread_num()] += polyvalue;
            }
            keyvalues.clear();

            int ret = 0;
            for (int i = 0; i < ThreadNum; i++)
                ret += count[i];
            double pr_feqto1 = (double) ret / (double) alltotal;

            fstream fout; fout.open(file, ios_base::app);
            fout << endl << message << endl << "Pr[f = 1] = " << pr_feqto1 << endl << endl;
            fout.close();

            cout << "Pr[f = 1] = " << pr_feqto1 << endl;
            return pr_feqto1;
        }



        double TestBalanced4(string file, Arr1Int mindeg = {}, string message = "") {
            const int ThreadNum = 32;
            int shift = 20;
            int maxk = 0;
            const int bitsetlen = 350;
            bool flag = (mindeg.size() == 0);


            int xKLEN = XKEYs.size();
            vector<MGTerm>* sk = new vector<MGTerm>[xKLEN];
            for (int i1 = 0; i1 < xKLEN; i1++) {
                sk[i1].clear();
                for (int i2 = 0; i2 < XKEYs[i1].size(); i2++) {
                    MGTerm temp;
                    for (int i3 = 0; i3 < XKEYs[i1][i2].size(); i3++)
                        temp.insert(XKEYs[i1][i2][i3]);
                    sk[i1].push_back(temp);
                }
            }

            // key variables find
            int first128bitcount = 0;
            bitset<bitsetlen> keyexist(0);    // 128bit-key and 32bit-newkey
            Arr2Int Poly; Poly.clear();
            for (auto pt = Mapterm.begin(); pt != Mapterm.end(); pt++) {
                if (pt->second & 1) {
                    Arr1Int term;

                    bool lenflag = 0;
                    for (auto pr = pt->first.begin(); pr != pt->first.end(); pr++){
                        term.push_back(*pr); 
                        keyexist.set(*pr, 1); 
                        if (maxk < *pr) 
                            maxk = *pr;
                        
                        if ( *pr >= ACTKEYLEN ) lenflag = true;
                    }
                    Poly.push_back(term);
                }
            }
            maxk += 1;

            for (int loc = 128; loc < ACTKEYLEN; loc++) {
                if (keyexist.test(loc)){
                    for (auto pt = sk[loc - 128].begin(); pt != sk[loc - 128].end(); pt++){
                        for (auto pd = pt->begin(); pd != pt->end(); pd++)
                            keyexist.set(*pd, 1);
                    }
                }
            }

            for (int i = 0; i < 128; i++)
                if (keyexist.test(i))
                    first128bitcount += 1;

            if (true) {
                cout << "include key variables("<< maxk <<"):";
                for (int i = 0; i < bitsetlen; i++)
                    if(keyexist.test(i))
                        cout << " k" << i;
                cout << endl;
            }

            if (keyexist.count() == 0) {
                fstream fout; fout.open(file, ios_base::app);
                fout << endl << message << endl << "Pr[f = 1] = 0" << endl << endl;
                fout.close();

                cout << "Pr[f = 1] = 0" << endl;
                return 0;
            }
            else if (first128bitcount < shift)
                shift = first128bitcount;

            int alltotal = 1 << shift;
            unordered_set< bitset<bitsetlen>> keysets;
            vector< bitset<bitsetlen>> keyvalues;

            int singlethreadnum = 1 << (shift - 4);
            vector<unordered_set< bitset<bitsetlen>>> threadkeysets(ThreadNum);
            #pragma omp parallel for num_threads (ThreadNum)
            for (int thr = 0; thr < ThreadNum; thr++) {

                threadkeysets[thr].clear();
                // sleep(thr);

                while (threadkeysets[thr].size() < singlethreadnum){
                    
                    random_device rd;
                    uniform_int_distribution<int > u(0, 1);
                    bitset<bitsetlen> tmpkey(0);

                    if (flag) { // bias of new key: 0
                   
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++)
                            tmpkey[i] = u(rd);
                    }
                    else { // bias of new key: 1/4
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++) {
                            tmpkey[i] = 1;

                            for (int ll = 0; ll < mindeg[i - ACTKEYLEN]; ll++)
                                tmpkey[i] = tmpkey[i] * u(rd);
                        }
                    }

                    tmpkey &= keyexist;
                    auto it = threadkeysets[thr].find(tmpkey);
                    if (it == threadkeysets[thr].end())
                        threadkeysets[thr].insert(tmpkey);
                }
                cout << "ThreadNum " << thr << " OK!" << endl;
            }

            for (int thr = 0; thr < ThreadNum; thr++) {
                keysets.merge(threadkeysets[thr]);
                // keysets.insert(threadkeysets[thr].begin(), threadkeysets[thr].end());
            }

            if (keysets.size() < alltotal) {
                while (keysets.size() < alltotal) {
                    random_device rd;
                    uniform_int_distribution<int > u(0, 1);
                    bitset<bitsetlen> tmpkey(0);

                    if (flag) // bias of new key: 0
                    {
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++)
                            tmpkey[i] = u(rd);
                    }
                    else { // bias of new key: 1/4
                        for (int i = 0; i < 128; i++)
                            tmpkey[i] = u(rd);

                        for (int i = ACTKEYLEN; i < maxk; i++){
                            tmpkey[i] = 1;

                            for (int ll = 0; ll < mindeg[i - ACTKEYLEN]; ll++)
                                tmpkey[i] = tmpkey[i] * u(rd);
                        }
                    }

                    tmpkey &= keyexist;

                    auto it = keysets.find(tmpkey);
                    if (it == keysets.end()) {
                        keysets.insert(tmpkey);
                    }
                }
            }

            for (auto ppt = keysets.begin(); ppt != keysets.end(); ppt++) {
                keyvalues.push_back(*ppt);
                if (keyvalues.size() >= alltotal)
                    break;
            }

            #pragma omp parallel for num_threads (ThreadNum)
            for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++){
                bitset<bitsetlen> tmp = *PPT;

                for (int loc = 128; loc < ACTKEYLEN; loc++){
                    int polyvalue = 0;
                    if (keyexist.test(loc)){
                        for (auto pt = sk[loc - 128].begin(); pt != sk[loc - 128].end(); pt++){
                            int termvalue = 1;
                            for (auto pr = pt->begin(); pr != pt->end(); pr++)
                                termvalue &= tmp[*pr];
                            polyvalue ^= termvalue;
                        }
                        (*PPT).set(loc, polyvalue);
                    }
                }
            }

            cout << "Random Keys(" << keysets.size() << ", " << keyvalues.size() <<  ") have been completed!" << endl;
            keysets.clear();
            delete []sk;

            Arr1Int count(ThreadNum, 0);
            #pragma omp parallel for num_threads (ThreadNum)
            for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++) {
                int polyvalue = 0;
                for (auto pt = Poly.begin(); pt != Poly.end(); pt++){
                    int termvalue = 1;
                    for (auto pr = pt->begin(); pr != pt->end(); pr++){
                        termvalue &= (*PPT)[*pr];
                    }
                    polyvalue ^= termvalue;
                }
                count[omp_get_thread_num()] += polyvalue;
            }
            keyvalues.clear();

            int ret = 0;
            for (int i = 0; i < ThreadNum; i++)
                ret += count[i];
            double pr_feqto1 = (double) ret / (double) alltotal;

            fstream fout; fout.open(file, ios_base::app);
            fout << endl << message << endl << "Pr[f = 1] = " << pr_feqto1 << endl << endl;
            fout.close();

            cout << "Pr[f = 1] = " << pr_feqto1 << endl;
            return pr_feqto1;
        }


        bool showANF(string message = "") {
            cout << message << endl << "# p(k,v) = ";

            if (Mapterm.size() == 0) {
                cout << "0 " << endl << "- The number of terms which are contained in superpoly: 0"
                    << endl << "- The number of feasible trails is 0" << endl;
                return false;
            }

            int CoutCount = 0;
            int FeasibleSolutions = 0;
            int TrueTermsNum = 0;

            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                FeasibleSolutions += pr->second;
                TrueTermsNum += ((pr->second) & 1);

                if (((pr->second) & 1) == 0)
                    continue;

                if (CoutCount)
                    cout << " + ";
                if ((pr->first.size()) == 0)
                    cout << '1';
                else{
                    bool flag = false;
                    for (BTerm::iterator pt = pr->first.begin(); pt != pr->first.end(); pt++){
                        if (flag)
                            cout << "*";
                        if (*pt < ACTKEYLEN)
                            cout << "k" << *pt;
                        else
                            cout << "v" << *pt - ACTKEYLEN;
                        flag = true;
                    }
                }
                CoutCount += 1;
            }
            cout << endl << "- The number of terms which are contained in superpoly: " << TrueTermsNum
                << endl << "- The number of feasible trails if " << FeasibleSolutions << endl;
            return true;
        }

        bool empty() {
            return Mapterm.empty();
        }

        bool clear() {
            Mapterm.clear();
            return true;
        }

        uint32_t size() {
            return (uint32_t) Mapterm.size();
        }      

        void WriteValueToFile(string file, string message, bool OutputCoeffFlag = false) {
            ofstream fout;
            fout.open(file, ios_base::app);
            if (Mapterm.size() == 0) {
                fout << 0 << ' ' << message << " All Trails: 0" << endl;
                fout.close();
                return;
            }

            int TermNum = 0, AllMonomials = 0;
            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                AllMonomials += pr->second;
                TermNum += (pr->second & 0x1);
            }

            if (!OutputCoeffFlag) {
                fout << TermNum << ' ' << message << " All Trails: " << AllMonomials << endl;
                for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++)
                    if (pr->second & 0x1){
                        fout << (pr->first.size()) << ' ';
                        for (BTerm::iterator pt = pr->first.begin(); pt != pr->first.end(); pt++)
                            fout << *pt << " ";
                        fout << endl;
                    }
            }
            else {
                fout << Mapterm.size() << ' ' << message << " All Trails: " << AllMonomials << endl;
                for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++){
                    fout << (pr->second) << ' ' << (pr->first.size()) << " ";
                    for (BTerm::iterator pt = pr->first.begin(); pt != pr->first.end(); pt++)
                        fout << *pt << " ";
                    fout << endl;
                }
            }

            fout << endl;
            fout.close();
        }

        void ReadValueFromFile(string Infile, bool InputCoeffFlag = false) {
            Mapterm.clear();

            ifstream fin;
            string line, c;
            int ssize = 0;
            int value = 0;

            fin.open(Infile, ios_base::in);
            fin >> dec >> ssize;
            getline(fin, line);
            cout << ssize << ' ' << line << endl;

            while (ssize--) {
                if (InputCoeffFlag)
                    fin >> value;

                int cc = 0, tvalue = 0;
                fin >> cc;

                MGTerm termtemp; termtemp.clear();

                while(cc--)
                {
                    fin >> tvalue;
                    termtemp.insert(tvalue);
                }

                if (InputCoeffFlag)
                    this->InSert(MapGPair(termtemp, value));
                else
                    this->InSert(termtemp);
            }
            // this->showANF();
            cout << "Read All Date!" << endl;
            
            fin.close();
        }

        void WritePolyToFile(string ofile, string message = "", bool OutPutTermNumFlag = false) {
            
            ofstream fout;
            fout.open(ofile, ios_base::app);
            fout << "- The superpoly of the cube ( With " << ACTKEYLEN << " vars )" << endl
                << "  " << message << endl;

            if (Mapterm.size() == 0) {
                fout << "  The number of monomials in ANF: 0, the number of feasible solutions: 0" << endl
                    << "  The number of monomials in polynomial(including the monomials with even coefficient): 0, " << endl
                    << "- p(k) = 0" << endl << endl;
                fout.close();
                return;
            }
            
            int FeasibleSolutions = 0, TrueTermsNum = 0;
            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                FeasibleSolutions += pr->second;
                TrueTermsNum += ((pr->second) & 1);
            }

            fout << "  The number of monomials in ANF: " << TrueTermsNum << ", the number of feasible solutions: " << FeasibleSolutions << endl 
                << "  The number of monomials in polynomial(including the monomials with even coefficient): " << (uint32_t) Mapterm.size() << endl
                << "- p(k) = ";

            bool outputplusflag = false;

            // Arr1Int tmpVarCount(ACTKEYLEN, 0);

            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                if ((pr->second & 1) == 0)
                    continue;

                if (outputplusflag)
                    fout << " + ";
                if (!(pr->first).size())
                    fout << "1";
                else{
                    bool flag = false;

                    for (BTerm::iterator pt = pr->first.begin(); pt != pr->first.end(); pt++){

                        // tmpVarCount[*pt] += 1;
                        
                        if (flag)
                            fout << "*";
                        if (*pt < ACTKEYLEN)
                            fout << "k" << *pt;
                        else
                            fout << "v" << *pt - ACTKEYLEN;
                        flag = true;
                    }
                }
                outputplusflag = true;
            }

            fout << endl << endl;
            // for (int i = 0; i < ACTKEYLEN; i++)
            //     if (tmpVarCount[i] > 0)
            //         fout << "(" << i << ", " << tmpVarCount[i] << "), ";
            // fout << endl;

            if (OutPutTermNumFlag){
                fout << endl << "------------------------------------------------" << endl;
                for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++)
                {
                    fout << setw(12) << pr->second << "  |    ";

                    if (!(pr->first).size())
                        fout << 1 << endl;
                    else{
                        bool flag = false;
                        for (BTerm::iterator pt = pr->first.begin(); pt != pr->first.end(); pt++){
                            if (flag)
                                fout << "*";
                            if (*pt < ACTKEYLEN)
                                fout << "k" << *pt;
                            else
                                fout << "v" << *pt - ACTKEYLEN;
                            flag = true;
                        }
                        fout << endl;
                    }
                }
                fout << " --------------------------------------------------------------- " << endl;
            }
            fout << endl << endl;
            fout.close();
        }


        void WritevPolyToFile(string ofile, string message = "", bool OutPutTermNumFlag = false) {
            
            ofstream fout;
            fout.open(ofile, ios_base::app);
            fout << "- The superpoly of the cube ( With " << 96 << " v-vars )" << endl
                << "  " << message << endl;

            if (Mapterm.size() == 0) {
                fout << "  The number of monomials in ANF: 0, the number of feasible solutions: 0" << endl
                    << "  The number of monomials in polynomial(including the monomials with even coefficient): 0, " << endl
                    << "- p(k) = 0" << endl << endl;
                fout.close();
                return;
            }
            
            int FeasibleSolutions = 0, TrueTermsNum = 0;
            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                FeasibleSolutions += pr->second;
                TrueTermsNum += ((pr->second) & 1);
            }

            fout << "  The number of monomials in ANF: " << TrueTermsNum << ", the number of feasible solutions: " << FeasibleSolutions << endl 
                << "  The number of monomials in polynomial(including the monomials with even coefficient): " << (uint32_t) Mapterm.size() << endl
                << "- p(k) = ";

            bool outputplusflag = false;
            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                if ((pr->second & 1) == 0) continue;
                if (outputplusflag) fout << " + ";

                if (!(pr->first).size()) fout << "1";
                else {
                    bool flag = false;

                    for (BTerm::iterator pt = pr->first.begin(); pt != pr->first.end(); pt++){
                        if (flag) fout << "*";
                        fout << "v" << *pt;
                        flag = true;
                    }
                }
                outputplusflag = true;
            }

            fout << endl << endl;
            fout.close();
        }


        void WriteNVarsGPoly(string ofile, string message, bool OutPutTermNumFlag = false)
        {
            ofstream fout;
            fout.open(ofile, ios_base::app);
            fout << "- The superpoly of the cube ( With " << ACTKEYLEN << " vars, " << message << ")" << endl;

            if (Mapterm.size() == 0) {
                fout << "  The number of monomials in ANF: 0, the number of feasible solutions: 0" << endl
                    << "  The number of monomials in polynomial(including the monomials with even coefficient): 0" << endl
                    << "- p(k) = 0" << endl << endl;
                fout.close();
                return;
            }

            int SolNum = 0, TermNum = 0;
            for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                SolNum += pr->second;
                TermNum += (pr->second & 1);
            }

            fout << "  The number of monomials in ANF: " << TermNum << ", the number of feasible solutions: " << SolNum << endl
                << "  The number of monomials in polynomial(including the monomials with even coefficient): " << (uint32_t) Mapterm.size() << endl
                << "- p(xk) = ";

            if (TermNum == 0){
                fout << 0 << endl << endl;
            } else {
                bool outputplusflag = false;
                for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++)
                {
                    if ((pr->second & 1) == 0)
                        continue;

                    if (outputplusflag)
                        fout << " + ";

                    if (!(pr->first).size())
                        fout << "1";
                    else{
                        bool flag = false;

                        for (auto pt = pr->first.begin(); pt != pr->first.end(); pt++){
                            if (flag)
                                fout << "*";
                            fout << "k" << *pt;
                            flag = true;
                        }
                    }
                    outputplusflag = true;
                }
                fout << endl << " ------------------------------------- " << endl;

                outputplusflag = false;
                fout << "- p(k) = ";
                for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                    if ((pr->second & 1) == 0)
                        continue;

                    if (outputplusflag)
                        fout << " + ";

                    if (!(pr->first).size())
                        fout << "1";
                    else{
                        bool flag = false;
                        for (auto pt = pr->first.begin(); pt != pr->first.end(); pt++){
                            if (flag)
                                fout << "*";
                            fout << STRPOLY[*pt];
                            flag = true;
                        }
                    }
                    outputplusflag = true;
                }
                fout << endl << " ------------------------------------- " << endl;
            }

            if (OutPutTermNumFlag){
                for (MapGTerm::reverse_iterator pr = Mapterm.rbegin(); pr != Mapterm.rend(); pr++) {
                    fout << setw(12) << pr->second << "  |    ";

                    if (!(pr->first).size())
                        fout << 1;
                    else{
                        bool flag = false;
                        for (auto pt = pr->first.begin(); pt != pr->first.end(); pt++){
                            if (flag)
                                fout << "*";
                            fout << STRPOLY[*pt];
                        }
                    }
                    fout << endl;
                }
                fout << " --------------------------------------------------------------- " << endl << endl << endl;
            }
            fout << endl << endl;
            fout.close();
        }

        // ----------------------------------------------------------------------------------------
        void ConvertNKvarsTo128Kvars(MapGPoly &Ret)
        {
            int xKLEN = XKEYs.size();
            vector<MGTerm>* sk = new vector<MGTerm>[xKLEN];

            for (int i1 = 0; i1 < xKLEN; i1++) {
                sk[i1].clear();
                for (int i2 = 0; i2 < XKEYs[i1].size(); i2++) {
                    MGTerm temp;
                    for (int i3 = 0; i3 < XKEYs[i1][i2].size(); i3++)
                        temp.insert(XKEYs[i1][i2][i3]);
                    sk[i1].push_back(temp);
                }
            }

            // for (int i = 0; i < xKLEN; i++) {
            //     cout << "sk[" << i << "]: ";
            //     for (int j = 0; j < sk[i].size(); j++)
            //         sk[i][j].show();
            //     cout << endl;
            // }

            vector<MGTerm> TempMTerms;
            for (auto pt = Mapterm.begin(); pt != Mapterm.end(); pt++)
                if (pt->second & 1)
                    TempMTerms.push_back(pt->first);
            int SpLen = TempMTerms.size();

            // --------------------------------
            int ThreadNum = std::thread::hardware_concurrency();
            MapGPoly* TempMapPoly = new MapGPoly[ThreadNum];
            int DealCount = 0;
            // --------------------------------

            #pragma omp parallel for num_threads(ThreadNum) schedule(dynamic, 1000)
            for (int pf = 0; pf < SpLen; pf++) {
                vector<MGTerm> **Arr = new vector<MGTerm>* [xKLEN +1];
                MGTerm Temp;
                int count = 0;
                auto pt = TempMTerms[pf].begin();
                for (; pt != TempMTerms[pf].end(); pt++){
                    if (*pt < 128)
                        Temp.insert(*pt);
                    else 
                        Arr[count++] = sk + ((*pt) - 128);
                }
                vector<MGTerm> tempMGTerm = { Temp };
                Arr[count++] = &tempMGTerm;

                int id = omp_get_thread_num();
                TempMapPoly[id].MGTermsMulti(Arr, count);

                tempMGTerm.clear();
                delete[] Arr;
            }

            for (int i = 0; i < ThreadNum; i++){
                Ret.MergeMod2(TempMapPoly[i]);
                TempMapPoly[i].clear();
            }

            delete[] TempMapPoly;
            delete[] sk;
        }

        void MGTermsMulti(vector<MGTerm> *kpolys[], int len)
        {
            vector<MGTerm> InANF(*(kpolys[0])), OutANF;
            vector<MGTerm> *InPt = &InANF;
            vector<MGTerm> *OutPt = &OutANF;
            vector<MGTerm> *TempPt = &InANF;

            for (int i = 1; i < len; i++) {
                for (vector<MGTerm>::iterator pt = InPt->begin(); pt != InPt->end(); pt++)
                    for (vector<MGTerm>::iterator pd = kpolys[i]->begin(); pd != kpolys[i]->end(); pd++)
                        OutPt->push_back((*pt) & (*pd));
                TempPt = InPt;
                InPt = OutPt;
                OutPt = TempPt;
                OutPt->clear();
            }

            for (vector<MGTerm>::iterator pt = InPt->begin(); pt != InPt->end(); pt++)
                this->InSert(*pt);
            InPt->clear();
        }
    };
}


#endif