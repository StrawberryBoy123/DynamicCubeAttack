#pragma once
#include "ParameterSelection.h"
#include <gurobi_c++.h>


#ifndef GRAIN128AEAD_H_
#define GRAIN128AEAD_H_

 
// --------------------------------------------------------------------------------------------
void GInitilization(GRBModel &Model, GRBVar* svar, GRBVar *bvar, GRBVar *kvar, GRBVar *vvar);
void Grain128AEADEvalBDPT(SecParaG::MapGPoly& ResPoly, GTerm &Pterm, IvGterm &Cube, int IRound, bool SolutFlag = true, int TimeLimit = 0, int ThreadNum = 0, int ModelType = 0, IvGterm DCube = 0, bool AEAD_FLAG = true);
bool FilterPartTermBDPT(SecParaG::MapGPoly& RetSuperpoly, GPoly& ANF, int IRound, IvGterm Cube, string files, int ModelType = 0, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, bool AEAD_FLAG = true);
bool SPRecoveryForGrain128Family(int ORound, IvGterm Cube = 0, int ModelType = 0, int count = 0, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, int wrongiv = 0, bool AEAD_FLAG = true);
int DegEst(GPoly ANF, int IRound, IvGterm Cube, string files, int ModelType = 0, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, int wrongiv = 0, bool AEAD_Flag = true);
void TestBalanced(SecParaG::MapGPoly Poly[], int Len,  string file = "BalancedFile.txt");

// --------------------------------------------------------------------------------------------
bool BiasEvaluation(int ORound, IvGterm Cube = 0, int ModelType = 0, int count = 0, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, int wrongiv = 0, bool AEAD_FLAG = true);
bool BiasEvaluation(SecParaG::MapGPoly RetSuperpoly, GPoly& ANF, int IRound, IvGterm Cube, string files, int ModelType = 0, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, bool AEAD_FLAG = true);
Arr1Int DegEst(GTerm &Pterm, IvGterm &Cube, int IRound, int ThreadNum = 0, int ModelType = 0, IvGterm DCube = 0, bool AEAD_FLAG = true);
// ----------------

int DegEstForLowBound(GPoly ANF, int IRound, IvGterm Cube, string files, int ModelType = 0, IvGterm DCube = 0, bool guassflag = true, int guassloc = 0, int wrongiv = 0, bool AEAD_Flag = true);
int Grain128AEADTest(GTerm Pterm, IvGterm &Cube, int IRound, int ThreadNum = 0, int ModelType = 0, IvGterm DCube = 0, bool AEAD_FLAG = true);
// --------------------------------------------------------------------------------------------
 

// --------------------------------------------------------------------------------------------
GRBVar tap(GRBModel& model, GRBVar& x);
GRBVar funcZ(GRBModel& model, GRBVar* b, GRBVar* s, bool AEAD_FLAG = true, bool outputbitflag = false);
GRBVar funcF(GRBModel& model, GRBVar* s);
GRBVar funcG(GRBModel& model, GRBVar* b, bool AEAD_FLAG = true);


// ------------------------------------------------------------------------------------------------------
void InvExpressInitGAEAD(GPoly& ZR, GPoly& updateb, GPoly& updates, GPoly& SAll);
void InvExpressInitG128(GPoly& ZR, GPoly& updateb, GPoly& updates, GPoly& SAll);
void ExpressOneRound(GPoly& OutPutANF, GPoly& InPutANF, GPoly UpdateFunc[], GPoly& TempPoly); 
void ExpressRecursivelyForGrain(const int ORound, const int TargetRound, string file, bool AEAD_Flag = true);
// void ExpressRecursivelyForGrain128AEAD(const int ORound, const int TargetRound, string file);
void GReadANF(int &TargetRound, GPoly &InPutANF, string file, bool degkflag = true);
void GReadANF(int &TargetRound, GPoly &InPutANF, SecParaG::MapGPoly &SP, string file, bool TPInputCeoffFlag = true, bool MPInputCoeffFlag = false);


#endif GRAIN128AEAD_H_ 