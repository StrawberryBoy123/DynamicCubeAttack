#pragma once
#include <algorithm>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <set>
#include <unordered_set>
#include <functional>


#ifndef POLY_H_
#define POLY_H_

using namespace std;

const int SIZEBw = 500000;
const int SIZEFw = 100000;
const int xSIZEFw = 5000;
const int ZSIZEFw = 50000;

typedef vector< int > Arr1Int;
typedef vector<Arr1Int> Arr2Int;
typedef vector<Arr2Int> Arr3Int;
typedef vector<Arr3Int> Arr4Int;
 
// ****************************************************************************
class Term
{
private:
    int degk = -1;
    int deg = 0;
    int Coeff = 1;
     
    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:
    uint32_t pterm[9] = {0};

    int degree()
    {
        deg = 0;
        for (int i = 0; i < 9; i++)
            deg += Weight(pterm[i]);
        return deg;
    }

    void setdegk(int n)
    {
        degk = n;
    }

    int getdegk() const
    {
        return degk;
    }

    void setdeg(int n)
    {
        if (n >= 288)
            deg = 288;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    bool setCoeff(int n)
    {
        if (n < 0)
            return false;
        Coeff = n;
        return true;
    }

    int getCoeff() const
    {
        return Coeff;
    }

    void AddCoeffOne()
    {
        Coeff += 1;
    }

    bool AddCoeff(int n)
    {
        if (n < 0)
            return false;
        Coeff += n;
        return true;
    }

    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": " << Coeff << '*';

        if (deg == 0)
            fout << '1' << endl;
        else 
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        fout << 's' << ((i << 5) + j + 1);
        fout << endl;
        fout.close();
    }

    void show(string message)
    {
        cout << "- " << message << ": " << Coeff << '*';

        if (deg == 0)
            cout << '1';
        else
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        cout << 's' << ((i << 5) + j + 1);
        cout << endl;
    }

    void showvalue(string message)
    {
        cout << "- " << message << ", ( degk = " << degk << ", deg = " << deg << ", Coeff = " << Coeff << "): ";
        for (int i = 0; i < 9; i++)
            cout << "0x" << hex << pterm[i] << " ";
        cout << endl;
    }

    Term& operator=(const Term &p)
    {
        if (this == &p)
            return *this;
        
        for (int i = 0; i < 9; i++)
            this->pterm[i] = p.pterm[i];
        this->deg = p.deg;
        this->degk = p.degk;
        this->Coeff = p.Coeff;
        return *this;
    }

    bool operator!=(const Term &p)
    {
        for (int i = 0; i < 9; i++)
            if (pterm[i] != p.pterm[i])
                return true;
        return false;
    }

};

class Poly
{
private:
    uint32_t Size = 0;

public:
    Term* poly;

    Poly();
    Poly(uint32_t size);
    Poly(const Poly &p);
    ~Poly();

    uint32_t getSize() const;
    bool setSize(int n);

    void setSize(uint32_t n);
    void clear();
    void AddSizeOne();
    void AddTerm(const Term& t1);

    Poly & SetPolyLen(const uint32_t len);

    Poly & operator=(const Poly &p);	
    Poly & PolyCopy(const Poly &p);
    Poly & MergeSameTerm();
    Poly & DiscardEvenCoeff();
    Poly & Merge(const Poly &p);

    void WriteValueToFile(int n, char file[], string message = " ", bool ios_base_flag = 0, uint32_t StartPos = 0);
    void WritePolyToFile(int n, char file[], string message = " ", bool ios_base_flag = 0, uint32_t StartPos = 0);
    void show(int Round, string message = " ");
};

Term operator* (const Term &pt1, const Term &pt2);
bool operator< (const Term &p1, const Term &p2);
bool operator<= (const Term &p1, const Term &p2);
bool operator> (const Term &p1, const Term &p2);
bool operator== (const Term &p1, const Term &p2);
bool Divisibility(const Term &BigP, const Term &SmallP);

void PolyAdd(Poly &result, const Poly &p1, const Poly &p2);
void PolyMul(Poly &result, const Poly &p1, const Term &pt1);
void PolyMul(Poly &result, const Poly &p1, const Poly &p2);
void PolyMul(Poly &result, const Poly& p1, const Poly& p2, const Poly& p3);



// **************************************************************************
class TermFw
{
private:
    int deg = 0;
    
    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:
    uint32_t pterm[5] = {0};    // 80-bit Iv + 80-bit Key

    void setdeg(int n)
    {
        if (n >= 288)
            deg = 288;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    bool is_one() const
    {
        if ((deg == 0) && ((pterm[0] | pterm[1] | pterm[2] | pterm[3] | pterm[4]) == 0))
            return true;
        else
            return false;
    }

    // flag = 0, deg(iv); flag = 1, deg(key, iv)
    int degree(int flag = 0)
    {
        deg = 0;
        if (flag)  // flag = 1: key and iv
            for (int i = 0; i < 5; i++)
                deg += Weight(pterm[i]);
        else    // flag = 0: iv
            deg = Weight(pterm[0]) + Weight(pterm[1]) + Weight(pterm[2] & 0xffff0000);
        return deg;
    }


    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": ";

        if ( (deg == 0) && ( (pterm[0] | pterm[1] | pterm[2] | pterm[3] | pterm[4]) == 0) )
            fout << '1' << endl;
        else 
            for (int i = 0; i < 160; i++)
                if ((pterm[i>>5] >> (0x1f ^ (i&0x1f))) & 1)
                {
                    if (i < 80)
                        fout << 'v' << i;
                    else
                        fout << 'k' << i-80; 
                }
        fout << endl;
        fout.close();
    }

    void Xor(const TermFw& t){
        for (int i = 0; i < 5; i++)
            pterm[i] ^= t.pterm[i];
        degree();
    }
};


class PolyFw
{
public:
    TermFw* poly;
    uint32_t Size = 0;

    PolyFw();
    PolyFw(uint32_t size);
    PolyFw(const PolyFw &p);
    ~PolyFw();

    PolyFw & SuperPolyTerm(const int deg);
    PolyFw & operator=(const PolyFw &p);	
    PolyFw & PolyCopy(const PolyFw &p);
    PolyFw & SetPolyLen(const uint32_t len);
    PolyFw & XorTerm(const TermFw &term);
    PolyFw & Merge(const PolyFw &p);

    PolyFw & RemoveDup();
    void show(int Round, string message = " ");
    void WritePolyToFile(int n, char file[], string message = " "); 
    void WritePolyToFile_Simple(char file[], int loc);
};

TermFw operator* (const TermFw &pt1, const TermFw &pt2);
bool operator< (const TermFw &p1, const TermFw &p2);
bool operator<= (const TermFw &p1, const TermFw &p2);
bool operator> (const TermFw &p1, const TermFw &p2);
bool operator== (const TermFw &p1, const TermFw &p2);

void PolyAdd(PolyFw &result, const PolyFw &p1, const PolyFw &p2);
void PolyMul(PolyFw &result, PolyFw &p1, TermFw &pt1);
void PolyMul(PolyFw &result, PolyFw &p1, PolyFw &p2);
void PolyMul(PolyFw &result, PolyFw &p1, PolyFw &p2, PolyFw &p3);


// ************************************** Kreyvium **************************************
class KTerm
{
private:
    int degk = -1;
    int deg = 0;
    int Coeff = 1;
    
    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:
    // 288bits(s); 128bits(v); 128bits(k)
    uint32_t pterm[17] = { 0 };

    int degree()
    {
        deg = 0;
        for (int i = 0; i < 17; i++)
            deg += Weight(pterm[i]);
        return deg;
    }

    void setdegk(int n)
    {
        degk = n;
    }

    int getdegk() const
    {
        return degk;
    }

    void setdeg(int n)
    {
        if (n >= 544)
            deg = 544;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    void Adddeg(int n)
    {
        if (n + deg >= 544)
            deg = 544;
        else
            deg += n;
    }

    bool setCoeff(int n)
    {
        if (n < 0)
            return false;
        Coeff = n;
        return true;
    }

    int getCoeff() const
    {
        return Coeff;
    }

    void AddCoeffOne()
    {
        Coeff += 1;
    }

    bool AddCoeff(int n)
    {
        if (n < 0)
            return false;
        Coeff += n;
        return true;
    }

    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": " << Coeff << '*';

        if (deg == 0)
            fout << '1' << endl;
        else
        {
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        fout << 's' << ((i << 5) + j + 1);
            for (int i = 9; i < 13; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        fout << 'v' << ((i - 9) * 32 + j);
            for (int i = 13; i < 17; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        fout << 'k' << ((i - 13) * 32 + j);
        }
        fout << endl;
        fout.close();
    }

    void show(string message)
    {
        cout << "- " << message << ": " << Coeff << '*';

        if (deg == 0)
            cout << '1';
        else
        {
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        cout << 's' << ((i << 5) + j + 1);
            for (int i = 9; i < 13; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        cout << 'v' << ((i - 9) * 32 + j);
            for (int i = 13; i < 17; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        cout << 'k' << ((i - 13) * 32 + j);
        }
        cout << endl;
    }

    void showvalue(string message)
    {
        cout << "- " << message << ", ( degk = " << degk << ", deg = " << deg << ", Coeff = " << Coeff << "): ";
        for (int i = 0; i < 17; i++)
            cout << "0x" << hex << pterm[i] << " ";
        cout << endl;
    }

    KTerm& operator=(const KTerm &p)
    {
        if (this == &p)
            return *this;

        for (int i = 0; i < 17; i++)
            this->pterm[i] = p.pterm[i];
        this->deg = p.deg;
        this->degk = p.degk;
        this->Coeff = p.Coeff;
        return *this;
    }

    bool operator!=(const KTerm &p)
    {
        for (int i = 0; i < 17; i++)
            if (pterm[i] != p.pterm[i])
                return true;
        return false;
    }

};

class KPoly
{
private:
    uint32_t Size = 0;

public:
    KTerm* poly;

    KPoly();
    KPoly(uint32_t size);
    KPoly(const KPoly &p);
    ~KPoly();

    uint32_t getSize() const;
    bool setSize(int n);

    void setSize(uint32_t n);
    void clear();
    void AddSizeOne();
    void AddTerm(const KTerm& t1);

    KPoly & SetPolyLen(const uint32_t len);

    KPoly & operator=(const KPoly &p);
    KPoly & PolyCopy(const KPoly &p);
    KPoly & MergeSameTerm();
    KPoly & DiscardEvenCoeff();
    KPoly & Merge(const KPoly &p);

    void WriteValueToFile(int n, char file[], string message = " ", bool ios_base_flag = 0, uint32_t StartPos = 0);
    void WritePolyToFile(int n, char file[], string message = " ", bool ios_base_flag = 0, uint32_t StartPos = 0);
    void show(int Round, string message = " ");
};

KTerm operator* (const KTerm &pt1, const KTerm &pt2);
bool operator< (const KTerm &p1, const KTerm &p2);
bool operator<= (const KTerm &p1, const KTerm &p2);
bool operator> (const KTerm &p1, const KTerm &p2);
bool operator== (const KTerm &p1, const KTerm &p2);
bool Divisibility(const KTerm &BigP, const KTerm &SmallP);

void PolyAdd(KPoly &result, const KPoly &p1, const KPoly &p2);
void PolyMul(KPoly &result, const KPoly &p1, const KTerm &pt1);
void PolyMul(KPoly &result, const KPoly &p1, const KPoly &p2);
void PolyMul(KPoly &result, const KPoly& p1, const KPoly& p2, const KPoly& p3);


// ************************************** 256 (Key, Iv) **************************************
class KTermFw
{
private:
    int deg = 0;
    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:
    uint32_t pterm[8] = { 0 };   // 128-bit Iv + 128-bit Key

    void setdeg(int n)
    {
        if (n >= 256)
            deg = 256;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    bool is_one() const
    {
        if ((deg == 0) && ((pterm[0] | pterm[1] | pterm[2] | pterm[3] | pterm[4] | pterm[5] | pterm[6] | pterm[7]) == 0))
            return true;
        else
            return false;
    }

    // flag = 0, deg(iv); flag = 1, deg(key, iv)
    int degree(int flag = 0)
    {
        deg = 0;
        if (flag)  // flag = 1: key and iv
            for (int i = 0; i < 8; i++)
                deg += Weight(pterm[i]);
        else    // flag = 0: iv
            deg = Weight(pterm[0]) + Weight(pterm[1]) + Weight(pterm[2]) + Weight(pterm[3]);
        return deg;
    }

    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": ";

        if (is_one())
            fout << '1' << endl;
        else
            for (int i = 0; i < 256; i++)
                if ((pterm[i >> 5] >> (0x1f ^ (i & 0x1f))) & 1)
                {
                    if (i < 128)
                        fout << 'v' << i;
                    else
                        fout << 'k' << i - 128;
                }
        fout << endl;
        fout.close();
    }

    void Xor(const KTermFw& t)
    {
        for (int i = 0; i < 8; i++)
            pterm[i] ^= t.pterm[i];
        degree();
    }
};


class KPolyFw
{
public:
    KTermFw* poly;
    uint32_t Size = 0;

    KPolyFw();
    KPolyFw(uint32_t size);
    KPolyFw(const KPolyFw &p);
    ~KPolyFw();

    KPolyFw & SuperPolyTerm(const int deg);
    KPolyFw & operator=(const KPolyFw &p);
    KPolyFw & PolyCopy(const KPolyFw &p);
    KPolyFw & SetPolyLen(const uint32_t len);
    KPolyFw & XorTerm(const KTermFw &term);
    KPolyFw & Merge(const KPolyFw &p);

    KPolyFw & RemoveDup();
    void show(int Round, string message = " ");
    void WritePolyToFile(int n, char file[], string message = " ");
    void WritePolyToFile_Simple(char file[], int loc);
};

KTermFw operator* (const KTermFw &pt1, const KTermFw &pt2);
bool operator< (const KTermFw &p1, const KTermFw &p2);
bool operator<= (const KTermFw &p1, const KTermFw &p2);
bool operator> (const KTermFw &p1, const KTermFw &p2);
bool operator== (const KTermFw &p1, const KTermFw &p2);

void PolyAdd(KPolyFw &result, const KPolyFw &p1, const KPolyFw &p2);
void PolyAdd(KPolyFw &result, KPolyFw **ps, int len);
void PolyMul(KPolyFw &result, KPolyFw &p1, KTermFw &pt1);
void PolyMul(KPolyFw &result, KPolyFw &p1, KPolyFw &p2);
void PolyMul(KPolyFw &result, KPolyFw &p1, KPolyFw &p2, KPolyFw &p3);



// ************************************** N-bit Key and M-bit Iv **************************************
class xTermFw
{
private:
    int deg = 0;
    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:

    // for model128/192, 15*32-bit Iv + 5*32-bit Key; 
    uint32_t pterm[30] = {0};

    void setdeg(int n)
    {
        if (n < 0)
            deg = 0;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    bool is_one() const 
    {
        if (deg != 0)
            return false;

        uint32_t ttmp = 0;
        for (int i = 0; i < 30; i++)
            ttmp |= pterm[i];
        return (ttmp == 0);
    }

    bool is_const() const 
    {
        uint32_t ttmp = 0;
        for (int i = 0; i < 15; i++)
            ttmp |= pterm[i];
        return (ttmp == 0);
    }

    bool is_div( xTermFw& t ) const
    {
        for (int i = 0; i < 30; i++)
            if ( (pterm[i] & t.pterm[i]) != t.pterm[i])
                return false;
        return true;
    }

    bool has_kv() const 
    {
        uint32_t ttmp = 0;
        for (int i = 0; i < 15; i++)
            ttmp |= pterm[i];
        if(!ttmp)
            return false;

        ttmp = 0;
        for (int i = 15; i < 30; i++)
            ttmp |= pterm[i];

        return (ttmp != 0);
    }

    xTermFw& operator=(const xTermFw &p)
    {
        if (this == &p)
            return *this;
        
        for (int i = 0; i < 30; i++)
            this->pterm[i] = p.pterm[i];
        this->deg = p.deg;
        return *this;
    }

    // flag = 0, deg(iv); flag = 1, deg(key, iv);
    int degree(int flag = 0)
    {
        deg = 0;
        if (flag)  // flag = 1: key and iv
            for (int i = 0; i < 30; i++)
                deg += Weight(pterm[i]);
        else    // flag = 0: iv
            for (int i = 0; i < 15; i++)
                deg += Weight(pterm[i]);
        return deg;
    }


    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": ";

        uint32_t temp = 0;
        for (int i = 0; i < 30; i++)
            temp |= pterm[i];

        if ( (deg == 0) && ( temp == 0) )
            fout << '1' << endl;
        else
        {
            for (int i = 0; i < 480; i++)
                if ((pterm[i>>5] >> (0x1f ^ (i&0x1f))) & 1)
                    fout << 'v' << i;
            for (int i = 480; i < 960; i++)
                if ((pterm[i>>5] >> (0x1f ^ (i&0x1f))) & 1)
                    fout << 'k' << i-480;
        }
            
        fout << endl;
        fout.close();
    }
};


class xPolyFw
{
public:
    xTermFw* poly;
    uint32_t Size = 0;

    xPolyFw();
    xPolyFw(uint32_t size);
    xPolyFw(const xPolyFw &p);
    ~xPolyFw();

    bool operator==(const xPolyFw &p);

    xPolyFw & SuperPolyTerm(const int deg);
    xPolyFw & operator=(const xPolyFw &p);
    xPolyFw & PolyCopy(const xPolyFw &p);
    xPolyFw & SetPolyLen(const uint32_t len);
    xPolyFw & XorTerm(const xTermFw &term);
    xPolyFw & Merge(const xPolyFw &p);

    xPolyFw & Clear();
    xPolyFw & RemoveDup();
    void show(int Round, string message = " ");
    void WritePolyToFile(int n, string file, string message = " "); 
    void WritePolyToFile_Simple(string file, string message = " ");
};

xTermFw operator* (const xTermFw &pt1, const xTermFw &pt2);
bool operator< (const xTermFw &p1, const xTermFw &p2);
bool operator<= (const xTermFw &p1, const xTermFw &p2);
bool operator> (const xTermFw &p1, const xTermFw &p2);
bool operator== (const xTermFw &p1, const xTermFw &p2);

void PolyAdd(xPolyFw &result, const xPolyFw &p1, const xPolyFw &p2);
void PolyMul(xPolyFw &result, xPolyFw &p1, xTermFw &pt1);
void PolyMul(xPolyFw &result, xPolyFw &p1, xPolyFw &p2);
void PolyMul(xPolyFw &result, xPolyFw *parr[], int len);
void PolyMul(xPolyFw &result, xPolyFw &p1, xPolyFw &p2, xPolyFw &p3);



// ************************************** Kreyvium,Grain128AEAD N-bit Key and M-bit Iv **************************************
class xTerm
{
private:
    int deg = 0;
    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:

    // for 128/192 model, 20*32-bit Iv + 20*32-bit Key; 
    uint32_t pterm[40] = {0};

    void setdeg(int n)
    {
        if (n < 0)
            deg = 0;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    bool is_one() const 
    {
        if (deg != 0)
            return false;

        uint32_t ttmp = 0;
        for (int i = 0; i < 40; i++)
            ttmp |= pterm[i];
        return (ttmp == 0);
    }

    bool is_const() const 
    {
        uint32_t ttmp = 0;
        for (int i = 0; i < 20; i++)
            ttmp |= pterm[i];
        return (ttmp == 0);
    }

    bool is_div( xTerm& t ) const
    {
        for (int i = 0; i < 40; i++)
            if ( (pterm[i] & t.pterm[i]) != t.pterm[i])
                return false;
        return true;
    }

    bool has_kv() const 
    {
        uint32_t ttmp = 0;
        for (int i = 0; i < 20; i++)
            ttmp |= pterm[i];
        if(!ttmp)
            return false;

        ttmp = 0;
        for (int i = 20; i < 40; i++)
            ttmp |= pterm[i];

        return (ttmp != 0);
    }

    xTerm& operator=(const xTerm &p)
    {
        if (this == &p)
            return *this;
        
        for (int i = 0; i < 40; i++)
            this->pterm[i] = p.pterm[i];
        this->deg = p.deg;
        return *this;
    }

    // flag = 0, deg(iv); flag = 1, deg(key, iv)
    int degree(int flag = 0)
    {
        deg = 0;
        if (flag)  // flag = 1: key and iv
            for (int i = 0; i < 40; i++)
                deg += Weight(pterm[i]);
        else    // flag = 0: iv
            for (int i = 0; i < 20; i++)
                deg += Weight(pterm[i]);
        return deg;
    }


    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": ";

        uint32_t temp = 0;
        for (int i = 0; i < 40; i++)
            temp |= pterm[i];

        if ( (deg == 0) && ( temp == 0) )
            fout << '1' << endl;
        else
        {
            for (int i = 0; i < 640; i++)
                if ((pterm[i>>5] >> (0x1f ^ (i&0x1f))) & 1)
                    fout << 'v' << i;
            for (int i = 640; i < 1280; i++)
                if ((pterm[i>>5] >> (0x1f ^ (i&0x1f))) & 1)
                    fout << 'k' << i-640;
        }
            
        fout << endl;
        fout.close();
    }
};


class xPoly
{
public:
    xTerm* poly;
    uint32_t Size = 0;

    xPoly();
    xPoly(uint32_t size);
    xPoly(const xPoly &p);
    ~xPoly();

    bool operator==(const xPoly &p);

    xPoly operator+(const xPoly &p1) const;
    xPoly operator*(const xPoly &p1) const;
    xPoly operator*(const xTerm &p1) const;
    xPoly & operator=(const xPoly &p);

    xPoly & SuperPolyTerm(const int deg);
    xPoly & PolyCopy(const xPoly &p);
    xPoly & SetPolyLen(const uint32_t len);
    xPoly & XorTerm(const xTerm &term);
    xPoly & AddTerm(const xTerm &term);
    xPoly & Merge(const xPoly &p);

    xPoly & Clear();
    xPoly & RemoveDup();
    void show(int Round, string message = " ");
    void WritePolyToFile(int n, string file, string message = " "); 
    void WritePolyToFile_Simple(string file, string message = " ");
};

xTerm operator* (const xTerm &pt1, const xTerm &pt2);
bool operator< (const xTerm &p1, const xTerm &p2);
bool operator<= (const xTerm &p1, const xTerm &p2);
bool operator> (const xTerm &p1, const xTerm &p2);
bool operator== (const xTerm &p1, const xTerm &p2);

void PolyAdd(xPoly &result, const xPoly &p1, const xPoly &p2);
void PolyMul(xPoly &result, xPoly &p1, xTerm &pt1);
void PolyMul(xPoly &result, xPoly &p1, xPoly &p2);
void PolyMul(xPoly &result, xPoly *parr[], int len);
void PolyMul(xPoly &result, xPoly &p1, xPoly &p2, xPoly &p3);




// ************************************** Grain128AEAD 128-bit s and 128-bit b **************************************

class GTerm
{
private:
    int degk = -1;
    int deg = 0;
    int Coeff = 1;

    int Weight(uint32_t n)
    {
        n = n - ((n >> 1) & 0x55555555);
        n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
        n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
        n = n + (n >> 8);
        n = n + (n >> 16);
        return int(n & 0x0000003f);
    }

public:
    uint32_t pterm[8] = { 0 };  // 4*32-bit b + 4*32-bit s

    int degree()
    {
        deg = 0;
        for (int i = 0; i < 8; i++)
            deg += Weight(pterm[i]);
        return deg;
    }

    void setdegk(int n)
    {
        degk = n;
    }

    int getdegk() const 
    {
        return degk;
    }

    void setdeg(int n)
    {
        if (n >= 256)
            deg = 256;
        else
            deg = n;
    }

    int getdeg() const
    {
        return deg;
    }

    void Adddeg(int n) {
        if (n + deg >= 256)
            deg = 256;
        else
            deg += n;
    }

    bool setCoeff(int n){
        if (n < 0)
            return false;
        Coeff = n;
        return true;
    }

    int getCoeff() const{
        return Coeff;
    }

    void AddCoeffOne(){
        Coeff += 1;
    }

    bool AddCoeff(int n){
        if (n < 0)
            return false;
        Coeff += n;
        return true;
    }

    void write(char file[], string message)
    {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "- " << message << ": ";

        if (deg == 0)
            fout << '1' << endl;
        else
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        fout << 'b' << ((i << 5) + j + 1);
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i+4] >> (31 ^ j)) & 1)
                        fout << 's' << ((i << 5) + j + 1);
        }
        fout << endl;
        fout.close();
    }

    void show(string message = "") {
        if (message != "")
            cout << "- " << message << ": ";

        if (deg == 0)
            cout << '1';
        else
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i] >> (31 ^ j)) & 1)
                        cout << 'b' << ((i << 5) + j + 1);
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 32; j++)
                    if ((pterm[i+4] >> (31 ^ j)) & 1)
                        cout << 's' << ((i << 5) + j + 1);
        }
        cout << endl;
    }

    GTerm& operator=(const GTerm &p)
    {
        if (this == &p)
            return *this;

        for (int i = 0; i < 8; i++)
            this->pterm[i] = p.pterm[i];
        this->deg = p.deg;
        this->degk = p.degk;
        this->Coeff = p.Coeff;
        return *this;
    }

    bool operator!=(const GTerm &p)
    {
        for (int i = 0; i < 8; i++)
            if (pterm[i] != p.pterm[i])
                return true;
        return false;
    }

    int set(int a)
    {
        if ((a < 0) || (a >= 256))
            return false;

        pterm[a >> 5] |= (1 << (31 - (a & 31)));
        return true;
    }

    int set(int a, char c)
    {
        if ((a < 0) || (a >= 128))
            return false;

        if (c == 's'){
            pterm[4 + (a >> 5)] |= (1 << (31 - (a & 31)));
            return true;
        }
        else if (c == 'b') {
            pterm[a >> 5] |= (1 << (31 - (a & 31)));
            return true;
        }
        else
            return false;
    }

    int set(int* a, int len)
    {
        for (int i = 0; i < len; i++)
            if ((a[i] < 0) || (a[i] >= 256))
                continue;
            else
                pterm[a[i] >> 5] |= (1 << (31 - (a[i] & 31)));
        return true;
    }
};

class GPoly
{
private:
    uint32_t Size = 0;

public:
    GTerm* poly;

    GPoly();
    GPoly(uint32_t size);
    GPoly(const GPoly &p);
    ~GPoly();

    uint32_t getSize() const;
    bool setSize(int n);

    void setSize(uint32_t n);
    void clear(); 
    void AddSizeOne();
    void AddTerm(const GTerm& t1);

    GPoly & SetPolyLen(const uint32_t len);

    GPoly & operator=(const GPoly &p);
    GPoly & PolyCopy(const GPoly &p);
    GPoly & MergeSameTerm();
    GPoly & DiscardEvenCoeff();
    GPoly & Merge(const GPoly &p);
 

    void WritePolyToFile(int Round, string file, string message, bool ios_base_flag = 0, uint32_t StartPos = 0);
    void WriteValueToFile(int Round, string file, string message, bool ios_base_flag = 0, uint32_t StartPos = 0);
    void show(int Round, string message = " ");
};

GTerm operator* (const GTerm &pt1, const GTerm &pt2);
bool operator< (const GTerm &p1, const GTerm &p2);
bool operator<= (const GTerm &p1, const GTerm &p2);
bool operator> (const GTerm &p1, const GTerm &p2);
bool operator== (const GTerm &p1, const GTerm &p2);
bool Divisibility(const GTerm &BigP, const GTerm &SmallP);

void PolyAdd(GPoly &result, const GPoly &p1, const GPoly &p2);
void PolyMul(GPoly &result, const GPoly &p1, const GTerm &pt1);
void PolyMul(GPoly &result, const GPoly &p1, const GPoly &p2);
void PolyMul(GPoly &result, const GPoly& p1, const GPoly& p2, GPoly& p3);



// ************************************** KATANn(32, 48, 64) state bits + 80 key bits **************************************
class TTerm
{
private:
	int degk = -1;
	int deg = 0;
	int Coeff = 1;

	int Weight(uint32_t n)
	{
		n = n - ((n >> 1) & 0x55555555);
		n = (n & 0x33333333) + ((n >> 2) & 0x33333333);
		n = (n & 0x0f0f0f0f) + ((n >> 4) & 0x0f0f0f0f);
		n = n + (n >> 8);
		n = n + (n >> 16);
		return int(n & 0x0000003f);
	}

public:
	uint32_t pterm[2 + 16] = { 0 };

	int degree(bool flag = 1) { // flag = 0: degree of iv; flag = 1: degree of iv and key.
		deg = 0; int n = 2 + 16 * flag;
		for (int i = 0; i < n; i++)
			deg += Weight(pterm[i]);
		return deg;
	}

	void setdegk(int n)
	{
		degk = n;
	}

	int getdegk() const
	{
		return degk;
	}

	void setdeg(int n)
	{
		deg = n;
	}

	int getdeg() const
	{
		return deg;
	}

	bool setCoeff(int n)
	{
		if (n < 0)
			return false;
		Coeff = n;
		return true;
	}

	int getCoeff() const
	{
		return Coeff;
	}

	void AddCoeffOne()
	{
		Coeff += 1;
	}

	bool AddCoeff(int n)
	{
		if (n < 0)
			return false;
		Coeff += n;
		return true;
	}

	void write(char file[], string message)
	{
		ofstream fout;
		fout.open(file, ios_base::app);
		fout << "- " << message << ": " << Coeff << '*';

		if (deg == 0)
			fout << '1' << endl;
		else {
			for (int i = 0; i < 2; i++)
				for (int j = 0; j < 32; j++)
					if ((pterm[i] >> (31 ^ j)) & 1)
						fout << 's' << ((i << 5) + j);
			for (int i = 2; i < 18; i++)
				for (int j = 0; j < 32; j++)
					if ((pterm[i] >> (31 ^ j)) & 1)
						fout << 'k' << (((i - 2) << 5) + j);
		}

		fout << endl; fout.close();
	}

	void show(string message)
	{
		cout << "- " << message << ": " << Coeff << '*';

		if (deg == 0)
			cout << '1';
		else {
			for (int i = 0; i < 2; i++)
				for (int j = 0; j < 32; j++)
					if ((pterm[i] >> (31 ^ j)) & 1)
						cout << 's' << ((i << 5) + j);
			for (int i = 2; i < 18; i++)
				for (int j = 0; j < 32; j++)
					if ((pterm[i] >> (31 ^ j)) & 1)
						cout << 'k' << (((i - 2) << 5) + j);
		}
		cout << endl;
	}

	void showvalue(string message)
	{
		cout << "- " << message << ", ( degk = " << degk << ", deg = " << deg << ", Coeff = " << Coeff << "): ";
		for (int i = 0; i < 18; i++)
			cout << "0x" << hex << pterm[i] << " ";
		cout << endl;
	}

	TTerm& operator=(const TTerm &p)
	{
		if (this == &p)
			return *this;

		for (int i = 0; i < 18; i++)
			this->pterm[i] = p.pterm[i];
		this->deg = p.deg;
		this->degk = p.degk;
		this->Coeff = p.Coeff;
		return *this;
	}

	bool operator!=(const TTerm &p)
	{
		for (int i = 0; i < 18; i++)
			if (pterm[i] != p.pterm[i])
				return true;
		return false;
	}

};

class TPoly
{
private:
	uint32_t Size = 0;

public:
	TTerm* poly;

	TPoly();
	TPoly(uint32_t size);
	TPoly(const TPoly &p);
	~TPoly();

	uint32_t getSize() const;
	bool setSize(int n);

	void setSize(uint32_t n);
	void clear();
	void AddSizeOne();
	void AddTerm(const TTerm& t1);

	TPoly & SetPolyLen(const uint32_t len);

	TPoly & operator=(const TPoly &p);
	TPoly operator+(const TPoly &p);
    TPoly operator*(const TTerm &p);
	TPoly operator*(const TPoly &p);

	TPoly & PolyCopy(const TPoly &p);
	TPoly & MergeSameTerm();
	TPoly & DiscardEvenCoeff();
	TPoly & Merge(const TPoly &p);

	void WriteValueToFile(int n, char file[], string message = " ", bool ios_base_flag = 0, uint32_t StartPos = 0);
	void WritePolyToFile(int n, char file[], string message = " ", bool ios_base_flag = 0, uint32_t StartPos = 0);
	void show(int Round, string message = " ");
};

TTerm operator* (const TTerm &pt1, const TTerm &pt2);
bool operator< (const TTerm &p1, const TTerm &p2);
bool operator<= (const TTerm &p1, const TTerm &p2);
bool operator> (const TTerm &p1, const TTerm &p2);
bool operator== (const TTerm &p1, const TTerm &p2);
bool Divisibility(const TTerm &BigP, const TTerm &SmallP);

void PolyAdd(TPoly &result, const TPoly &p1, const TPoly &p2);
void PolyMul(TPoly &result, const TPoly &p1, const TTerm &pt1);
void PolyMul(TPoly &result, const TPoly &p1, const TPoly &p2);
void PolyMul(TPoly &result, const TPoly& p1, const TPoly& p2, const TPoly& p3);



// ----------------------------------------------------------------------------

template <class T>
void quickSort(T s[], int l, int r);

int minint(int arr[], int len);
int maxint(int arr[], int len);

#endif 