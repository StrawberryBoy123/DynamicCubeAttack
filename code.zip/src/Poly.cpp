#include "Poly.h"

// ****************************************************************************
Poly::Poly()
{
    poly = new Term[SIZEBw];
    Size = 0;
}

Poly::Poly(uint32_t size)
{
    poly = new Term[size + 1];
    Size = 0;
}


Poly::Poly(const Poly &p)
{
    Size = p.Size;
    poly = new Term[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}
  
 
Poly & Poly::operator=(const Poly &p)
{
    if (this == &p)
        return *this;
    delete[] poly;
    Size = p.Size;
    poly = new Term [Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
    return *this;
}


Poly & Poly::SetPolyLen(const uint32_t len)
{
    delete [] poly;
    poly = new Term [len +1];
    Size = 0;
    return *this;
}
  

Poly::~Poly()
{
    delete [] poly;
}


Poly & Poly::PolyCopy(const Poly &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


Poly & Poly::MergeSameTerm()
{
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);
    
    uint32_t TempSize = this->Size;
    for (uint32_t pd = 1, pf = 0; pd < TempSize; pd++)
    {
        if (this->poly[pf] == this->poly[pd])
            this->poly[pf].AddCoeff(this->poly[pd].getCoeff());
        else
            this->poly[++pf] = this->poly[pd];
        this->Size = pf + 1;
    }

    return *this;
}


Poly & Poly::DiscardEvenCoeff()
{
    if (this->Size > 1)
        this->MergeSameTerm();

    int Len = this->Size;
    this->Size = 0;

    for (int pr = 0; pr < Len; pr++)
    {
        if (this->poly[pr].getCoeff() & 1)
            this->poly[this->Size++] = this->poly[pr];
    }

    return *this;
}


Poly & Poly::Merge(const Poly &p)
{
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->MergeSameTerm();

    return *this;
}


void Poly::WritePolyToFile(int Round, char file[], string message, bool ios_base_flag, uint32_t StartPos)
{
    ofstream fout;
    if (ios_base_flag == 0)
        fout.open(file, ios_base::app);
    else
        fout.open(file, ios_base::out);

    if (Size <= StartPos)
    {
        fout << "Round_" << Round << " OutPutFunction: " << endl << "# 0" << message << endl;
        fout.close();
        return ;
    }

    fout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg() 
         << ", number of terms = " << Size - StartPos << "; " << message << endl << "- Poly = ";
        
    for (uint32_t pr = StartPos; pr < Size; pr++)
    {
        if (pr > StartPos)
            fout << " + ";

        if (poly[pr].getCoeff() != 1)
            fout << poly[pr].getCoeff() << '*';

        if (poly[pr].getdeg())
        {
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ( (poly[pr].pterm[i] >> (31 ^ j)) & 1 )
                        fout << 's' << ( (i<<5) + j + 1);
        }
        else
            fout << '1';
    }
    fout << endl << endl;
    fout.close();
}


void Poly::WriteValueToFile(int Round, char file[], string message, bool ios_base_flag, uint32_t StartPos)
{
    ofstream fout;
    if (ios_base_flag == 0)
        fout.open(file, ios_base::app);
    else
        fout.open(file, ios_base::out);

    if (Size <= StartPos)
    {
        fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
            << ", number of terms = " << Size << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl << endl;
        fout.close();
        return ;
    }

    fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size - StartPos << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl;
        
    for (uint32_t pr = StartPos; pr < Size; pr++)
    {
        fout << hex << "0x" << poly[pr].getdegk() << " 0x" << poly[pr].getCoeff() << ' ';
        for (int i = 0; i < 9; i++)
            fout << hex << "0x" << poly[pr].pterm[i] << ' ';
        fout << hex << "0x" <<poly[pr].getdeg() << endl;
    }
    fout << endl << endl;
    fout.close();
}


void Poly::show(int Round, string message)
{
    if (Size == 0)
    {
        cout << "Round_" << Round << " OutPutFunction: " << endl << "- 0" << message << endl;
        return ;
    }

    uint32_t length = Size;
    cout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg() 
        << ", number of terms = " << Size << "; " << message << endl << "- Poly = ";
        
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";

        if (poly[pr].getCoeff() != 1)
            cout << poly[pr].getCoeff() << '*';

        if (poly[pr].getdeg())
        {
        for (int i = 0; i < 9; i++)
            for (int j = 0; j < 32; j++)
                if ( (poly[pr].pterm[i] >> (31 ^ j)) & 1 )
                    cout << 's' << ( (i<<5) + j + 1);
        }
        else
            cout << '1';
    }
    cout << endl;
}

uint32_t Poly::getSize() const
{
    return Size;
}

void Poly::setSize(uint32_t n)
{
    Size = n;
}

bool Poly::setSize(int n)
{
    if (n < 0)
        return false;
    Size = n;
    return true;
}

void Poly::clear()
{
    Size = 0;
}

void Poly::AddSizeOne()
{
    Size += 1;
}

void Poly::AddTerm(const Term& t1)
{
    poly[Size++] = t1;
}

void PolyAdd(Poly &result, const Poly &p1, const Poly &p2)
{
    uint32_t len1 = p1.getSize(), len2 = p2.getSize();
    result.clear();

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ( (len1 != 0) && (len2 != 0) )
    {
        uint32_t pt = 0; 
        uint32_t pd = 0;
        while( (pt < len1) && (pd < len2) )
        {
            if (p1.poly[pt] > p2.poly[pd])
                result.AddTerm(p1.poly[pt++]);
            else if (p1.poly[pt] < p2.poly[pd])
                result.AddTerm(p2.poly[pd++]);
            else
            {
                result.poly[result.getSize()] = p1.poly[pt++];
                result.poly[result.getSize()].AddCoeff(p2.poly[pd++].getCoeff());
                result.AddSizeOne();
            }
        }
        for (; pt < len1; pt++)
            result.AddTerm(p1.poly[pt]);
        for (; pd < len2; pd++)
            result.AddTerm(p2.poly[pd]);
    }
}


void PolyMul(Poly &result, const Poly &p1, const Term &pt1)
{
    uint32_t Len = p1.getSize();
    for (uint32_t i = 0; i < Len; i++)
        result.AddTerm(p1.poly[i] * pt1);
}


void PolyMul(Poly &result, const Poly &p1, const Poly &p2)
{
    uint32_t len1 = p1.getSize();
    uint32_t len2 = p2.getSize();
    result.clear();

    if ( (len1 != 0) && (len2 != 0) )
        for (uint32_t pd = 0; pd < len2; pd++)
            PolyMul(result, p1, p2.poly[pd]);

    if (result.getSize() <= 1)
        return;

    result.MergeSameTerm();
}


void PolyMul(Poly &result, const Poly& p1, const Poly& p2, const Poly& p3)
{
    uint32_t TempSize = p1.getSize() * p2.getSize();
    Poly TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}

// Term Order and Operation
Term operator* (const Term &pt1, const Term &pt2)
{
    Term result;
    for (int i = 0; i < 9; i++)
        result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
    result.degree();
    result.setdegk(-1);
    result.setCoeff(pt1.getCoeff() * pt2.getCoeff());
    return result;
}


bool operator< (const Term &p1, const Term &p2)
{

    if (p1.getdegk() > p2.getdegk())
        return true;
    else if (p1.getdegk() < p2.getdegk())
        return false;
    else if (p1.getdeg() < p2.getdeg())
        return true;
    else if (p1.getdeg() > p2.getdeg())
        return false;
    else {
        for (int i = 0; i < 9; i++)
        {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}

bool operator<= (const Term &p1, const Term &p2)
{
    if (p1 > p2)
        return false;
    else
        return true;
}

bool operator> (const Term &p1, const Term &p2)
{
    if (p1.getdegk() < p2.getdegk())
        return true;

    else if (p1.getdegk() > p2.getdegk())
        return false;

    else if (p1.getdeg() > p2.getdeg())
        return true;

    else if (p1.getdeg() < p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 9; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator==(const Term &p1, const Term &p2)
{
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 9; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;
            
    return true;
}


bool Divisibility(const Term &BigP, const Term &SmallP)
{
    if (BigP.getdeg() < SmallP.getdeg())
        return false;

    Term temp;
    for (int i = 0; i < 9; i++)
        temp.pterm[i] = BigP.pterm[i] | SmallP.pterm[i];
    if (temp == BigP)
        return true;
    else
        return false;
}


// ****************************************************************************
PolyFw::PolyFw()
{
    poly = new TermFw[SIZEFw];
    Size = 0;
}

PolyFw::PolyFw(uint32_t size)
{
    poly = new TermFw[size + 1];
    Size = 0;
}

PolyFw::PolyFw(const PolyFw &p)
{
    Size = p.Size;
    poly = new TermFw[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}

PolyFw & PolyFw::operator=(const PolyFw &p)
{
    if (this == &p)
        return *this;
    delete [] poly;
    Size = p.Size;
    poly = new TermFw [Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
    return *this;
}

PolyFw & PolyFw::SetPolyLen(const uint32_t len)
{
    delete [] poly;
    poly = new TermFw [len + 1];
    Size = 0;
    return *this;
}

PolyFw::~PolyFw()
{
    delete [] poly;
}


PolyFw & PolyFw::PolyCopy(const PolyFw &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


PolyFw & PolyFw::SuperPolyTerm(const int deg)
{
    if (this->Size == 0)
        return *this;

    for (uint32_t pd = 0; pd < this->Size; pd++)
        if (this->poly[pd].getdeg() < deg)
        {
            this->Size = pd;
            break;
        }
    return *this;
}


PolyFw & PolyFw::XorTerm(const TermFw &term)
{
    for (uint32_t pd = 0; pd < this->Size; pd++) {
        this->poly[pd].Xor(term);
    }
    return *this;
}

PolyFw & PolyFw::RemoveDup()
{
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);

    uint32_t pd = 0, pf = 0, TempSize = this->Size;
    while (pd < TempSize - 1)
    {
        if (this->poly[pd] == this->poly[pd + 1])
            pd += 2;
        else
            this->poly[pf++] = this->poly[pd++];
    }
    if (pd == TempSize - 1)
        this->poly[pf++] = this->poly[pd];
    this->Size = pf;

    return *this;
}


PolyFw & PolyFw::Merge(const PolyFw &p)
{
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->RemoveDup();

    return *this;
}


void PolyFw::WritePolyToFile(int Round, char file[], string message)
{
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << "Round_" << Round << " Poly with degree = -1, number of terms = 0; "
             << message << endl << "# 0" << endl << endl;
        fout.close();
        return ;
    }

    fout << "Round_" << Round << " Poly with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size << "; " << message << endl << "# ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        
        if (poly[pr].is_one())
            fout << '1';
        else
            for (int i = 0; i < 160; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                    {
                        if (i < 80)
                            fout << 'v' << i;
                        else 
                            fout << 'k' << i - 80;    
                    }    
    }
    fout << endl << endl;
    fout.close();
}


void PolyFw::WritePolyToFile_Simple(char file[], int loc)
{
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << "s" << loc << ": 0" << endl;
        fout.close();
        return;
    }
    
    fout << "s" << loc << ": ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        if (poly[pr].is_one())
            fout << '1';
        else {
            bool flag = false;
            for (int i = 0; i < 160; i++) {
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1)
                {
                    if (flag)
                        fout << "*";
                    flag = true;

                    if (i < 80)
                        fout << 'v' << i;
                    else
                        fout << 'k' << i - 80;
                }
            }
        }
    }
    fout << endl;
    fout.close();
}


void PolyFw::show(int Round, string message)
{
    if (Size == 0)
    {
        cout << "Round_" << Round << " Poly with degree = -1, number of terms = 0 : "
             << message << endl << "# 0" << endl;
        return ;
    }

    cout << "Round_" << Round << " Poly with degree = " 
         << poly[0].getdeg() << ", number of terms = "
         << Size << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";
        if ( poly[pr].is_one() )
            cout << '1';
        else{
            bool flag = false;
            for (int i = 0; i < 160; i++){
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                {
                    if (flag)
                        cout << "*";
                    flag = true;

                    if (i < 80)
                        cout << 'v' << i;
                    else 
                        cout << 'k' << i - 80;    
                }
            }
        }
    }
    cout << endl;
}


void PolyAdd(PolyFw &result, const PolyFw &p1, const PolyFw &p2)
{
    uint32_t len1 = p1.Size, len2 = p2.Size;
    result.Size = 0;

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ( (len1 != 0) && (len2 != 0) )
    {
        uint32_t pt = 0, pd = 0; 
        while( (pt < len1) && (pd < len2) )
        {
            if (p1.poly[pt] > p2.poly[pd])
                result.poly[result.Size++] = p1.poly[pt++];
            else if (p1.poly[pt] < p2.poly[pd])
                result.poly[result.Size++] = p2.poly[pd++];
            else
            {
                pd += 1;
                pt += 1;
            }
        }
        for (; pt < len1; pt++)
            result.poly[result.Size++] = p1.poly[pt];
        for (; pd < len2; pd++)
            result.poly[result.Size++] = p2.poly[pd];
    }
}


void PolyMul(PolyFw &result, PolyFw &p1, TermFw &pt1)
{
    for (uint32_t i = 0; i < p1.Size; i++)
        result.poly[result.Size++] = p1.poly[i] * pt1;
}


void PolyMul(PolyFw &result, PolyFw &p1, PolyFw &p2)
{
    uint32_t len1 = p1.Size;
    uint32_t len2 = p2.Size;
    result.Size = 0;

    if ((len1 == 0) || (len2 == 0))
        return;

    for (uint32_t pd = 0; pd < len2; pd++)
        PolyMul(result, p1, p2.poly[pd]);

    result.RemoveDup();
}


void PolyMul(PolyFw &result, PolyFw& p1, PolyFw& p2, PolyFw& p3)
{
    uint32_t TempSize = p1.Size * p2.Size;
    PolyFw TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}


// Term Order and Operation
TermFw operator* (const TermFw &pt1, const TermFw &pt2)
{
    TermFw result;
    for (int i = 0; i < 5; i++)
        result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
    result.degree();
    return result;
}

bool operator< (const TermFw &p1, const TermFw &p2)
{
    if (p1.getdeg() < p2.getdeg())
        return true;

    else if (p1.getdeg() > p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 5; i++)
        {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}

bool operator<= (const TermFw &p1, const TermFw &p2)
{
    if (p1 > p2)
        return false;
    else
        return true;
}

bool operator> (const TermFw &p1, const TermFw &p2)
{
    if (p1.getdeg() > p2.getdeg())
        return true;

    else if (p1.getdeg() < p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 5; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator== (const TermFw &p1, const TermFw &p2)
{
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 5; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;

    return true;
}


// ************************************** Grain128AEAD 256-bit state **************************************
GPoly::GPoly()
{
    poly = new GTerm[SIZEBw];
    Size = 0;
}

GPoly::GPoly(uint32_t size)
{
    poly = new GTerm[size + 1];
    Size = 0;
}

GPoly::GPoly(const GPoly &p)
{
    Size = p.Size;
    poly = new GTerm[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}

GPoly & GPoly::operator=(const GPoly &p)
{
    if (this == &p)
        return *this;
    delete[] poly;
    Size = p.Size;
    poly = new GTerm[Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
    return *this;
}

GPoly & GPoly::SetPolyLen(const uint32_t len)
{
    delete[] poly;
    poly = new GTerm[len + 1];
    Size = 0;
    return *this;
}

GPoly::~GPoly()
{
    delete[] poly;
}


GPoly & GPoly::PolyCopy(const GPoly &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


GPoly & GPoly::MergeSameTerm()
{
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);
    
    uint32_t TempSize = this->Size;
    for (uint32_t pd = 1, pf = 0; pd < TempSize; pd++)
    {
        if (this->poly[pf] == this->poly[pd])
            this->poly[pf].AddCoeff(this->poly[pd].getCoeff());
        else
            this->poly[++pf] = this->poly[pd];
        this->Size = pf + 1;
    }

    return *this;
}


GPoly & GPoly::DiscardEvenCoeff()
{
    if (this->Size > 1)
        this->MergeSameTerm();

    int Len = this->Size;
    this->Size = 0;

    for (int pr = 0; pr < Len; pr++)
    {
        if (this->poly[pr].getCoeff() & 1)
            this->poly[this->Size++] = this->poly[pr];
    }

    return *this;
}


GPoly & GPoly::Merge(const GPoly &p)
{
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->MergeSameTerm();

    return *this;
}


void GPoly::WritePolyToFile(int Round, string file, string message, bool ios_base_flag, uint32_t StartPos)
{
    ofstream fout;
    if (ios_base_flag == 0)
        fout.open(file, ios_base::app);
    else
        fout.open(file, ios_base::out);

    if (Size <= StartPos)
    {
        fout << "Round_" << Round << " OutPutFunction: " << endl << "# 0" << message << endl;
        fout.close();
        return;
    }

    fout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size - StartPos << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = StartPos; pr < Size; pr++)
    {
        if (pr > StartPos)
            fout << " + ";

        if (poly[pr].getCoeff() != 1)
            fout << poly[pr].getCoeff() << '*';

        if (poly[pr].getdeg())
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        fout << 'b' << ((i << 5) + j);

            for (int i = 4; i < 8; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        fout << 's' << ((i - 4) * 32 + j);
        }
        else
            fout << '1';
    }
    fout << endl << endl;
    fout.close();
}


void GPoly::WriteValueToFile(int Round, string file, string message, bool ios_base_flag, uint32_t StartPos)
{
    ofstream fout;
    if (ios_base_flag == 0)
        fout.open(file, ios_base::app);
    else
        fout.open(file, ios_base::out);

    if (Size <= StartPos)
    {
        fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
            << ", number of terms = " << Size << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl << endl;
        fout.close();
        return;
    }

    fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size - StartPos << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl;

    for (uint32_t pr = StartPos; pr < Size; pr++)
    {
        fout << hex << "0x" << poly[pr].getdegk() << " 0x" << poly[pr].getCoeff() << ' ';
        for (int i = 0; i < 8; i++)
            fout << hex << "0x" << poly[pr].pterm[i] << ' ';
        fout << hex << "0x" << poly[pr].getdeg() << endl;
    }
    fout << endl << endl;
    fout.close();
}


void GPoly::show(int Round, string message)
{
    if (Size == 0)
    {
        cout << "Round_" << Round << " OutPutFunction: " << endl << "- 0" << message << endl;
        return;
    }

    cout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg() << ", number of terms = "
        << Size << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 32; j++)
                if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                    cout << 'b' << ((i << 5) + j + 1);
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 32; j++)
                if ((poly[pr].pterm[i+4] >> (31 ^ j)) & 1)
                    cout << 's' << ((i << 5) + j + 1);
        cout << "(" << poly[pr].getdegk() << ")";
    }
    cout << endl;
}


uint32_t GPoly::getSize() const {
    return Size;
}

void GPoly::setSize(uint32_t n) {
    Size = n;
}

bool GPoly::setSize(int n) {
    if (n < 0)
        return false;
    Size = n;
    return true;
}

void GPoly::clear() {
    Size = 0;
}

void GPoly::AddSizeOne() {
    Size += 1;
}

void GPoly::AddTerm(const GTerm& t1) {
    poly[Size++] = t1;
}


void PolyAdd(GPoly &result, const GPoly &p1, const GPoly &p2)
{
    uint32_t len1 = p1.getSize();
    uint32_t len2 = p2.getSize();

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ((len1 != 0) && (len2 != 0))
    {
        uint32_t pt = 0, pd = 0;
        while ((pt < len1) && (pd < len2))
        {
            if (p1.poly[pt] > p2.poly[pd])
                result.AddTerm(p1.poly[pt++]);
            else if (p1.poly[pt] < p2.poly[pd])
                result.AddTerm(p2.poly[pd++]);
            else
            {
                result.poly[result.getSize()] = p1.poly[pt++];
                result.poly[result.getSize()].AddCoeff(p2.poly[pd++].getCoeff());
                result.AddSizeOne();
            }
        }
        for (; pt < len1; pt++)
            result.AddTerm(p1.poly[pt]);
        for (; pd < len2; pd++)
            result.AddTerm(p2.poly[pd]);
    }
}


void PolyMul(GPoly &result, const GPoly &p1, const GTerm &pt1)
{
    uint32_t Len = p1.getSize();
    for (uint32_t i = 0; i < Len; i++)
        result.AddTerm(p1.poly[i] * pt1);
}


void PolyMul(GPoly &result, const GPoly &p1, const GPoly &p2)
{
    uint32_t len1 = p1.getSize();
    uint32_t len2 = p2.getSize();
    result.clear();

    if ((len1 != 0) && (len2 != 0))
        for (uint32_t pd = 0; pd < len2; pd++)
            PolyMul(result, p1, p2.poly[pd]);

    if (result.getSize() <= 1)
        return;

    result.MergeSameTerm();
}


void PolyMul(GPoly &result, const GPoly& p1, const GPoly& p2, const GPoly& p3)
{
    uint32_t TempSize = p1.getSize() * p2.getSize();
    GPoly TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}


// Term Order and Operation
GTerm operator* (const GTerm &pt1, const GTerm &pt2)
{
    GTerm result;
    if (pt1.getdeg() == 0)
        result = pt2;
    else if (pt2.getdeg() == 0)
        result = pt1;
    else
    {
        for (int i = 0; i < 8; i++)
            result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
        result.degree();
        result.setdegk(-1);
        result.setCoeff(pt1.getCoeff() * pt2.getCoeff());
    }
    return result;
}


bool operator< (const GTerm &p1, const GTerm &p2)
{
    if (p1.getdegk() > p2.getdegk())
        return true;
    else if (p1.getdegk() < p2.getdegk())
        return false;
    else if (p1.getdeg() < p2.getdeg())
        return true;
    else if (p1.getdeg() > p2.getdeg())
        return false;
    else {
        for (int i = 0; i < 8; i++) {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator<= (const GTerm &p1, const GTerm &p2)
{
    if (p1 > p2)
        return false;
    else
        return true;
}


bool operator> (const GTerm &p1, const GTerm &p2)
{

    if (p1.getdegk() < p2.getdegk())
        return true;
    else if (p1.getdegk() > p2.getdegk())
        return false;
    else if (p1.getdeg() > p2.getdeg())
        return true;
    else if (p1.getdeg() < p2.getdeg())
        return false;
    else {
        for (int i = 0; i < 8; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator==(const GTerm &p1, const GTerm &p2)
{
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 8; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;

    return true;
}


bool Divisibility(const GTerm &BigP, const GTerm &SmallP)
{
    if (BigP.getdeg() < SmallP.getdeg())
        return false;

    GTerm temp;
    for (int i = 0; i < 8; i++)
        temp.pterm[i] = BigP.pterm[i] | SmallP.pterm[i];
    if (temp == BigP)
        return true;
    else
        return false;
}



// ************************************** 288-bit state **************************************
KPoly::KPoly()
{
    poly = new KTerm[SIZEBw];
    Size = 0;
}

KPoly::KPoly(uint32_t size)
{
    poly = new KTerm[size + 1];
    Size = 0;
}


KPoly::KPoly(const KPoly &p)
{
    Size = p.Size;
    poly = new KTerm[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}


KPoly & KPoly::operator=(const KPoly &p)
{
    if (this == &p)
        return *this;
    delete[] poly;
    Size = p.Size;
    poly = new KTerm[Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
    return *this;
}


KPoly & KPoly::SetPolyLen(const uint32_t len)
{
    delete[] poly;
    poly = new KTerm[len + 1];
    Size = 0;
    return *this;
}


KPoly::~KPoly()
{
    delete[] poly;
}


KPoly & KPoly::PolyCopy(const KPoly &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


KPoly & KPoly::MergeSameTerm()
{
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);
    
    uint32_t TempSize = this->Size;
    for (uint32_t pd = 1, pf = 0; pd < TempSize; pd++)
    {
        if (this->poly[pf] == this->poly[pd])
            this->poly[pf].AddCoeff(this->poly[pd].getCoeff());
        else
            this->poly[++pf] = this->poly[pd];
        this->Size = pf + 1;
    }

    return *this;
}


KPoly & KPoly::DiscardEvenCoeff()
{
    if (this->Size > 1)
        this->MergeSameTerm();

    int Len = this->Size;
    this->Size = 0;

    for (int pr = 0; pr < Len; pr++)
    {
        if (this->poly[pr].getCoeff() & 1)
            this->poly[this->Size++] = this->poly[pr];
    }

    return *this;
}


KPoly & KPoly::Merge(const KPoly &p)
{
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->MergeSameTerm();

    return *this;
}


void KPoly::WritePolyToFile(int Round, char file[], string message, bool ios_base_flag, uint32_t StartPos)
{
    ofstream fout;
    if (ios_base_flag == 0)
        fout.open(file, ios_base::app);
    else
        fout.open(file, ios_base::out);

    if (Size <= StartPos)
    {
        fout << "Round_" << Round << " OutPutFunction: " << endl << "# 0" << message << endl;
        fout.close();
        return;
    }

    fout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size - StartPos << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = StartPos; pr < Size; pr++)
    {
        if (pr > StartPos)
            fout << " + ";

        if (poly[pr].getCoeff() != 1)
            fout << poly[pr].getCoeff() << '*';

        if (poly[pr].getdeg())
        {
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        fout << 's' << ((i << 5) + j + 1);
            for (int i = 9; i < 13; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        fout << 'v' << ((i - 9) * 32 + j);
            for (int i = 13; i < 17; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        fout << 'k' << ((i - 13) * 32 + j);
        }
        else
            fout << '1';
    }
    fout << endl << endl;
    fout.close();
}


void KPoly::WriteValueToFile(int Round, char file[], string message, bool ios_base_flag, uint32_t StartPos)
{
    ofstream fout;
    if (ios_base_flag == 0)
        fout.open(file, ios_base::app);
    else
        fout.open(file, ios_base::out);

    if (Size <= StartPos)
    {
        fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
            << ", number of terms = " << Size << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl << endl;
        fout.close();
        return;
    }

    fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size - StartPos << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl;

    for (uint32_t pr = StartPos; pr < Size; pr++)
    {
        fout << hex << "0x" << poly[pr].getdegk() << " 0x" << poly[pr].getCoeff() << ' ';
        for (int i = 0; i < 17; i++)
            fout << hex << "0x" << poly[pr].pterm[i] << ' ';
        fout << hex << "0x" << poly[pr].getdeg() << endl;
    }
    fout << endl << endl;
    fout.close();
}


void KPoly::show(int Round, string message)
{
    if (Size == 0)
    {
        cout << "Round_" << Round << " OutPutFunction: " << endl << "- 0" << message << endl;
        return;
    }

    cout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";

        if (poly[pr].getCoeff() != 1)
            cout << poly[pr].getCoeff() << '*';

        if (poly[pr].getdeg())
        {
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        cout << 's' << ((i << 5) + j + 1);
            for (int i = 9; i < 13; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        cout << 'v' << ((i - 9) * 32 + j);
            for (int i = 13; i < 17; i++)
                for (int j = 0; j < 32; j++)
                    if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
                        cout << 'k' << ((i - 13) * 32 + j);
        }
        else
            cout << '1';
    }
    cout << endl;
}

uint32_t KPoly::getSize() const
{
    return Size;
}

void KPoly::setSize(uint32_t n)
{
    Size = n;
}

bool KPoly::setSize(int n)
{
    if (n < 0)
        return false;
    Size = n;
    return true;
}

void KPoly::clear()
{
    Size = 0;
}

void KPoly::AddSizeOne()
{
    Size += 1;
}

void KPoly::AddTerm(const KTerm& t1)
{
    poly[Size++] = t1;
}

void PolyAdd(KPoly &result, const KPoly &p1, const KPoly &p2)
{
    uint32_t len1 = p1.getSize(), len2 = p2.getSize();
    result.clear();

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ((len1 != 0) && (len2 != 0))
    {
        uint32_t pt = 0, pd = 0;
        while ((pt < len1) && (pd < len2))
        {
            if (p1.poly[pt] > p2.poly[pd])
                result.AddTerm(p1.poly[pt++]);
            else if (p1.poly[pt] < p2.poly[pd])
                result.AddTerm(p2.poly[pd++]);
            else
            {
                result.poly[result.getSize()] = p1.poly[pt++];
                result.poly[result.getSize()].AddCoeff(p2.poly[pd++].getCoeff());
                result.AddSizeOne();
            }
        }
        for (; pt < len1; pt++)
            result.AddTerm(p1.poly[pt]);
        for (; pd < len2; pd++)
            result.AddTerm(p2.poly[pd]);
    }
}


void PolyMul(KPoly &result, const KPoly &p1, const KTerm &pt1)
{
    uint32_t Len = p1.getSize();
    for (uint32_t i = 0; i < Len; i++)
        result.AddTerm(p1.poly[i] * pt1);
}


void PolyMul(KPoly &result, const KPoly &p1, const KPoly &p2)
{
    uint32_t len1 = p1.getSize();
    uint32_t len2 = p2.getSize();
    result.clear();

    if ((len1 != 0) && (len2 != 0))
        for (uint32_t pd = 0; pd < len2; pd++)
            PolyMul(result, p1, p2.poly[pd]);

    if (result.getSize() <= 1)
        return;

    result.MergeSameTerm();
}


void PolyMul(KPoly &result, const KPoly& p1, const KPoly& p2, const KPoly& p3)
{
    uint32_t TempSize = p1.getSize() * p2.getSize();
    KPoly TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}


// Term Order and Operation
KTerm operator* (const KTerm &pt1, const KTerm &pt2)
{
    KTerm result;
    for (int i = 0; i < 17; i++)
        result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
    result.degree();
    result.setdegk(-1);
    result.setCoeff(pt1.getCoeff() * pt2.getCoeff());
    return result;
}


bool operator< (const KTerm &p1, const KTerm &p2)
{
    if (p1.getdegk() > p2.getdegk())
        return true;
    else if (p1.getdegk() < p2.getdegk())
        return false;
    else if (p1.getdeg() < p2.getdeg())
        return true;
    else if (p1.getdeg() > p2.getdeg())
        return false;
    else {
        for (int i = 0; i < 17; i++) {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator<= (const KTerm &p1, const KTerm &p2)
{
    if (p1 > p2)
        return false;
    else
        return true;
}


bool operator> (const KTerm &p1, const KTerm &p2)
{
    if (p1.getdegk() < p2.getdegk())
        return true;

    else if (p1.getdegk() > p2.getdegk())
        return false;

    else if (p1.getdeg() > p2.getdeg())
        return true;

    else if (p1.getdeg() < p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 17; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator==(const KTerm &p1, const KTerm &p2)
{
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 17; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;

    return true;
}


bool Divisibility(const KTerm &BigP, const KTerm &SmallP)
{
    if (BigP.getdeg() < SmallP.getdeg())
        return false;

    KTerm temp;
    for (int i = 0; i < 17; i++)
        temp.pterm[i] = BigP.pterm[i] | SmallP.pterm[i];
    if (temp == BigP)
        return true;
    else
        return false;
}



// ************************************** 160-bit Key and Iv **************************************
KPolyFw::KPolyFw()
{
    poly = new KTermFw[SIZEFw];
    Size = 0;
}

KPolyFw::KPolyFw(uint32_t size)
{
    poly = new KTermFw[size + 1];
    Size = 0;
}

KPolyFw::KPolyFw(const KPolyFw &p)
{
    Size = p.Size;
    poly = new KTermFw[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}

KPolyFw & KPolyFw::operator=(const KPolyFw &p)
{
    if (this == &p)
        return *this;
    delete[] poly;
    Size = p.Size;
    poly = new KTermFw[Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
    return *this;
}

KPolyFw & KPolyFw::SetPolyLen(const uint32_t len)
{
    delete[] poly;
    poly = new KTermFw[len + 1];
    Size = 0;
    return *this;
}

KPolyFw::~KPolyFw()
{
    delete[] poly;
}


KPolyFw & KPolyFw::PolyCopy(const KPolyFw &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


KPolyFw & KPolyFw::SuperPolyTerm(const int deg)
{
    if (this->Size == 0)
        return *this;

    for (uint32_t pd = 0; pd < this->Size; pd++)
        if (this->poly[pd].getdeg() < deg)
        {
            this->Size = pd;
            break;
        }
    return *this;
}


KPolyFw & KPolyFw::XorTerm(const KTermFw &term)
{
    for (uint32_t pd = 0; pd < this->Size; pd++)
        this->poly[pd].Xor(term);
    return *this;
}


KPolyFw & KPolyFw::RemoveDup()
{
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);
    
    uint32_t pd = 0, pf = 0, TempSize = this->Size;
    while (pd < TempSize - 1)
    {
        if (this->poly[pd] == this->poly[pd + 1])
            pd += 2;
        else
            this->poly[pf++] = this->poly[pd++];
    }
    if (pd == TempSize - 1)
        this->poly[pf++] = this->poly[pd];
    this->Size = pf;

    return *this;
}


KPolyFw & KPolyFw::Merge(const KPolyFw &p)
{
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->RemoveDup();

    return *this;
}


void KPolyFw::WritePolyToFile(int Round, char file[], string message)
{
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << "Round_" << Round << " Poly with degree = -1, number of terms = 0; "
            << message << endl << "# 0" << endl << endl;
        fout.close();
        return;
    }

    fout << "Round_" << Round << " Poly with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size << "; " << message << endl << "# ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        if (poly[pr].is_one())
            fout << '1';
        else
            for (int i = 0; i < 256; i++)
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1)
                {
                    if (i < 128)
                        fout << 'v' << i;
                    else
                        fout << 'k' << i - 128;
                }
    }
    fout << endl << endl;
    fout.close();
}


void KPolyFw::WritePolyToFile_Simple(char file[], int loc)
{
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << "s" << loc << ": 0" << endl;
        fout.close();
        return;
    }

    fout << "s" << loc << ": ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        if (poly[pr].is_one())
            fout << '1';
        else{
            bool flag = false;
            for (int i = 0; i < 256; i++){
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1)
                {
                    if (flag)
                        fout << "*";
                    flag = true;

                    if (i < 128)
                        fout << 'v' << i;
                    else
                        fout << 'k' << i - 128;
                }
            }
        }
    }
    fout << endl;
    fout.close();
}


void KPolyFw::show(int Round, string message)
{
    if (Size == 0)
    {
        cout << "Round_" << Round << " Poly with degree = -1, number of terms = 0 : "
            << message << endl << "# 0" << endl;
        return;
    }

    cout << "Round_" << Round << " Poly with degree = "
         << poly[0].getdeg() << ", number of terms = "
         << Size << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";
        if (poly[pr].is_one())
            cout << '1';
        else{
            bool flag = false;
            for (int i = 0; i < 256; i++){
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1)
                {
                    if (flag)
                        cout << "*";
                    flag = true;

                    if (i < 128)
                        cout << 'v' << i;
                    else
                        cout << 'k' << i - 128;
                }
            }
        }
    }
    cout << endl;
}


void PolyAdd(KPolyFw &result, const KPolyFw &p1, const KPolyFw &p2)
{
    uint32_t len1 = p1.Size, len2 = p2.Size;
    result.Size = 0;

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ((len1 != 0) && (len2 != 0))
    {
        uint32_t pt = 0, pd = 0;
        while ((pt < len1) && (pd < len2))
        {
            if (p1.poly[pt] > p2.poly[pd])
                result.poly[result.Size++] = p1.poly[pt++];
            else if (p1.poly[pt] < p2.poly[pd])
                result.poly[result.Size++] = p2.poly[pd++];
            else
            {
                pd += 1;
                pt += 1;
            }
        }
        for (; pt < len1; pt++)
            result.poly[result.Size++] = p1.poly[pt];
        for (; pd < len2; pd++)
            result.poly[result.Size++] = p2.poly[pd];
    }
}


void PolyAdd(KPolyFw &result, KPolyFw **ps, int len)
{
    result.Size = 0;
    if (len <= 0)
        return;

    for (int i = 0; i < len; i++)
        result.Merge(*(ps[i]));
    result.RemoveDup();
}


void PolyMul(KPolyFw &result, KPolyFw &p1, KTermFw &pt1)
{
    for (uint32_t i = 0; i < p1.Size; i++)
        result.poly[result.Size++] = p1.poly[i] * pt1;
}


void PolyMul(KPolyFw &result, KPolyFw &p1, KPolyFw &p2)
{
    uint32_t len1 = p1.Size;
    uint32_t len2 = p2.Size;
    result.Size = 0;

    if ((len1 == 0) || (len2 == 0))
        return;

    for (uint32_t pd = 0; pd < len2; pd++)
        PolyMul(result, p1, p2.poly[pd]);

    result.RemoveDup();
}


void PolyMul(KPolyFw &result, KPolyFw& p1, KPolyFw& p2, KPolyFw& p3)
{
    uint32_t TempSize = p1.Size * p2.Size;
    KPolyFw TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}


// Term Order and Operation
KTermFw operator* (const KTermFw &pt1, const KTermFw &pt2)
{
    KTermFw result;
    for (int i = 0; i < 8; i++)
        result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
    result.degree();
    return result;
}


bool operator< (const KTermFw &p1, const KTermFw &p2)
{
    if (p1.getdeg() < p2.getdeg())
        return true;

    else if (p1.getdeg() > p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 8; i++)
        {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator<= (const KTermFw &p1, const KTermFw &p2)
{
    if (p1 > p2)
        return false;
    else
        return true;
}


bool operator> (const KTermFw &p1, const KTermFw &p2)
{
    if (p1.getdeg() > p2.getdeg())
        return true;

    else if (p1.getdeg() < p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 8; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator== (const KTermFw &p1, const KTermFw &p2)
{
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 8; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;

    return true;
}



// ************************************** N-bit Key and M-bit Iv **************************************
xPolyFw::xPolyFw()
{
    poly = new xTermFw[xSIZEFw];
    Size = 0;
}

xPolyFw::xPolyFw(uint32_t size)
{
    poly = new xTermFw[size + 1];
    Size = 0;
}

xPolyFw::xPolyFw(const xPolyFw &p)
{
    Size = p.Size;
    poly = new xTermFw[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}


bool xPolyFw::operator==(const xPolyFw &p) {
    if (Size != p.Size)
        return false;
    
    for (int i = 0; i < Size; i++)
        if (poly[i] == p.poly[i])
            continue;
        else
            return false;
    return true;
}


xPolyFw & xPolyFw::operator=(const xPolyFw &p)
{
    if (this == &p)
        return *this;
    delete [] poly;
    Size = p.Size;
    poly = new xTermFw [Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
            
    return *this;
}

xPolyFw & xPolyFw::SetPolyLen(const uint32_t len)
{
    delete [] poly;
    poly = new xTermFw [len + 1];
    Size = 0;
    return *this;
}

xPolyFw::~xPolyFw()
{
    delete [] poly;
}


xPolyFw & xPolyFw::PolyCopy(const xPolyFw &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


xPolyFw & xPolyFw::SuperPolyTerm(const int deg)
{
    if (this->Size == 0)
        return *this;

    for (uint32_t pd = 0; pd < this->Size; pd++)
        if (this->poly[pd].getdeg() < deg)
        {
            this->Size = pd;
            break;
        }
    return *this;
}


xPolyFw & xPolyFw::XorTerm(const xTermFw &term)
{
    for (uint32_t pd = 0; pd < this->Size; pd++)
    {
        for (uint8_t pt = 0; pt < 30; pt++)
            this->poly[pd].pterm[pt] ^= term.pterm[pt];
        this->poly[pd].degree();
    }
    return *this;
}


xPolyFw & xPolyFw::RemoveDup()
{
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);
    
    uint32_t pd = 0, pf = 0, TempSize = this->Size;
    while (pd < TempSize - 1)
    {
        if (this->poly[pd] == this->poly[pd + 1])
            pd += 2;
        else
            this->poly[pf++] = this->poly[pd++];
    }
    if (pd == TempSize - 1)
        this->poly[pf++] = this->poly[pd];
    this->Size = pf;

    return *this;
}


xPolyFw & xPolyFw::Merge(const xPolyFw &p)
{
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->RemoveDup();

    return *this;
}


xPolyFw & xPolyFw::Clear()
{
    xTermFw temp;
    for (int i = 0; i < Size; i++)
        this->poly[i] = temp;
    this->Size = 0;

    return *this;
}


void xPolyFw::WritePolyToFile(int Round, string file, string message)
{
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << "Round_" << Round << " Poly with degree = -1, number of terms = 0; "
             << message << endl << "# 0" << endl << endl;
        fout.close();
        return ;
    }

    fout << "Round_" << Round << " Poly with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size << "; " << message << endl << "# ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        
        uint32_t ttmp = 0;
        for (int i = 0; i < 30; i++)
            ttmp |= poly[pr].pterm[i];

        if ( (poly[pr].getdeg() == 0) && ( ttmp == 0 ) )
            fout << '1';
        else
        {
            bool flag = false;
            for (int i = 0; i < 480; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                {
                    if (flag)
                        fout << '*';
                    fout << 'v' << i;
                    flag = true;
                }
            for (int i = 480; i < 960; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                {
                    if (flag)
                        fout << '*';
                    fout << 'k' << i-480;
                    flag = true;
                }
        }
    }
    fout << endl << endl;
    fout.close();
}


void xPolyFw::WritePolyToFile_Simple(string file, string message)
{
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << message << ": 0" << endl;
        fout.close();
        return;
    }
    
    fout << message << ": ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        if (poly[pr].is_one())
            fout << '1';
        else
        {
            bool flag = false;
            for (int i = 0; i < 480; i++)
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1){
                    if (flag)
                        fout << "*";
                    fout << 'v' << i;
                    flag = true;
                }
            for (int i = 480; i < 960; i++)
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1){
                    if (flag)
                        fout << "*";
                    fout << 'k' << i-480;
                    flag = true;
                }
        }
    }
    fout << endl;
    fout.close();
}


void xPolyFw::show(int Round, string message)
{
    if (Size == 0)
    {
        cout << "Round_" << Round << " Poly with degree = -1, number of terms = 0 : "
             << message << endl << "# 0" << endl;
        return ;
    }

    cout << "Round_" << Round << " Poly with degree = " 
            << poly[0].getdeg() << ", number of terms = "
            << Size << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";
        if ( poly[pr].is_one() )
            cout << '1';
        else
        {
            for (int i = 0; i < 480; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                    cout << 'v' << i;
            for (int i = 480; i < 960; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                    cout << 'k' << i-480;
        }    
    }
    cout << endl;
}


void PolyAdd(xPolyFw &result, const xPolyFw &p1, const xPolyFw &p2)
{
    uint32_t len1 = p1.Size, len2 = p2.Size;
    result.Size = 0;

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ( (len1 != 0) && (len2 != 0) )
    {
        uint32_t pt = 0, pd = 0; 
        while( (pt < len1) && (pd < len2) )
        {
            if (p1.poly[pt] > p2.poly[pd])
                result.poly[result.Size++] = p1.poly[pt++];
            else if (p1.poly[pt] < p2.poly[pd])
                result.poly[result.Size++] = p2.poly[pd++];
            else
            {
                pd += 1;
                pt += 1;
            }
        }
        for (; pt < len1; pt++)
            result.poly[result.Size++] = p1.poly[pt];
        for (; pd < len2; pd++)
            result.poly[result.Size++] = p2.poly[pd];
    }
}


void PolyMul(xPolyFw &result, xPolyFw &p1, xTermFw &pt1)
{
    for (uint32_t i = 0; i < p1.Size; i++)
        result.poly[result.Size++] = p1.poly[i] * pt1;
}


void PolyMul(xPolyFw &result, xPolyFw &p1, xPolyFw &p2)
{
    uint32_t len1 = p1.Size;
    uint32_t len2 = p2.Size;
    result.Size = 0;

    if ((len1 == 0) || (len2 == 0))
        return;

    for (uint32_t pd = 0; pd < len2; pd++)
        PolyMul(result, p1, p2.poly[pd]);

    result.RemoveDup();
}


void PolyMul(xPolyFw &result, xPolyFw& p1, xPolyFw& p2, xPolyFw& p3)
{
    uint32_t TempSize = p1.Size * p2.Size;
    xPolyFw TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}


void PolyMul(xPolyFw &result, xPolyFw *parr[], int len)
{
    result.Clear();
    if (len < 1)
        return ;
    else if (len == 1){
        result.PolyCopy(*parr[0]);
        return ;
    }
    else if (len == 2){
        PolyMul(result, *parr[0], *parr[1]);
        return ;
    }

    uint32_t TempSize = 1;
    for (int i = 0; i < len; i++)
        TempSize *= parr[i]->Size;

    xPolyFw InPoly(TempSize), OutPoly(TempSize);
    InPoly.PolyCopy(*parr[0]);
    xPolyFw *InPt = &InPoly;
    xPolyFw *OutPt = &OutPoly;
    xPolyFw *TmpPt = InPt;

    for (int i = 1; i < len; i++){
        PolyMul(*OutPt, *InPt, *parr[i]);
        TmpPt = InPt;
        InPt = OutPt;
        OutPt = TmpPt;
    }

    result.PolyCopy(*InPt);
}


// Term Order and Operation
xTermFw operator* (const xTermFw &pt1, const xTermFw &pt2)
{
    xTermFw result;
    for (int i = 0; i < 30; i++)
        result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
    result.degree();
    return result;
}

bool operator< (const xTermFw &p1, const xTermFw &p2)
{
    if (p1.getdeg() < p2.getdeg())
        return true;

    else if (p1.getdeg() > p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 30; i++)
        {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}

bool operator<= (const xTermFw &p1, const xTermFw &p2)
{
    if (p1 > p2)
        return false;
    else
        return true;
}

bool operator> (const xTermFw &p1, const xTermFw &p2)
{
    if (p1.getdeg() > p2.getdeg())
        return true;

    else if (p1.getdeg() < p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 30; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator== (const xTermFw &p1, const xTermFw &p2)
{
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 30; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;

    return true;
}




// ************************************** Kreyvium N-bit Key and M-bit Iv **************************************
xPoly::xPoly()
{
    poly = new xTerm[xSIZEFw];
    Size = 0;
}

xPoly::xPoly(uint32_t size)
{
    poly = new xTerm[size + 1];
    Size = 0;
}

xPoly::xPoly(const xPoly &p)
{
    Size = p.Size;
    poly = new xTerm[Size + 1];
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
}


bool xPoly::operator==(const xPoly &p) {
    if (Size != p.Size)
        return false;
    
    for (int i = 0; i < Size; i++)
        if (poly[i] == p.poly[i])
            continue;
        else
            return false;
    return true;
}


xPoly & xPoly::operator=(const xPoly &p)
{
    if (this == &p)
        return *this;
    delete [] poly;
    Size = p.Size;
    poly = new xTerm [Size + 1];

    if (Size != 0)
        for (uint32_t pd = 0; pd < Size; pd++)
            poly[pd] = p.poly[pd];
    
    return *this;
}

xPoly & xPoly::SetPolyLen(const uint32_t len)
{
    delete [] poly;
    poly = new xTerm [len + 1];
    Size = 0;
    return *this;
}

xPoly::~xPoly()
{
    delete [] poly;
}


xPoly & xPoly::PolyCopy(const xPoly &p)
{
    if (this == &p)
        return *this;
    Size = p.Size;
    for (uint32_t pd = 0; pd < Size; pd++)
        poly[pd] = p.poly[pd];
    return *this;
}


xPoly & xPoly::SuperPolyTerm(const int deg)
{
    if (this->Size == 0)
        return *this;

    for (uint32_t pd = 0; pd < this->Size; pd++)
        if (this->poly[pd].getdeg() < deg)
        {
            this->Size = pd;
            break;
        }
    return *this;
}


xPoly & xPoly::XorTerm(const xTerm &term) {
    for (uint32_t pd = 0; pd < this->Size; pd++)
    {
        for (uint8_t pt = 0; pt < 40; pt++)
            this->poly[pd].pterm[pt] ^= term.pterm[pt];
        this->poly[pd].degree();
    }
    return *this;
}


xPoly & xPoly::AddTerm(const xTerm &term) {
    poly[Size++] = term;
    return *this;
}


xPoly & xPoly::RemoveDup() {
    if (this->Size <= 1)
        return *this;

    quickSort(this->poly, 0, int(this->Size) - 1);
    
    uint32_t pd = 0, pf = 0, TempSize = this->Size;
    while (pd < TempSize - 1)
    {
        if (this->poly[pd] == this->poly[pd + 1])
            pd += 2;
        else
            this->poly[pf++] = this->poly[pd++];
    }
    if (pd == TempSize - 1)
        this->poly[pf++] = this->poly[pd];
    this->Size = pf;

    return *this;
}


xPoly & xPoly::Merge(const xPoly &p) {
    if (p.Size == 0)
        return *this;

    for (uint32_t i = 0; i < p.Size; i++)
        this->poly[this->Size++] = p.poly[i];
    this->RemoveDup();

    return *this;
}


xPoly & xPoly::Clear() {
    xTerm temp;
    for (int i = 0; i < Size; i++)
        this->poly[i] = temp;
    this->Size = 0;

    return *this;
}


xPoly xPoly::operator+(const xPoly &p1) const {
    xPoly result;
    uint32_t len1 = p1.Size, len2 = Size;
    result.Size = 0;

    if (len1 == 0)
        result.Merge(*this);
    else if (len2 == 0)
        result.Merge(p1);
    else if ((len1 != 0) && (len2 != 0))
    {
        uint32_t pt = 0, pd = 0;
        while ((pt < len1) && (pd < len2))
        {
            if (p1.poly[pt] > this->poly[pd])
                result.poly[result.Size++] = p1.poly[pt++];
            else if (p1.poly[pt] < this->poly[pd])
                result.poly[result.Size++] = this->poly[pd++];
            else
            {
                pd += 1;
                pt += 1;
            }
        }
        for (; pt < len1; pt++)
            result.poly[result.Size++] = p1.poly[pt];
        for (; pd < len2; pd++)
            result.poly[result.Size++] = this->poly[pd];
    }
    return result;
}


xPoly xPoly::operator*(const xTerm &pt) const {
    xPoly result;
    for (uint32_t i = 0; i < Size; i++)
        result.poly[result.Size++] = poly[i] * pt;
    return result;
}


xPoly xPoly::operator*(const xPoly &p1) const {
    xPoly result;
    uint32_t len1 = p1.Size;
    uint32_t len2 = Size;

    if ((len1 == 0) || (len2 == 0))
        return result;

    for (uint32_t pd = 0; pd < len2; pd++)
        result.Merge(p1*poly[pd]);
    return result;
}


void xPoly::WritePolyToFile(int Round, string file, string message) {
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0)
    {
        fout << "Round_" << Round << " Poly with degree = -1, number of terms = 0; "
             << message << endl << "# 0" << endl << endl;
        fout.close();
        return ;
    }

    fout << "Round_" << Round << " Poly with degree = " << poly[0].getdeg()
        << ", number of terms = " << Size << "; " << message << endl << "# ";
    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            fout << " + ";
        
        if (poly[pr].is_one())
            fout << '1';
        else
        {
            bool flag = false;
            for (int i = 0; i < 640; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                {
                    if (flag)
                        fout << '*';
                    fout << 'v' << i;
                    flag = true;
                }
            for (int i = 640; i < 1280; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                {
                    if (flag)
                        fout << '*';
                    fout << 'k' << i-640;
                    flag = true;
                }
        }
    }
    fout << endl << endl;
    fout.close();
}


void xPoly::WritePolyToFile_Simple(string file, string message) {
    ofstream fout;
    fout.open(file, ios_base::app);

    if (Size == 0) {
        fout << message << ": 0" << endl;
        fout.close();
        return;
    }
    
    fout << message << ": ";
    for (uint32_t pr = 0; pr < Size; pr++) {
        if (pr)
            fout << " + ";
        if (poly[pr].is_one())
            fout << '1';
        else {
            bool flag = false;
            for (int i = 0; i < 640; i++)
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1){
                    if (flag)
                        fout << "*";
                    fout << 'v' << i;
                    flag = true;
                }
            for (int i = 640; i < 1280; i++)
                if ((poly[pr].pterm[i >> 5] >> (31 ^ (31 & i))) & 1){
                    if (flag)
                        fout << "*";
                    fout << 'k' << i-640;
                    flag = true;
                }
        }
    }
    fout << endl;
    fout.close();
}


void xPoly::show(int Round, string message) {
    if (Size == 0)
    {
        cout << "Round_" << Round << " Poly with degree = -1, number of terms = 0 : "
             << message << endl << "# 0" << endl;
        return ;
    }

    cout << "Round_" << Round << " Poly with degree = " 
            << poly[0].getdeg() << ", number of terms = "
            << Size << "; " << message << endl << "- Poly = ";

    for (uint32_t pr = 0; pr < Size; pr++)
    {
        if (pr)
            cout << " + ";
        if ( poly[pr].is_one() )
            cout << '1';
        else
        {
            for (int i = 0; i < 640; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                    cout << 'v' << i;
            for (int i = 640; i < 1280; i++)
                if ( (poly[pr].pterm[i>>5] >> (31 ^ (31&i))) & 1 )
                    cout << 'k' << i-640;
        }    
    }
    cout << endl;
}


void PolyAdd(xPoly &result, const xPoly &p1, const xPoly &p2) {
    uint32_t len1 = p1.Size, len2 = p2.Size;
    result.Size = 0;

    if (len1 == 0)
        result.Merge(p2);
    else if (len2 == 0)
        result.Merge(p1);
    else if ( (len1 != 0) && (len2 != 0) ) {
        uint32_t pt = 0, pd = 0; 
        while( (pt < len1) && (pd < len2) ) {
            if (p1.poly[pt] > p2.poly[pd])
                result.poly[result.Size++] = p1.poly[pt++];
            else if (p1.poly[pt] < p2.poly[pd])
                result.poly[result.Size++] = p2.poly[pd++];
            else {
                pd += 1;
                pt += 1;
            }
        }
        for (; pt < len1; pt++)
            result.poly[result.Size++] = p1.poly[pt];
        for (; pd < len2; pd++)
            result.poly[result.Size++] = p2.poly[pd];
    }
}


void PolyMul(xPoly &result, xPoly &p1, xTerm &pt1) {
    for (uint32_t i = 0; i < p1.Size; i++)
        result.poly[result.Size++] = p1.poly[i] * pt1;
}


void PolyMul(xPoly &result, xPoly &p1, xPoly &p2) {
    uint32_t len1 = p1.Size;
    uint32_t len2 = p2.Size;
    result.Size = 0;

    if ((len1 == 0) || (len2 == 0))
        return;

    for (uint32_t pd = 0; pd < len2; pd++)
        PolyMul(result, p1, p2.poly[pd]);

    result.RemoveDup();
}


void PolyMul(xPoly &result, xPoly& p1, xPoly& p2, xPoly& p3) {
    uint32_t TempSize = p1.Size * p2.Size;
    xPoly TempPoly(TempSize);
    PolyMul(TempPoly, p1, p2);
    PolyMul(result, TempPoly, p3);
}


void PolyMul(xPoly &result, xPoly *parr[], int len) {
    result.Clear();
    if (len < 1)
        return ;
    else if (len == 1){
        result.PolyCopy(*parr[0]);
        return ;
    }
    else if (len == 2){
        PolyMul(result, *parr[0], *parr[1]);
        return ;
    }

    uint32_t TempSize = 1;
    for (int i = 0; i < len; i++)
        TempSize *= parr[i]->Size;

    xPoly InPoly(TempSize), OutPoly(TempSize);
    InPoly.PolyCopy(*parr[0]);
    xPoly *InPt = &InPoly;
    xPoly *OutPt = &OutPoly;
    xPoly *TmpPt = InPt;

    for (int i = 1; i < len; i++){
        PolyMul(*OutPt, *InPt, *parr[i]);
        TmpPt = InPt;
        InPt = OutPt;
        OutPt = TmpPt;
    }

    result.PolyCopy(*InPt);
}


// Term Order and Operation
xTerm operator* (const xTerm &pt1, const xTerm &pt2) {
    xTerm result;
    for (int i = 0; i < 40; i++)
        result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
    result.degree();
    return result;
}


bool operator< (const xTerm &p1, const xTerm &p2) {
    if (p1.getdeg() < p2.getdeg())
        return true;

    else if (p1.getdeg() > p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 40; i++)
        {
            if (p1.pterm[i] < p2.pterm[i])
                return true;
            else if (p1.pterm[i] > p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator<= (const xTerm &p1, const xTerm &p2) {
    if (p1 > p2)
        return false;
    else
        return true;
}


bool operator> (const xTerm &p1, const xTerm &p2) {
    if (p1.getdeg() > p2.getdeg())
        return true;

    else if (p1.getdeg() < p2.getdeg())
        return false;

    else
    {
        for (int i = 0; i < 40; i++)
        {
            if (p1.pterm[i] > p2.pterm[i])
                return true;
            else if (p1.pterm[i] < p2.pterm[i])
                return false;
        }
    }
    return false;
}


bool operator== (const xTerm &p1, const xTerm &p2) {
    if (p1.getdeg() != p2.getdeg())
        return false;

    for (int i = 0; i < 40; i++)
        if (p1.pterm[i] != p2.pterm[i])
            return false;

    return true;
}



// ************************************** KATANn n state bits and 80 key bits **************************************

TPoly::TPoly()
{
	poly = new TTerm[SIZEBw];
	Size = 0;
}


TPoly::TPoly(uint32_t size)
{
	poly = new TTerm[size + 1];
	Size = 0;
}


TPoly::TPoly(const TPoly &p)
{
	Size = p.Size;
	poly = new TTerm[Size + 1];
	for (uint32_t pd = 0; pd < Size; pd++)
		poly[pd] = p.poly[pd];
}


TPoly & TPoly::operator=(const TPoly &p)
{
	if (this == &p)
		return *this;
	delete[] poly;

	Size = p.Size;
	poly = new TTerm[Size + 1];

	if (Size != 0)
		for (uint32_t pd = 0; pd < Size; pd++)
			poly[pd] = p.poly[pd];
	return *this;
}


TPoly & TPoly::SetPolyLen(const uint32_t len)
{
	delete[] poly;
	poly = new TTerm[len + 1];
	Size = 0;
	return *this;
}


TPoly::~TPoly()
{
	delete[] poly;
}


TPoly & TPoly::PolyCopy(const TPoly &p)
{
	if (this == &p)
		return *this;
	Size = p.Size;
	for (uint32_t pd = 0; pd < Size; pd++)
		poly[pd] = p.poly[pd];
	return *this;
}


TPoly & TPoly::MergeSameTerm()
{
	if (this->Size <= 1)
		return *this;

	quickSort(this->poly, 0, int(this->Size) - 1);
    
	uint32_t TempSize = this->Size;
	for (uint32_t pd = 1, pf = 0; pd < TempSize; pd++)
	{
		if (poly[pf] == poly[pd])
			this->poly[pf].AddCoeff(poly[pd].getCoeff());
		else
			this->poly[++pf] = poly[pd];
		this->Size = pf + 1;
	}

	return *this;
}


TPoly & TPoly::DiscardEvenCoeff()
{
    if (Size <= 1)
        return *this;

	if (Size > 1)
		this->MergeSameTerm();

	int Len = this->Size;
	this->Size = 0;

	for (int pr = 0; pr < Len; pr++) {
		if (this->poly[pr].getCoeff() & 1)
			this->poly[this->Size++] = this->poly[pr];
	}

	return *this;
}


TPoly & TPoly::Merge(const TPoly &p)
{
	if (p.Size == 0)
		return *this;

	for (uint32_t i = 0; i < p.Size; i++)
		this->poly[this->Size++] = p.poly[i];
	this->MergeSameTerm();

	return *this;
}


void TPoly::WritePolyToFile(int Round, char file[], string message, bool ios_base_flag, uint32_t StartPos)
{
	ofstream fout;
	if (ios_base_flag == 0)
		fout.open(file, ios_base::app);
	else
		fout.open(file, ios_base::out);

	if (Size <= StartPos)
	{
        fout << "Round_" << Round << " OutPutFunction with degree = -1, number of terms = " 
            << Size - StartPos << "; " << message << endl << "- Poly = 0" << endl << endl;
        
        fout.close();
		return;
	}

	fout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
		<< ", number of terms = " << Size - StartPos << "; " << message << endl << "- Poly = ";

	for (uint32_t pr = StartPos; pr < Size; pr++) {
		if (pr > StartPos)
			fout << " + ";

		if (poly[pr].getCoeff() != 1)
			fout << poly[pr].getCoeff() << '*';

		if (poly[pr].getdeg()) {
			for (int i = 0; i < 2; i++)
				for (int j = 0; j < 32; j++)
					if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
						fout << 's' << ((i << 5) + j);
			for (int i = 2; i < 18; i++)
				for (int j = 0; j < 32; j++)
					if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
						fout << 'k' << (((i - 2) << 5) + j);
		}
		else
			fout << '1';
	}
	fout << endl << endl;
	fout.close();
}


void TPoly::WriteValueToFile(int Round, char file[], string message, bool ios_base_flag, uint32_t StartPos)
{
	ofstream fout;
	if (ios_base_flag == 0)
		fout.open(file, ios_base::app);
	else
		fout.open(file, ios_base::out);

	if (Size <= StartPos)
	{
		fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
			<< ", number of terms = " << Size << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl << endl;
		fout.close();
		return;
	}

	fout << "Round_of_Expanding_Recursively_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
		<< ", number of terms = " << Size - StartPos << "; " << message << endl << "- " << Round << ' ' << Size - StartPos << endl;

	for (uint32_t pr = StartPos; pr < Size; pr++)
	{
		fout << hex << "0x" << poly[pr].getdegk() << " 0x" << poly[pr].getCoeff() << ' ';
		for (int i = 0; i < 18; i++)
			fout << hex << "0x" << poly[pr].pterm[i] << ' ';
		fout << hex << "0x" << poly[pr].getdeg() << endl;
	}
	fout << endl << endl;
	fout.close();
}


void TPoly::show(int Round, string message)
{
	if (Size == 0)
	{
		cout << "Round_" << Round << " OutPutFunction: " << endl << "- 0" << message << endl;
		return;
	}

	uint32_t length = Size;
	cout << "Round_" << Round << " OutPutFunction with degree = " << poly[0].getdeg()
		<< ", number of terms = " << Size << "; " << message << endl << "- Poly = ";

	for (uint32_t pr = 0; pr < Size; pr++)
	{
		if (pr)
			cout << " + ";

		if (poly[pr].getCoeff() != 1)
			cout << poly[pr].getCoeff() << '*';

		if (poly[pr].getdeg()) {
			for (int i = 0; i < 2; i++)
				for (int j = 0; j < 32; j++)
					if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
						cout << 's' << ((i << 5) + j);
			for (int i = 2; i < 18; i++)
				for (int j = 0; j < 32; j++)
					if ((poly[pr].pterm[i] >> (31 ^ j)) & 1)
						cout << 'k' << (((i - 2) << 5) + j);
		}
		else
			cout << '1';
	}
	cout << endl;
}


uint32_t TPoly::getSize() const
{
	return Size;
}


void TPoly::setSize(uint32_t n)
{
	Size = n;
}


bool TPoly::setSize(int n)
{
	if (n < 0)
		return false;
	Size = n;
	return true;
}


void TPoly::clear()
{
	Size = 0;
}


void TPoly::AddSizeOne()
{
	Size += 1;
}


void TPoly::AddTerm(const TTerm& t1)
{
	poly[Size++] = t1;
}


TPoly TPoly::operator+(const TPoly &p) {
	uint32_t len1 = this->getSize(), len2 = p.getSize();
	TPoly result; result.clear();

	if (len1 == 0)
		result.Merge(p);
	else if (len2 == 0)
		result.Merge(*this);
	else if ((len1 != 0) && (len2 != 0))
	{
		uint32_t pt = 0;
		uint32_t pd = 0;
		while ((pt < len1) && (pd < len2))
		{
			if (poly[pt] > p.poly[pd])
				result.AddTerm(poly[pt++]);
			else if (poly[pt] < p.poly[pd])
				result.AddTerm(p.poly[pd++]);
			else
			{
				result.poly[result.getSize()] = poly[pt++];
				result.poly[result.getSize()].AddCoeff(poly[pd++].getCoeff());
				result.AddSizeOne();
			}
		}
		for (; pt < len1; pt++)
			result.AddTerm(poly[pt]);
		for (; pd < len2; pd++)
			result.AddTerm(p.poly[pd]);
	}
	return result;
}


TPoly TPoly::operator*(const TPoly &p)
{
	uint32_t len1 = Size;
	uint32_t len2 = p.getSize();
	TPoly result(len1 * len2); result.clear();

	if ((len1 != 0) && (len2 != 0))
		for (uint32_t pd = 0; pd < len2; pd++)
			for (uint32_t pf = 0; pf < len1; pf++)
				result.AddTerm(poly[pf] * p.poly[pd]);

	result.DiscardEvenCoeff();
	return result;
}


TPoly TPoly::operator*(const TTerm &p)
{
	uint32_t len1 = Size;
	TPoly result(len1); result.clear();

	if ((len1 != 0))
        for (uint32_t pf = 0; pf < len1; pf++)
            result.AddTerm(poly[pf] * p);

	result.DiscardEvenCoeff();
	return result;
}


void PolyAdd(TPoly &result, const TPoly &p1, const TPoly &p2)
{
	uint32_t len1 = p1.getSize(), len2 = p2.getSize();
	result.clear();

	if (len1 == 0)
		result.Merge(p2);
	else if (len2 == 0)
		result.Merge(p1);
	else if ((len1 != 0) && (len2 != 0))
	{
		uint32_t pt = 0;
		uint32_t pd = 0;
		while ((pt < len1) && (pd < len2))
		{
			if (p1.poly[pt] > p2.poly[pd])
				result.AddTerm(p1.poly[pt++]);
			else if (p1.poly[pt] < p2.poly[pd])
				result.AddTerm(p2.poly[pd++]);
			else
			{
				result.poly[result.getSize()] = p1.poly[pt++];
				result.poly[result.getSize()].AddCoeff(p2.poly[pd++].getCoeff());
				result.AddSizeOne();
			}
		}
		for (; pt < len1; pt++)
			result.AddTerm(p1.poly[pt]);
		for (; pd < len2; pd++)
			result.AddTerm(p2.poly[pd]);
	}
}


void PolyMul(TPoly &result, const TPoly &p1, const TTerm &pt1)
{
	uint32_t Len = p1.getSize();
	for (uint32_t i = 0; i < Len; i++)
		result.AddTerm(p1.poly[i] * pt1);
}


void PolyMul(TPoly &result, const TPoly &p1, const TPoly &p2)
{
	uint32_t len1 = p1.getSize();
	uint32_t len2 = p2.getSize();
	result.clear();

	if ((len1 != 0) && (len2 != 0))
		for (uint32_t pd = 0; pd < len2; pd++)
			PolyMul(result, p1, p2.poly[pd]);

	if (result.getSize() <= 1)
		return;

	result.DiscardEvenCoeff();
}


void PolyMul(TPoly &result, const TPoly& p1, const TPoly& p2, const TPoly& p3)
{
	uint32_t TempSize = p1.getSize() * p2.getSize();
	TPoly TempPoly(TempSize);
	PolyMul(TempPoly, p1, p2);
	PolyMul(result, TempPoly, p3);
}

// Term Order and Operation
TTerm operator* (const TTerm &pt1, const TTerm &pt2)
{
	TTerm result;
	for (int i = 0; i < 18; i++)
		result.pterm[i] = (pt1.pterm[i]) | (pt2.pterm[i]);
	result.degree();
	result.setdegk(-1);
	result.setCoeff(pt1.getCoeff() * pt2.getCoeff());
	return result;
}


bool operator< (const TTerm &p1, const TTerm &p2)
{

	if (p1.getdegk() > p2.getdegk())
		return true;
	else if (p1.getdegk() < p2.getdegk())
		return false;
	else if (p1.getdeg() < p2.getdeg())
		return true;
	else if (p1.getdeg() > p2.getdeg())
		return false;
	else {
		for (int i = 0; i < 18; i++)
		{
			if (p1.pterm[i] < p2.pterm[i])
				return true;
			else if (p1.pterm[i] > p2.pterm[i])
				return false;
		}
	}
	return false;
}


bool operator<= (const TTerm &p1, const TTerm &p2)
{
	if (p1 > p2)
		return false;
	else
		return true;
}


bool operator> (const TTerm &p1, const TTerm &p2)
{
	if (p1.getdegk() < p2.getdegk())
		return true;

	else if (p1.getdegk() > p2.getdegk())
		return false;

	else if (p1.getdeg() > p2.getdeg())
		return true;

	else if (p1.getdeg() < p2.getdeg())
		return false;

	else
	{
		for (int i = 0; i < 18; i++)
		{
			if (p1.pterm[i] > p2.pterm[i])
				return true;
			else if (p1.pterm[i] < p2.pterm[i])
				return false;
		}
	}
	return false;
}


bool operator==(const TTerm &p1, const TTerm &p2)
{
	if (p1.getdeg() != p2.getdeg())
		return false;

	for (int i = 0; i < 18; i++)
		if (p1.pterm[i] != p2.pterm[i])
			return false;

	return true;
}


bool Divisibility(const TTerm &BigP, const TTerm &SmallP)
{
	if (BigP.getdeg() < SmallP.getdeg())
		return false;

	TTerm temp;
	for (int i = 0; i < 18; i++)
		temp.pterm[i] = BigP.pterm[i] | SmallP.pterm[i];
	if (temp == BigP)
		return true;
	else
		return false;
}


// ---------------------------------------------------------------------------

template <class T>
void quickSort(T s[], int l, int r)
{
    if (l < r)
    {
        int i = l, j = r;
        T x = s[l];
        while (i < j)
        {
            while ((i < j) && (s[j] <= x))
                j--;
            if (i < j)
                s[i++] = s[j];
            while (i < j && s[i] > x)
                i++;
            if (i < j)
                s[j--] = s[i];
        }
        s[i] = x;
        quickSort(s, l, i - 1);
        quickSort(s, i + 1, r);
    }
}


int minint(int arr[], int len)
{
    if (len == 0)
        return 0;
    int temp = arr[0];
    for (int i = 1; i < len; i++)
        if (temp > arr[i])
            temp = arr[i];
    return temp;
}


int maxint(int arr[], int len)
{
    if (len == 0)
        return 0;
    int temp = arr[0];
    for (int i = 1; i < len; i++)
        if (temp < arr[i])
            temp = arr[i];
    return temp;
}