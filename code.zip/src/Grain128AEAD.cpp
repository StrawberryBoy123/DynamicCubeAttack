#include "Grain128AEAD.h"


// ------------------------------------ Parallel ------------------------------------
mutex G_STREAM_MUTEX, G_MAP_MUTEX;
atomic<int > G_CCount, G_TimeOutTermNum, G_TestNum, G_AllNum;


// -------------------------------------------------------------------------------------------
bool SPRecoveryForGrain128Family(int ORound, IvGterm Cube, int ModelType, int count, IvGterm DCube, bool guassflag, int guassloc, int wrongiv, bool AEAD_FLAG) {
    const int BackRound = 60;
    string ANFFile = "GExpandingANF" + to_string(BackRound) + ".txt";

    string strfile = "GReSP" + to_string(ORound) + '_' + to_string(count);
    if (DCube.count()) {
        if (guassflag) strfile += "_RG";
        else           strfile += "_EG" + to_string(guassloc + SecParaG::DyVarShiftFlag*60);
    }

    string file_str = "mkdir " + strfile;
    system(file_str.c_str());

    string str;
    if (AEAD_FLAG) str = "/NewState(Grain128AEAD).txt";
    else           str = "/NewState(Grain128).txt";

    string Outfile   = strfile + "/GReSP" + to_string(ORound) + '_' + to_string(count) + ".txt";
    string Parafile1 = strfile + "/ModelRequired.txt";
    string Parafile2 = strfile + str;
    string FileName1 = strfile + "/TestResult.txt";
    string FileName2 = strfile + "/SuperpolyValue.txt";
    string FileName3 = "TestBalancedness.txt";


    SecParaG::MapGPoly Superpoly;
    GPoly InANF(10);
    int TRound = 0; 
    string Cubestr = "";
    
    time_t s_t = time(nullptr);
    if (false) 
        ExpressRecursivelyForGrain(ORound, BackRound, ANFFile, AEAD_FLAG);

    Superpoly.clear(); InANF.clear();
    int IRound = 0;
    if (true) {
        GReadANF(TRound, InANF, ANFFile);
        IRound = ORound - TRound;
    } else {
        cout << "openfile: " << Outfile << endl;
        ifstream fin; fin.open(Outfile);
        if (!fin.is_open())
            return false;

        GReadANF(TRound, InANF, Superpoly, Outfile);
        IRound = TRound;
    }
 
    SecParaG::ParameterSelection(Cube, ModelType, DCube, guassflag, guassloc, wrongiv, Parafile1, Parafile2, AEAD_FLAG);
    bool TimeFlag = FilterPartTermBDPT(Superpoly, InANF, IRound, Cube, Outfile, ModelType, DCube, guassflag, guassloc, AEAD_FLAG);
    time_t e_t = time(nullptr);

    Cubestr = "- No." + to_string(count) + " Round: " + to_string(ORound) 
            + "; RunningTime: " + to_string(e_t - s_t) + " s; Cube(" 
            + to_string(Cube.count()) + "); zvar:";

    IvGterm tmpC = Cube | DCube;
    for (int i = 0; i < 96; i++)
        if (!tmpC.test(i))
            Cubestr += " v" + to_string(i);
    if (DCube.count()) {
        Cubestr += "; dvar: ";
        for (int i = 0; i < 96; i++)
            if (DCube.test(i))
                Cubestr += " v" + to_string(i);
    }

    if (TimeFlag) {
        if (ModelType == 0) {
            Superpoly.WritePolyToFile(FileName1, Cubestr);
            Superpoly.WriteValueToFile(FileName2, Cubestr, true);
        } else if (ModelType > 0) {
            if (Superpoly.size() > 0) {
                Superpoly.TestBalanced2(FileName3, Cubestr, false);
                SecParaG::MapGPoly Ret;
                Superpoly.ConvertNKvarsTo128Kvars(Ret);
                Ret.WritePolyToFile(FileName1, Cubestr);
                Ret.WriteValueToFile(FileName2, Cubestr);
                Superpoly.WriteValueToFile(FileName2, Cubestr);
                // Ret.TestBalanced(FileName3, Cubestr);
                // Superpoly.WriteNVarsGPoly(FileName, Cubestr);
            }
        }
        cout << "Successful !" << endl;
    }
    else 
        cout << "Fail !" << endl;


    Superpoly.clear();
    SecParaG::ParameterClear();
    return true;
}


bool FilterPartTermBDPT(SecParaG::MapGPoly& RetSuperpoly, GPoly& ANF, int IRound, IvGterm Cube, string files, int ModelType, IvGterm DCube, bool guassflag, int guassloc, bool AEAD_FLAG) {
    
    if ((!IRound) && (!ANF.getSize()))
        return true;

    GPoly InPutANF(1000000), OutPutANF(1000000);
    GPoly UpdateFunc[4], ZR(13), TempPoly1(50 * SIZEBw), TempPoly2(50 * SIZEBw);
    GPoly Snullptr(0), updateb(30), updates(30), SAll(900);

    if (AEAD_FLAG)
        InvExpressInitGAEAD(ZR, updateb, updates, SAll);
    else
        InvExpressInitG128(ZR, updateb, updates, SAll);
        
    UpdateFunc[0] = Snullptr;
    UpdateFunc[1] = updates;
    UpdateFunc[2] = updateb;
    UpdateFunc[3] = SAll;

    int AllThread = std::thread::hardware_concurrency();
    const int ParallelNum = 4, SingleThread = 7;  // for superpoly recovery;
    const int ParallelNum2 = 7, SingleThread2 = 4; // for evaluating degree;
    cout << "The total number of threads available to this computer: " << AllThread << endl
        << "ParallelNum = " << ParallelNum << ", SingleThread: " << SingleThread << endl;

    int pos = files.find('/');
    string mfile = files.substr(0, pos) + "/RoundLog/";
    string inst = "mkdir " + mfile;
    system(inst.c_str());
    

    int BACKROUNDBOUND = SecParaG::REDUCEROUND + 1;
    int TimeLimit = 60, MaxDeg = SecParaG::ACTKEYLEN;
    const int LEN = 6;
    const int TRound[LEN] = { 32, BACKROUNDBOUND, BACKROUNDBOUND + 2, 100, 130, 140 };
    const int Ttime[LEN]  = {  0, 240, 180, 120, 90, 60 };
    const double ThresholdCoeff = 0.50;
    const int BackExpandNumThr = 5;
    const int BackExpandNumThr2 = 2000;
    const int RecoveryNumThr = 30;
    const int partLen = 1000;
    int SaveTermNum = 1;


    // ----------------------------------------------------------------------
    for (int pt = 0; pt < ANF.getSize(); pt++) {
        if (ANF.poly[pt].getdegk() < 0)
            OutPutANF.AddTerm(ANF.poly[pt]);
        else 
            InPutANF.AddTerm(ANF.poly[pt]);
    }

    if (OutPutANF.getSize()) {
        SecParaG::MapGPoly TmpSp; G_CCount.store(0); G_AllNum.store(OutPutANF.getSize());
        #pragma omp parallel for num_threads(ParallelNum2) schedule(dynamic, 3)
        for (int pt = 0; pt < OutPutANF.getSize(); pt++) {
            Grain128AEADEvalBDPT(TmpSp, OutPutANF.poly[pt], Cube, IRound, false, TimeLimit, SingleThread2, ModelType, DCube, AEAD_FLAG);

            if (OutPutANF.poly[pt].getdegk() > 0) {
                #pragma omp critical
                InPutANF.AddTerm(OutPutANF.poly[pt]);
            }
        }
        OutPutANF.clear();

        if (InPutANF.getSize()) {
            cout << "InPutANF = " << InPutANF.getSize() << endl;
            quickSort(InPutANF.poly, 0, int(InPutANF.getSize()) - 1);
            MaxDeg = InPutANF.poly[InPutANF.getSize() - 1].getdegk();
        }
        else 
            MaxDeg = SaveTermNum = 0;

            // if (MaxDeg > 50) return false;
        
        // string ofile = files.substr(0, files.length() - 4) + '(' + to_string(IRound) + ").txt";
        // InPutANF.WriteValueToFile(IRound, ofile, "Terms: " + to_string(InPutANF.getSize()));
        // return true;
    }

    while ((SaveTermNum <= 100000) && (SaveTermNum)) {
        int TESTFLAG = true;
        bool computeflag = true;

        time_t TimeOutStart = time(nullptr);
        while (((OutPutANF.getSize() <= RecoveryNumThr)||(TESTFLAG)) && (IRound > BACKROUNDBOUND) && (InPutANF.getSize() <= BackExpandNumThr2) ) {

            TempPoly1.clear(); TempPoly2.clear();
            computeflag = false;

            for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++) {
                uint8_t flag = ((InPutANF.poly[pt].pterm[3] & 1) << 1) | (InPutANF.poly[pt].pterm[7] & 1);
                uint8_t flagweight = (InPutANF.poly[pt].pterm[3] & 1) + (InPutANF.poly[pt].pterm[7] & 1);

                for (int i = 7; i > 0; i--)
                    InPutANF.poly[pt].pterm[i] = (InPutANF.poly[pt].pterm[i] >> 1) | ((InPutANF.poly[pt].pterm[i - 1] << 31) & 0x80000000);
                InPutANF.poly[pt].pterm[0] >>= 1;
                InPutANF.poly[pt].setdeg(InPutANF.poly[pt].getdeg() - flagweight);

                if (flag) {
                    InPutANF.poly[pt].pterm[4] &= 0x7fffffff;
                    PolyMul(TempPoly2, UpdateFunc[flag], InPutANF.poly[pt]);
                } else
                    TempPoly1.AddTerm(InPutANF.poly[pt]);
            }
            
            for (uint32_t pt = 0; pt < OutPutANF.getSize(); pt++) {
                uint8_t flag = ((OutPutANF.poly[pt].pterm[3] & 1) << 1) | (OutPutANF.poly[pt].pterm[7] & 1);
                uint8_t flagweight = (OutPutANF.poly[pt].pterm[3] & 1) + (OutPutANF.poly[pt].pterm[7] & 1);

                for (int i = 7; i > 0; i--)
                    OutPutANF.poly[pt].pterm[i] = (OutPutANF.poly[pt].pterm[i] >> 1) | ((OutPutANF.poly[pt].pterm[i - 1] << 31) & 0x80000000);
                OutPutANF.poly[pt].pterm[0] >>= 1;
                OutPutANF.poly[pt].setdeg(OutPutANF.poly[pt].getdeg() - flagweight);

                if (flag) {
                    OutPutANF.poly[pt].pterm[4] &= 0x7fffffff;
                    PolyMul(TempPoly2, UpdateFunc[flag], OutPutANF.poly[pt]);
                }
                else
                    TempPoly2.AddTerm(OutPutANF.poly[pt]);
            }
            IRound -= 1;
            OutPutANF.clear();
            InPutANF.PolyCopy(TempPoly1);
            cout << endl << "Before Degest: OutPutANF Terms: " << TempPoly2.getSize() << ", SaveTerms: " << InPutANF.getSize() << ", IRound = " << IRound << endl;
            // ---------------------------------------------------------------
            TempPoly2.DiscardEvenCoeff();
            cout << "DegEst1(Pass DiscardEvenCoeff): OutPutANF Terms: " << TempPoly2.getSize() << ", SaveTerms: " << InPutANF.getSize() << ", IRound = " << IRound << endl;
            // ---------------------------------------------------------------

            if ((TempPoly2.getSize() < BackExpandNumThr) && (IRound > BACKROUNDBOUND)) {
                OutPutANF.PolyCopy(TempPoly2);
                TESTFLAG = true;
                continue;
            }
            TESTFLAG = false;


            // ------------------------------------------------------------
            // time_t local_time;
            // struct tm *local_tm;
            // char buf_tmp[64];
            // time (&local_time);
            // local_tm = localtime(&local_time);
            // strftime(buf_tmp, 64, "%Y_%m_%d_%H_%M_%S", local_tm);
            // string Date1 = buf_tmp;
            // string filec1 = mfile + "TempFile(" + to_string(IRound) + "_" + Date1 + ").txt";
            // TempPoly2.WritePolyToFile(IRound, filec1, "TermNum: " + to_string(TempPoly2.getSize()), 1);
            // ------------------------------------------------------------


            SecParaG::MapGPoly TmpSp; G_CCount.store(0); G_AllNum.store(TempPoly2.getSize());
            #pragma omp parallel for num_threads(ParallelNum2) schedule(dynamic, 3)
            for (int pt = 0; pt < TempPoly2.getSize(); pt++) {

                if (TempPoly2.poly[pt].getdegk() <= 0) 
                    Grain128AEADEvalBDPT(TmpSp, TempPoly2.poly[pt], Cube, IRound, false, TimeLimit, SingleThread2, ModelType, DCube, AEAD_FLAG);

                if (TempPoly2.poly[pt].getdegk() > 0) {
                    #pragma omp critical
                    OutPutANF.AddTerm(TempPoly2.poly[pt]);
                }
            }

            if (OutPutANF.getSize() > 0) {
                quickSort(OutPutANF.poly, int64_t(0), int64_t(OutPutANF.getSize()) - 1);
                MaxDeg = OutPutANF.poly[OutPutANF.getSize() - 1].getdegk();
            } else
                MaxDeg = 0;

            // time_t local_time;
            // struct tm *local_tm;
            // char buf_tmp[64];
            // time (&local_time);
            // local_tm = localtime(&local_time);
            // strftime(buf_tmp, 64, "%Y_%m_%d_%H_%M_%S", local_tm);
            // string Date1 = buf_tmp;
            // string filec1 = mfile + "TempFile(" + to_string(IRound) + "_" + Date1 + ").txt";
            // OutPutANF.WriteValueToFile(IRound, filec1, "TermNum: " + to_string(OutPutANF.getSize()));
            // InPutANF.WriteValueToFile(IRound, filec1, "SaveTerm: " + to_string(InPutANF.getSize()));
            // RetSuperpoly.WriteValueToFile(filec1, "Recovered Superpoly");

            // ------------------------------------------------------------
            cout << "DegEst2(Pass DegEst): OutPutANF Terms: " << OutPutANF.getSize() << ", SaveTerms: " << InPutANF.getSize() << ", IRound = " << IRound << endl;
            if (IRound <= BACKROUNDBOUND) {
                OutPutANF.Merge(InPutANF);
                InPutANF.clear();
                break;
            }
        }
        // cout << "IRound: " << IRound << ", BACKROUNDBOUND: " << BACKROUNDBOUND << ", OutPutANF: " << OutPutANF.getSize() << ", InPutANF: " << InPutANF.getSize() << endl;


        if ((InPutANF.getSize() + OutPutANF.getSize()) == 0) {
            string OutFile1 = files.substr(0, files.length() - 4) + '(' + to_string(IRound) + ").txt";
            InPutANF.WriteValueToFile(IRound, OutFile1, "Terms: " + to_string(InPutANF.getSize()), true);
            RetSuperpoly.WriteValueToFile(OutFile1, "Recovered Superpoly");
            break;
        } else if (IRound < BACKROUNDBOUND + 1) {
            OutPutANF.Merge(InPutANF);
            InPutANF.clear();
        } else if ((computeflag) && (InPutANF.getSize() > 0) && (OutPutANF.getSize() == 0)) {
            OutPutANF.Merge(InPutANF);
            InPutANF.clear();
        }
        // cout << "go here: OutPutANF: " << OutPutANF.getSize() << endl;

        if (OutPutANF.getSize() > 0)
            quickSort(OutPutANF.poly, 0, int(OutPutANF.getSize()) - 1);
        MaxDeg = OutPutANF.poly[OutPutANF.getSize() - 1].getdegk();
        cout << "MaxDeg = " << MaxDeg << endl;

        time_t TotalStartTime = time(nullptr);
        int *TermNum = new int[MaxDeg];
  
        for (int i = 0; i < MaxDeg; i++)
            TermNum[i] = 0;
        for (uint32_t i = 0; i < OutPutANF.getSize(); i++)
            TermNum[OutPutANF.poly[i].getdegk() - 1] += 1;
        cout << "(deg, MonomialNumber): ";
        for (int i = 0; i < MaxDeg; i++)
            if (TermNum[i] > 0)
                cout << '(' << i << ", " << TermNum[i] << ") ";
        cout << endl;
        int AllTermNum = OutPutANF.getSize();
        G_AllNum.store(AllTermNum);

        for (int i = 0; i < LEN; i++)
            if (IRound >= TRound[i])
                TimeLimit = Ttime[i];

        for (int ppt = 0; ppt < AllTermNum; ppt += partLen) {
            int tarppt = ((ppt + partLen) >= AllTermNum) * AllTermNum + ((ppt + partLen) < AllTermNum) * (ppt + partLen);
            G_CCount.store(0); G_TimeOutTermNum.store(0); G_TestNum.store(tarppt - ppt);
            int d1 = OutPutANF.poly[ppt].getdegk(), d2 = OutPutANF.poly[tarppt - 1].getdegk();

            cout << "Start Superpoly Rrcovery!" << endl;
            #pragma omp parallel for num_threads(ParallelNum) schedule(dynamic, 1)
            for (int ppd = ppt; ppd < tarppt; ppd++){
                Grain128AEADEvalBDPT(RetSuperpoly, OutPutANF.poly[ppd], Cube, IRound, true, TimeLimit, SingleThread, ModelType, DCube, AEAD_FLAG);
                if (OutPutANF.poly[ppd].getdegk()) {
                    #pragma omp critical
                    InPutANF.AddTerm(OutPutANF.poly[ppd]);
                }
            }
            G_AllNum -= G_TestNum;

            // for (int ppd = ppt; ppd < tarppt; ppd++)
            //     if (OutPutANF.poly[ppd].getdegk())
            //         InPutANF.AddTerm(OutPutANF.poly[ppd]);

            time_t local_time;
            struct tm *local_tm;
            char buf_tmp[64];
            time (&local_time);
            local_tm = localtime(&local_time);
            strftime(buf_tmp, 64, "%Y_%m_%d_%H_%M_%S", local_tm);
            string Date = buf_tmp;
            string filec = mfile + "TempFile(" + to_string(IRound) + "_" + Date + ").txt";
            OutPutANF.WriteValueToFile(IRound, filec, to_string(tarppt) + "/" + to_string(OutPutANF.getSize()), 1, tarppt);
            InPutANF.WriteValueToFile(IRound, filec, "SaveTerm: " + to_string(InPutANF.getSize()));
            RetSuperpoly.WriteValueToFile(filec, "Recovered Superpoly");
            // InPutANF.WritePolyToFile(IRound, filec, "SaveTerm: " + to_string(InPutANF.getSize()));

            cout << "Round: " << IRound << ", Termdeg: " << d1 << "-" << d2 << ", The size of the Superpoly: " 
                << RetSuperpoly.size() << ", Accepted Terms: " << InPutANF.getSize() << endl;
            
            if ( (G_TimeOutTermNum > (tarppt - ppt) * ThresholdCoeff) ) {
                for (int ppd = tarppt; ppd < AllTermNum; ppd++)
                    InPutANF.AddTerm( OutPutANF.poly[ppd] );
                cout << "Round: " << IRound << ", The size of the Superpoly: " << RetSuperpoly.size() 
                    << ", Accepted Terms: " << InPutANF.getSize() << endl;
                break;
            }
        }
        time_t TotalEndTime = time(nullptr);
        delete[] TermNum;

        // -----------------------------------------------------------------------------------------------------

        InPutANF.DiscardEvenCoeff();
        cout << "Save Terms(Pass BDPT_MILP): " << InPutANF.getSize() << ", Rumtime: " << double(TotalEndTime - TotalStartTime) << " s" << endl;

        string OutFile = files.substr(0, files.length() - 4) + '(' + to_string(IRound) + ").txt";
        InPutANF.WriteValueToFile(IRound, OutFile, "Terms: " + to_string(InPutANF.getSize()), true);
        RetSuperpoly.WriteValueToFile(OutFile, "Recovered Superpoly");
        InPutANF.WritePolyToFile(IRound, OutFile, "Terms: " + to_string(InPutANF.getSize()));

        // -----------------------------------------------------------------------------------------------------

        SaveTermNum = InPutANF.getSize();
        OutPutANF.clear();
        
        // -----------------------------------------------------------------------------------------------------

        if (SaveTermNum == 0)
            return true;
        else if (IRound <= BACKROUNDBOUND){
            InPutANF.WriteValueToFile(IRound, OutFile, "Terms: " + to_string(InPutANF.getSize()), true);
            SecParaG::MapGPoly RetSP;
            RetSuperpoly.ConvertNKvarsTo128Kvars(RetSP);
            RetSP.WriteValueToFile(OutFile, "Recovered Superpoly 128-kvars");
            RetSuperpoly.WriteValueToFile(OutFile, "Recovered Superpoly N-kvars");
            InPutANF.WritePolyToFile(IRound, OutFile, "Terms: " + to_string(InPutANF.getSize()));
        
            return false;
        }
    }

    if (SaveTermNum != 0)
        return false;
    else
        return true;
}


int DegEst(GPoly ANF, int IRound, IvGterm Cube, string files, int ModelType, IvGterm DCube, bool guassflag, int guassloc, int wrongiv, bool AEAD_FLAG) {
    int ParallelNum = 2;
    int SingleThread = 15;
    int maxdeg = 0;

    string ofile;
    if (AEAD_FLAG) ofile = "NewState(Grain128AEAD).txt"; 
    else ofile = "NewState(Grain128).txt";

    SecParaG::ParameterSelection(Cube, ModelType, DCube, guassflag, guassloc, wrongiv, "ModelRequired.txt", ofile, AEAD_FLAG);

    SecParaG::MapGPoly TmpSp; G_CCount.store(0); G_AllNum.store(ANF.getSize());
    #pragma omp parallel for num_threads(ParallelNum) schedule(dynamic, 3)
    for (int pt = 0; pt < ANF.getSize(); pt++) {
        // only test deg ?= 0
        if (maxdeg > 0)
            continue;

        Grain128AEADEvalBDPT(TmpSp, ANF.poly[pt], Cube, IRound, false, 0, SingleThread, ModelType, DCube, AEAD_FLAG);

        if (ANF.poly[pt].getdegk() > 0) {
            #pragma omp critical
            {
                if (maxdeg < ANF.poly[pt].getdegk())
                    maxdeg = ANF.poly[pt].getdegk();
            }
        }
    }
    
    if (true) {
        ofstream fout; fout.open(files, ios_base::app);
        fout << "Cube(" << Cube.count() << "); zvar:";
        IvGterm TmpC = Cube | DCube;
        for (int i = 0; i < 96; i++)
            if (!TmpC.test(i)) 
                fout << " v" << i;
        if (DCube.count()){
            fout << "; dvar:";
            for (int i = 0; i < 96; i++)
                if (DCube.test(i))
                    fout << " v" << i;
            if (guassflag) 
                fout << "; Guass Right!";
            else{
                fout << "; Guass Wrong (v" << guassloc + 60 * SecParaG::DyVarShiftFlag << ")";
            }
        }
        fout << "; deg = " << maxdeg - 1 << endl;
    }
    return maxdeg - 1;
}


void Grain128AEADEvalBDPT(SecParaG::MapGPoly& ResPoly, GTerm &Pterm, IvGterm &Cube, int IRound, bool SolutFlag, int TimeLimit, int ThreadNum, int ModelType, IvGterm DCube, bool AEAD_FLAG) {
    if ((Pterm.getCoeff() & 1) == 0) {
        Pterm.setdegk(0);
        return ;
    }
    else
        Pterm.setCoeff(1);

    int StartRound = 0;
    GRBEnv Env = GRBEnv();
    Env.set(GRB_IntParam_LogToConsole, 0);
    GRBModel Model = GRBModel(Env);
    if (ThreadNum != 0) Model.set(GRB_IntParam_Threads, ThreadNum);
    if (TimeLimit != 0) Model.set(GRB_DoubleParam_TimeLimit, TimeLimit);

    if (SolutFlag) {
        Model.set(GRB_IntParam_PoolSolutions, 2000000000);  // Limit how many solutions to collect
        Model.set(GRB_IntParam_PoolSearchMode, 2);  // do a systematic search for the k- best solutions
        Model.set(GRB_DoubleParam_PoolGap, GRB_INFINITY);  // Limit the search space by setting a gap for the worst possible solution that will be acce
        Model.set(GRB_IntParam_MIPFocus, 3);
    }

    GRBVar *kvar = Model.addVars(SecParaG::ACTKEYLEN, 'B');
    GRBVar *vvar = Model.addVars(96 , 'B');
    GRBVar *svar = Model.addVars(128, 'B');
    GRBVar *bvar = Model.addVars(128, 'B');

    GRBLinExpr key_sum;
    for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
        key_sum += kvar[i];
    Model.setObjective(key_sum, GRB_MAXIMIZE);
    
    // -----------------------------
    // Model.addConstr(key_sum >= 1);
    // Model.setObjective(key_sum, GRB_MINIMIZE);
    // -----------------------------

    for (int i = 0; i < 96; i++) {
        if (Cube.test(i))        Model.addConstr(vvar[i] == 1);
        else if (!DCube.test(i)) Model.addConstr(vvar[i] == 0);
    }


    // ---------------------------------------------------------
    // Model.addConstr(key_sum == 0);
    // GRBLinExpr vsum;
    // for (int i = 0; i < 96; i++)
    //     vsum += vvar[i];
    // Model.setObjective(vsum, GRB_MAXIMIZE);
    // ---------------------------------------------------------


    if (ModelType == 0) {
        for (int i = 0; i < 96; i++)
            Model.addConstr(svar[i] == vvar[i]);

        if (AEAD_FLAG)
            Model.addConstr(svar[127] == 0);

        for (int i = 0; i < 128; i++)
            Model.addConstr(bvar[i] == kvar[i]);
    }
    else {
        StartRound = SecParaG::REDUCEROUND;
        GInitilization(Model, svar, bvar, kvar, vvar);
    }

    for (int r = StartRound; r < IRound; r++) {
        GRBVar z = funcZ(Model, bvar, svar, AEAD_FLAG);
        GRBVar *zs = Model.addVars(2, 'B');
        Model.addGenConstrOr(z, zs, 2);
        
        GRBVar f = funcF(Model, svar);
        GRBVar g = funcG(Model, bvar, AEAD_FLAG);

        GRBVar news = Model.addVar(0, 1, 0, GRB_BINARY);
        Model.addConstr(news == zs[0] + f);

        GRBVar newb = Model.addVar(0, 1, 0, GRB_BINARY);
        Model.addConstr(newb == zs[1] + g);

        for (int i = 0; i < 127; i++) {
            bvar[i] = bvar[i + 1];
            svar[i] = svar[i + 1];
        }
        bvar[127] = newb;
        svar[127] = news;
    }

    for (int pt = 0; pt < 128; pt++) {
        if ((Pterm.pterm[pt >> 5] >> (31 - (pt & 31))) & 1)
            Model.addConstr(bvar[pt] == 1);
        else
            Model.addConstr(bvar[pt] == 0);
    }

    for (int pt = 128; pt < 256; pt++) {
        if ((Pterm.pterm[pt >> 5] >> (31 - (pt & 31))) & 1)
            Model.addConstr(svar[pt - 128] == 1);
        else
            Model.addConstr(svar[pt - 128] == 0);
    }

    Model.update();
    Model.optimize();

    G_CCount++;

    // if (false)
    // if (Model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
    //     if (SolutFlag == false) {
    //         Pterm.setdegk(round(Model.get(GRB_DoubleAttr_ObjVal)));
    //         {
    //             lock_guard<mutex> guard(G_STREAM_MUTEX);
    //             cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() << ", Tested Terms("
    //                  << G_CCount << "/" << G_AllNum << "): deg = " << Pterm.getdegk() << ", monomial: ";
    //             Pterm.show("");
    //         }
    //     }
    // }
    // else {
    //     Pterm.setdegk(-1);
    //     {
    //         lock_guard<mutex> guard(G_STREAM_MUTEX);
    //         cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() << ", Tested Terms("
    //                 << G_CCount << "/" << G_AllNum << "): deg = " << Pterm.getdegk() << ", monomial: ";
    //         Pterm.show("");
    //     }
    // }


    // if (true)
    if (Model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
        if (SolutFlag == false) {
            Pterm.setdegk(round(Model.get(GRB_DoubleAttr_ObjVal)) + 1);
            {
                lock_guard<mutex> guard(G_STREAM_MUTEX);
                cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() 
                    << ", Have Tested Terms(" << Pterm.getdegk() << "): " << G_CCount 
                    << "/" << G_AllNum << ", RunningTime: " << Model.get(GRB_DoubleAttr_Runtime) << "s \n";
            }
        }
        else {
            int nSolutions = Model.get(GRB_IntAttr_SolCount);
            SecParaG::MapGPoly TempPoly;

            for (int res = 0; res < nSolutions; res++) {
                SecParaG::MGTerm p_term;
                Model.set(GRB_IntParam_SolutionNumber, res);

                for (int loc = 0; loc < SecParaG::ACTKEYLEN; loc++)
                    if (kvar[loc].get(GRB_DoubleAttr_Xn) >= 0.5)
                        p_term.insert(loc);
                TempPoly.InSert(p_term);
            }

            Pterm.setdegk(0);
            {
                lock_guard<mutex> guard(G_MAP_MUTEX);
                ResPoly.Merge(TempPoly);
                TempPoly.clear();
            }
            {
                lock_guard<mutex> guard(G_STREAM_MUTEX);
                cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() << ", Tested Terms(" << Pterm.getdegk() << "): (" << G_CCount
                    << "/" << G_TestNum << "/" << G_AllNum << "), The size of the Superpoly: " << ResPoly.size() << ", Accepted Terms: "
                    << G_TimeOutTermNum << ", Number of solutions: " << nSolutions << ", RunningTime: " << Model.get(GRB_DoubleAttr_Runtime) << "s " << endl;
            }
        }
    } else if (Model.get(GRB_IntAttr_Status) == GRB_TIME_LIMIT) {
        Pterm.setdegk(SecParaG::ACTKEYLEN);
        if (SolutFlag) {
            lock_guard<mutex> guard(G_STREAM_MUTEX);
            cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() << ", Tested Terms(" << Pterm.getdegk() << "): (" << G_CCount
                << "/" << G_TestNum << "/" << G_AllNum << "), The size of the Superpoly: " << ResPoly.size() << ", Accepted Terms: "
                << ++G_TimeOutTermNum << ", Number of solutions: nullptr, RunningTime: " << Model.get(GRB_DoubleAttr_Runtime) << "s " << endl;
        }
    } else {
        Pterm.setdegk(0);
    }
}


void GInitilization(GRBModel &Model, GRBVar* svar, GRBVar *bvar, GRBVar *kvar, GRBVar *vvar) {
    bool OutPutFlag = false;

    int InitIVLen = 96 + (SecParaG::WrongLocation > 0);
    GRBVar* vkvar = new GRBVar [SecParaG::ACTKEYLEN + InitIVLen];
    for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
        vkvar[i] = kvar[i];
    for (int i = 0, j = SecParaG::ACTKEYLEN; i < 96; i++, j++){
        if ( (SecParaG::WrongLocation) && (i == SecParaG::WrongIV[0])) {
            GRBVar* tmpv = Model.addVars(2, 'B');
            Model.addConstr( vvar[i] == tmpv[0] + tmpv[1] );
            vkvar[j] = tmpv[0];
            vkvar[SecParaG::ACTKEYLEN + 96] = tmpv[1];
        }
        else
            vkvar[j] = vvar[i];
    }

    if (SecParaG::CONDITIONS.size()) {
        for (auto pt = SecParaG::CONDITIONS.rbegin(); pt != SecParaG::CONDITIONS.rend(); pt++) {
            Arr2Int tpoly = *pt;
            GRBLinExpr tmpsum;
            int oneflag = 0;
            // cout << "v" << tpoly[0][0] << " = ";
            for (auto pd = tpoly.begin() + 1; pd != tpoly.end(); pd++) {
                int len = pd->size();

                // if (pd != tpoly.begin() + 1) cout << " + ";

                if (len == 0) { oneflag += 1; continue;} //  cout << "1";

                GRBVar *var = new GRBVar [len];
                var[0] = tap(Model, vkvar[(*pd)[0]]);

                // if ((*pd)[0] < SecParaG::ACTKEYLEN) cout << "k" << (*pd)[0];
                // else                                cout << "v" << (*pd)[0] - SecParaG::ACTKEYLEN;
                
                for (int i = 1; i < len; i++) {
                    var[i] = tap(Model, vkvar[(*pd)[i]]);
                    Model.addConstr(var[0] == var[i]);

                    // if ((*pd)[i] < SecParaG::ACTKEYLEN) cout << "*k" << (*pd)[i];
                    // else                                cout << "*v" << (*pd)[i] - SecParaG::ACTKEYLEN;
                }
                tmpsum += var[0];
            }
            if (oneflag & 1) Model.addConstr(vvar[tpoly[0][0]] >= tmpsum);
            else             Model.addConstr(vvar[tpoly[0][0]] == tmpsum);
            // cout << endl;
        }
    }

    GRBVar* tempkey = new GRBVar[SecParaG::ACTKEYLEN];
    for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
        tempkey[i] = vkvar[i];
    GRBVar* tempallv = new GRBVar[SecParaG::ACTIVLEN];
    for (int i = 0; i < InitIVLen; i++)
        tempallv[i] = vkvar[SecParaG::ACTKEYLEN + i];
    
    auto ppt = SecParaG::NewIVANFsARR.begin();
    auto ppd = SecParaG::IVCOUNTs.begin();
    
    while ((ppt != SecParaG::NewIVANFsARR.end()) && (ppd != SecParaG::IVCOUNTs.end())) {
        int newivlen = (*ppt).size();
        int varlen = (*ppd).size();
        int ivvarlen = varlen - SecParaG::ACTKEYLEN;
        Arr1Int Ivcount(varlen, 0);
        GRBVar *mv = Model.addVars(newivlen, 'B');
        GRBVar **newv = new GRBVar*[varlen];

        for (int i = 0; i < varlen; i++) {
            if ((*ppd)[i] > 0) {
                newv[i] = Model.addVars((*ppd)[i] + 1, 'B');                
                if (i < SecParaG::ACTKEYLEN) {
                    Model.addGenConstrOr(tempkey[i], newv[i], (*ppd)[i] + 1);
                    tempkey[i] = newv[i][(*ppd)[i]];
                }
                else {
                    Model.addGenConstrOr(tempallv[i - SecParaG::ACTKEYLEN], newv[i], (*ppd)[i] + 1);
                    tempallv[i - SecParaG::ACTKEYLEN] = newv[i][(*ppd)[i]];
                }
            }
            // else {
            //     if (i < SecParaG::ACTKEYLEN) cout << "k" << i << " = 0" << endl;
            //     else                         cout << "v" << i - SecParaG::ACTKEYLEN << " = 0" << endl;
            // }
        }

        for (int i = 0; i < newivlen; i++) {
            GRBLinExpr sstemp;
            
            // cout << "v" << (*ppt)[i][0][0] << " = ";

            for (int j = 1; j < (*ppt)[i].size(); j++) {
                // if (j > 1) cout << " + ";

                if ((*ppt)[i][j].size() > 0) {
                    // if ((*ppt)[i][j][0] < SecParaG::ACTKEYLEN) cout << "k" << (*ppt)[i][j][0];
                    // else                                       cout << "v" << (*ppt)[i][j][0] - SecParaG::ACTKEYLEN;

                    for (int l = 1; l < (*ppt)[i][j].size(); l++){
                        Model.addConstr(newv[(*ppt)[i][j][0]][Ivcount[(*ppt)[i][j][0]]] == newv[(*ppt)[i][j][l]][Ivcount[(*ppt)[i][j][l]]++]);
                        // if ((*ppt)[i][j][l] < SecParaG::ACTKEYLEN) cout << "*k" << (*ppt)[i][j][l];
                        // else                                       cout << "*v" << (*ppt)[i][j][l] - SecParaG::ACTKEYLEN;
                    }
                    sstemp += newv[(*ppt)[i][j][0]][Ivcount[(*ppt)[i][j][0]]++];
                }
                else {
                    // cout << "1";
                    GRBVar one = Model.addVar(0,1,0,'B');
                    sstemp += one;
                }
            }
            Model.addConstr(mv[i] == sstemp);
            tempallv[i + ivvarlen] = mv[i];
            // cout << endl;
        }

        if (OutPutFlag) {
            bool kflag = true, vflag = true;
            cout << endl << " ---------------------- " << endl;
            for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
                if ((*ppd)[i] != Ivcount[i]) {
                    cout << 'k' << i << "_(" << (*ppd)[i] << " != " << Ivcount[i] << ") ";
                    kflag = false;
                }
            cout << endl << "kflag = " << kflag << endl;
          
            for (int i = SecParaG::ACTKEYLEN, j = 0; i < (*ppd).size(); i++, j++)
                if ((*ppd)[i] != Ivcount[i]) {
                    cout << 'v' << j << "_(" << (*ppd)[i] << " != " << Ivcount[i] << ") ";
                    vflag = false;
            }
            cout << endl << "vflag = " << vflag << endl;
        }
        ppt++; ppd++;
    }
       
    // s_i = f(new_v, new_k)
    Arr1Int varcount(SecParaG::ACTKEYLEN + SecParaG::ACTIVLEN, 0);
    GRBVar **newvar = new GRBVar*[SecParaG::ACTKEYLEN + SecParaG::ACTIVLEN];
    for (int i = 0; i < SecParaG::ACTKEYLEN; i++) {
        if (SecParaG::VARCOUNT[i] <= 1) {
            newvar[i] = &tempkey[i];
            if (SecParaG::VARCOUNT[i] == 0)
                {Model.addConstr(tempkey[i] == 0); } // cout << "k" << i << " = 0" << endl;
        }
        else {
            newvar[i] = Model.addVars(SecParaG::VARCOUNT[i], 'B');
            Model.addGenConstrOr(tempkey[i], newvar[i], SecParaG::VARCOUNT[i]);
        }
    }

    for (int i = SecParaG::ACTKEYLEN, j = 0; i < SecParaG::ACTKEYLEN + SecParaG::ACTIVLEN; i++, j++){
        if (SecParaG::VARCOUNT[i] <= 1) {
            newvar[i] = &tempallv[j];
            if (SecParaG::VARCOUNT[i] == 0)
                {Model.addConstr(tempallv[j] == 0); }   // cout << "v" << j << " = 0" << endl;
        }
        else {
            newvar[i] = Model.addVars(SecParaG::VARCOUNT[i], 'B');
            Model.addGenConstrOr(tempallv[j], newvar[i], SecParaG::VARCOUNT[i]);
        }
    }

    for (int i = 0; i < 256; i++) {
        if (SecParaG::ANFS[i].size() == 0) {
            if (i < 128)
                {Model.addConstr(svar[i] == 0); }   // cout << "s" << i << " = 0" << endl;
            else
                {Model.addConstr(bvar[i - 128] == 0);} // cout << "b" << i - 128 << " = 0" << endl;
            continue;
        }

        // if (i < 128) cout << "s" << i << " = ";
        // else         cout << "b" << i - 128 << " = ";

        GRBLinExpr sstemp;
        for (int j = 0; j < SecParaG::ANFS[i].size(); j++) {
            // if (j > 0) cout << " + ";
            if ( SecParaG::ANFS[i][j].size() > 0 ) {
                
                // if (SecParaG::ANFS[i][j][0] < SecParaG::ACTKEYLEN) cout << "k" << SecParaG::ANFS[i][j][0];
                // else                                               cout << "v" << SecParaG::ANFS[i][j][0] - SecParaG::ACTKEYLEN;

                if (SecParaG::ANFS[i][j].size() >= 2) {
                    for (int ll = 1; ll < (int) SecParaG::ANFS[i][j].size(); ll++){
                        Model.addConstr(newvar[SecParaG::ANFS[i][j][0]][varcount[SecParaG::ANFS[i][j][0]]] == newvar[SecParaG::ANFS[i][j][ll]][varcount[SecParaG::ANFS[i][j][ll]]++]);
                        
                        // if (SecParaG::ANFS[i][j][ll] < SecParaG::ACTKEYLEN) cout << "k" << SecParaG::ANFS[i][j][ll];
                        // else                                                cout << "v" << SecParaG::ANFS[i][j][ll] - SecParaG::ACTKEYLEN;
                    }
                }
                sstemp += newvar[SecParaG::ANFS[i][j][0]][varcount[SecParaG::ANFS[i][j][0]]++];
            } else {
                GRBVar one = Model.addVar(0,1,0, 'B');
                sstemp += one;
                // cout << "1";
            }
        }

        // cout << endl;

        if (i < 128)
            Model.addConstr(svar[i] == sstemp);
        else
            Model.addConstr(bvar[i - 128] == sstemp);
    }


    if (OutPutFlag) {
        bool kflag = true, vflag = true;
        cout << endl << " ---------------------- " << endl;
        for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
            if (SecParaG::VARCOUNT[i] != varcount[i]){
                cout << 'k' << i << "_(" << SecParaG::VARCOUNT[i] << " != " << varcount[i] << ") ";
                kflag = false;
            }
        cout << endl << "kflag = " << kflag << endl;

        for (int j = SecParaG::ACTKEYLEN; j < SecParaG::ACTKEYLEN + SecParaG::ACTIVLEN; j++)
            if (SecParaG::VARCOUNT[j] != varcount[j]){
                cout << 'v' << j - SecParaG::ACTKEYLEN << "_(" << SecParaG::VARCOUNT[j] << " != " << varcount[j] << ") ";
                vflag = false;
            }
        cout << endl << "vflag = " << vflag << endl;; 

        for (int i = 0; i < 256; i++) {
            if (i < 128)
                cout << 's' << i << ": ";
            else
                cout << 'b' << i - 128 << ": ";
            if (SecParaG::ANFS[i].size() == 0) {
                cout << 0 << endl;
                continue;
            }

            for (int j = 0; j < SecParaG::ANFS[i].size(); j++) {
                if (j > 0)
                    cout << " + ";
                if (SecParaG::ANFS[i][j].size() == 0)
                    cout << "1";
                else {
                    for (vector<int>::iterator pt = SecParaG::ANFS[i][j].begin(); pt != SecParaG::ANFS[i][j].end(); pt++)
                        if (*pt < SecParaG::ACTKEYLEN)
                            cout << 'k' << *pt;
                        else
                            cout << 'v' << *pt - SecParaG::ACTKEYLEN;
                }
            }
            cout << endl;
        }
    }
}


GRBVar tap(GRBModel& model, GRBVar& x) {
    GRBVar* xs = model.addVars(2, 'B');
    model.addGenConstrOr(x, xs, 2);
    x = xs[0];
    return xs[1];
}


GRBVar funcZ(GRBModel& model, GRBVar* b, GRBVar* s, bool AEAD_FLAG, bool outputbitflag) {
    // function H
    GRBVar b12x = tap(model, b[12]);
    GRBVar s8 = tap(model, s[8]);
    model.addConstr(b12x == s8);

    GRBVar s13 = tap(model, s[13]);
    GRBVar s20 = tap(model, s[20]);
    model.addConstr(s13 == s20);

    GRBVar b95x = tap(model, b[95]);
    GRBVar s42 = tap(model, s[42]);
    model.addConstr(b95x == s42);

    GRBVar s60 = tap(model, s[60]);
    GRBVar s79 = tap(model, s[79]);
    model.addConstr(s60 == s79);

    GRBVar b12y = tap(model, b[12]);
    GRBVar b95y = tap(model, b[95]); model.addConstr(b12y == b95y);
    
    if (AEAD_FLAG){
        GRBVar s94 = tap(model, s[94]); model.addConstr(b12y == s94);
    } else {
        GRBVar s95 = tap(model, s[95]); model.addConstr(b12y == s95);
    }

    // function O
    GRBVar s93 = tap(model, s[93]);
    GRBVar b2  = tap(model, b[2] );
    GRBVar b15 = tap(model, b[15]);
    GRBVar b36 = tap(model, b[36]);
    GRBVar b45 = tap(model, b[45]);
    GRBVar b64 = tap(model, b[64]);
    GRBVar b73 = tap(model, b[73]);
    GRBVar b89 = tap(model, b[89]);

    GRBVar z = model.addVar(0, 1, 0, GRB_BINARY);
    if (outputbitflag) // keystream-bit z without s0.
        model.addConstr(z == b12x + s13 + b95x + s60 + b12y + s93 + b2 + b15 + b36 + b45 + b64 + b73 + b89);
    else
        model.addConstr(z == s[0] + b12x + s13 + b95x + s60 + b12y + s93 + b2 + b15 + b36 + b45 + b64 + b73 + b89);
    return z;
}


GRBVar funcF(GRBModel& model, GRBVar* s) {
    // GRBVar s0 = tap(model, s[0]);
    GRBVar s7  = tap(model, s[7] );
    GRBVar s38 = tap(model, s[38]);
    GRBVar s70 = tap(model, s[70]);
    GRBVar s81 = tap(model, s[81]);
    GRBVar s96 = tap(model, s[96]);

    GRBVar f = model.addVar(0, 1, 0, GRB_BINARY);
    model.addConstr(f == s7 + s38 + s70 + s81 + s96);

    return f;
}


GRBVar funcG(GRBModel& model, GRBVar* b, bool AEAD_FLAG) {
    // nonlinear feed back
    GRBVar g = model.addVar(0, 1, 0, GRB_BINARY);

    // nonlinear
    GRBVar b26 = tap(model, b[26]);
    GRBVar b56 = tap(model, b[56]);
    GRBVar b91 = tap(model, b[91]);
    GRBVar b96 = tap(model, b[96]);

    GRBVar b3 = tap(model, b[3]);
    GRBVar b67 = tap(model, b[67]);
    model.addConstr(b3 == b67);

    GRBVar b11 = tap(model, b[11]);
    GRBVar b13 = tap(model, b[13]);
    model.addConstr(b11 == b13);

    GRBVar b17 = tap(model, b[17]);
    GRBVar b18 = tap(model, b[18]);
    model.addConstr(b17 == b18);

    GRBVar b27 = tap(model, b[27]);
    GRBVar b59 = tap(model, b[59]);
    model.addConstr(b27 == b59);

    GRBVar b40 = tap(model, b[40]);
    GRBVar b48 = tap(model, b[48]);
    model.addConstr(b40 == b48);

    GRBVar b61 = tap(model, b[61]);
    GRBVar b65 = tap(model, b[65]);
    model.addConstr(b61 == b65);

    GRBVar b68 = tap(model, b[68]);
    GRBVar b84 = tap(model, b[84]);
    model.addConstr(b68 == b84);

    if (AEAD_FLAG){
        GRBVar b88 = tap(model, b[88]);
        GRBVar b92 = tap(model, b[92]);
        GRBVar b93 = tap(model, b[93]);
        GRBVar b95 = tap(model, b[95]);
        model.addConstr(b88 == b92);
        model.addConstr(b88 == b93);
        model.addConstr(b88 == b95);

        GRBVar b22 = tap(model, b[22]);
        GRBVar b24 = tap(model, b[24]);
        GRBVar b25 = tap(model, b[25]);
        model.addConstr(b22 == b24);
        model.addConstr(b22 == b25);

        GRBVar b70 = tap(model, b[70]);
        GRBVar b78 = tap(model, b[78]);
        GRBVar b82 = tap(model, b[82]);
        model.addConstr(b70 == b78);
        model.addConstr(b70 == b82);

        model.addConstr(g == b[0] + b26 + b56 + b91 + b96 + b3 + b11 + b17 + b27 + b40 + b61 + b68 + b88 + b22 + b70);
    }
    else {
        model.addConstr(g == b[0] + b26 + b56 + b91 + b96 + b3 + b11 + b17 + b27 + b40 + b61 + b68);
    }

    return g;
}


// ************************************** Grain-128 Family **************************************
// ----------------------------------------------------------------------------------------------------
void ExpressRecursivelyForGrain(const int OutPutRound, const int TargetRound, string file, bool AEAD_Flag) {
    GPoly UpdateFunction[4], ZR(13);
    GPoly Snullptr(0), updateb(30), updates(30), SAll(900);

    if (AEAD_Flag) InvExpressInitGAEAD(ZR, updateb, updates, SAll);
    else           InvExpressInitG128(ZR, updateb, updates, SAll);

    UpdateFunction[0] = Snullptr;
    UpdateFunction[1] = updates;
    UpdateFunction[2] = updateb;
    UpdateFunction[3] = SAll;

    GPoly* OutPutANF = new GPoly;
    GPoly* InPutANF = new GPoly;
    GPoly* TempPolyPt;
    GPoly TempPoly(100 * SIZEBw);
    (*OutPutANF).SetPolyLen(100 * SIZEBw);
    (*InPutANF).SetPolyLen(100 * SIZEBw);
    (*InPutANF).PolyCopy(ZR);

    int CountRound = OutPutRound;
    int FinalRound = OutPutRound - TargetRound + 1;  // 441, 841-401+1

    cout << "CountRound: ";
    time_t start = time(nullptr);
    while ((CountRound--) > FinalRound) {
        ExpressOneRound(*OutPutANF, *InPutANF, UpdateFunction, TempPoly);
        TempPolyPt = InPutANF;
        InPutANF = OutPutANF;
        OutPutANF = TempPolyPt;
        cout << CountRound << ", ";
    }
    ExpressOneRound(*OutPutANF, *InPutANF, UpdateFunction, TempPoly);
    time_t end = time(nullptr);
    cout << CountRound << ", time = " << double(end - start) << " s" << endl;

    OutPutANF->WriteValueToFile(TargetRound, file, "OutPutANF");
    delete OutPutANF;
    delete InPutANF;
}


void ExpressOneRound(GPoly& OutPutANF, GPoly& InPutANF, GPoly UpdateFunc[], GPoly& TempPoly) {
    OutPutANF.clear();
    for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++) {
        int flag = ((InPutANF.poly[pt].pterm[3] & 1) << 1) | (InPutANF.poly[pt].pterm[7] & 1);
        int flagweight = (InPutANF.poly[pt].pterm[3] & 1) + (InPutANF.poly[pt].pterm[7] & 1);

        for (int i = 7; i > 0; i--)
            InPutANF.poly[pt].pterm[i] = (InPutANF.poly[pt].pterm[i] >> 1) | ((InPutANF.poly[pt].pterm[i-1] << 31) & 0x80000000);
        InPutANF.poly[pt].pterm[0] >>= 1;
        InPutANF.poly[pt].setdeg(InPutANF.poly[pt].getdeg() - flagweight);

        if (flag) {
            InPutANF.poly[pt].pterm[4] &= 0x7fffffff;
            PolyMul(OutPutANF, UpdateFunc[flag], InPutANF.poly[pt]);
        }
        else
            OutPutANF.AddTerm(InPutANF.poly[pt]);
    }
    OutPutANF.DiscardEvenCoeff();
}


void InvExpressInitGAEAD(GPoly& ZR, GPoly& updateb, GPoly& updates, GPoly& SAll) {
    int h1[2] = { 12, 8 + 128 };
    int h2[2] = { 13 + 128, 20 + 128 };
    int h3[2] = { 95, 42 + 128 };
    int h4[2] = { 60 + 128, 79 + 128 };
    int h5[3] = { 12, 95, 94 + 128 };

    // ------------- output function -------------
    // h func
    ZR.poly[0].set(h1, 2);
    ZR.poly[1].set(h2, 2);
    ZR.poly[2].set(h3, 2);
    ZR.poly[3].set(h4, 2);
    ZR.poly[4].set(h5, 3);
    // z func
    ZR.poly[5].set(93 + 128);
    ZR.poly[6].set(2);
    ZR.poly[7].set(15);
    ZR.poly[8].set(36);
    ZR.poly[9].set(45);
    ZR.poly[10].set(64);
    ZR.poly[11].set(73);
    ZR.poly[12].set(89);
    ZR.setSize(13);
    for (int i = 0; i < ZR.getSize(); i++)
        ZR.poly[i].degree();

    // ------------- update s127 -------------
    // f func
    updates.poly[0].set(0 + 128);
    updates.poly[1].set(7 + 128);
    updates.poly[2].set(38 + 128);
    updates.poly[3].set(70 + 128);
    updates.poly[4].set(81 + 128);
    updates.poly[5].set(96 + 128);
    updates.setSize(6);
    for (int i = 0; i < updates.getSize(); i++)
        updates.poly[i].degree();
    // f func + z func
    updates.Merge(ZR);
    
    // ------------- update b127 -------------
    // s0
    updateb.poly[0].set(0 + 128);
    // g func
    updateb.poly[1].set(0);
    updateb.poly[2].set(26);
    updateb.poly[3].set(56);
    updateb.poly[4].set(91);
    updateb.poly[5].set(96);
    int g1[2] = { 3, 67 };				updateb.poly[6].set(g1, 2);
    int g2[2] = { 11, 13 };				updateb.poly[7].set(g2, 2);
    int g3[2] = { 17, 18 };				updateb.poly[8].set(g3, 2);
    int g4[2] = { 27, 59 };				updateb.poly[9].set(g4, 2);
    int g5[2] = { 40, 48 };				updateb.poly[10].set(g5, 2);
    int g6[2] = { 61, 65 };				updateb.poly[11].set(g6, 2);
    int g7[2] = { 68, 84 };				updateb.poly[12].set(g7, 2);
    int g8[4] = { 88, 92, 93, 95 };		updateb.poly[13].set(g8, 4);
    int g9[3] = { 22, 24, 25 };			updateb.poly[14].set(g9, 3);
    int g10[3] = { 70, 78, 82 };		updateb.poly[15].set(g10, 3);
    updateb.setSize(16);
    for (int i = 0; i < updateb.getSize(); i++)
        updateb.poly[i].degree();
    // s0 + g func + z func
    updateb.Merge(ZR);

    PolyMul(SAll, updates, updateb);

   if (false) {  // 检查初始化的结果
        char file[] = "InitGAEAD.txt";
        ZR.WritePolyToFile(0, file, "output function");
        updateb.WritePolyToFile(0, file, "Update b127");
        updates.WritePolyToFile(0, file, "Update s127");
        SAll.WritePolyToFile(0, file, "Update b127 * Update s127");
    }
}


// ----------------------------------- Grain-128 Init -----------------------------------
void InvExpressInitG128(GPoly& ZR, GPoly& updateb, GPoly& updates, GPoly& SAll) {
    int h1[2] = { 12, 8 + 128 };
    int h2[2] = { 13 + 128, 20 + 128 };
    int h3[2] = { 95, 42 + 128 };
    int h4[2] = { 60 + 128, 79 + 128 };
    int h5[3] = { 12, 95, 95 + 128 };

    // ------------- output function -------------
    // h func
    ZR.poly[0].set(h1, 2);
    ZR.poly[1].set(h2, 2);
    ZR.poly[2].set(h3, 2);
    ZR.poly[3].set(h4, 2);
    ZR.poly[4].set(h5, 3);
    // z func
    ZR.poly[5].set(93 + 128);
    ZR.poly[6].set(2);
    ZR.poly[7].set(15);
    ZR.poly[8].set(36);
    ZR.poly[9].set(45);
    ZR.poly[10].set(64);
    ZR.poly[11].set(73);
    ZR.poly[12].set(89);
    ZR.setSize(13);
    for (int i = 0; i < ZR.getSize(); i++)
        ZR.poly[i].degree();

    // ------------- update s127 -------------
    // f func
    updates.poly[0].set(0 + 128);
    updates.poly[1].set(7 + 128);
    updates.poly[2].set(38 + 128);
    updates.poly[3].set(70 + 128);
    updates.poly[4].set(81 + 128);
    updates.poly[5].set(96 + 128);
    updates.setSize(6);
    for (int i = 0; i < updates.getSize(); i++)
        updates.poly[i].degree();
    // f func + z func
    updates.Merge(ZR);
    
    // ------------- update b127 -------------
    // s0
    updateb.poly[0].set(0 + 128);
    // g func
    updateb.poly[1].set(0);
    updateb.poly[2].set(26);
    updateb.poly[3].set(56);
    updateb.poly[4].set(91);
    updateb.poly[5].set(96);
    int g1[2] = { 3, 67 };				updateb.poly[6].set(g1, 2);
    int g2[2] = { 11, 13 };				updateb.poly[7].set(g2, 2);
    int g3[2] = { 17, 18 };				updateb.poly[8].set(g3, 2);
    int g4[2] = { 27, 59 };				updateb.poly[9].set(g4, 2);
    int g5[2] = { 40, 48 };				updateb.poly[10].set(g5, 2);
    int g6[2] = { 61, 65 };				updateb.poly[11].set(g6, 2);
    int g7[2] = { 68, 84 };				updateb.poly[12].set(g7, 2);
    updateb.setSize(13);
    for (int i = 0; i < updateb.getSize(); i++)
        updateb.poly[i].degree();
    // s0 + g func + z func
    updateb.Merge(ZR);

    PolyMul(SAll, updates, updateb);

   if (false) {  // 检查初始化的结果
        string file = "InitG128.txt";
        ZR.WritePolyToFile(0, file, "output function");
        updateb.WritePolyToFile(0, file, "Update b127");
        updates.WritePolyToFile(0, file, "Update s127");
        SAll.WritePolyToFile(0, file, "Update b127 * Update s127");
    }
}



void GReadANF(int &TargetRound, GPoly& InPutANF, string file, bool InputCoeffFlag) {
    ifstream fin;
    string line1, c1;
    uint32_t temp = 0, tempdegk = 0, tempcoeff = 0;

    fin.open(file, ios_base::in);
    getline(fin, line1);
    fin >> c1 >> TargetRound >> temp;
    cout << line1 << endl << c1 << ' ' << TargetRound << ' ' << temp << endl;
    InPutANF.SetPolyLen(temp);
    InPutANF.setSize(temp);

    time_t starttime = time(nullptr);
    if (InputCoeffFlag)
        for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++) {
            fin >> hex >> tempdegk >> tempcoeff;
            for (uint8_t pd = 0; pd < 8; pd++)
                fin >> hex >> InPutANF.poly[pt].pterm[pd];
            fin >> hex >> temp;
            InPutANF.poly[pt].setdegk(tempdegk);
            InPutANF.poly[pt].setCoeff(tempcoeff);
            InPutANF.poly[pt].setdeg(temp);
        }
    else {
        for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++) {
            fin >> hex >> tempdegk;
            for (uint8_t pd = 0; pd < 8; pd++)
                fin >> hex >> InPutANF.poly[pt].pterm[pd];
            fin >> hex >> temp;
            InPutANF.poly[pt].setdegk(tempdegk);
            InPutANF.poly[pt].setCoeff(1);
            InPutANF.poly[pt].setdeg(temp);
        }
    }
    InPutANF.DiscardEvenCoeff();
    time_t endtime = time(nullptr);

    cout << "Load ANF: " << double(endtime - starttime) << " s" << endl;
    fin.close();
}


void GReadANF(int &TargetRound, GPoly& InPutANF, SecParaG::MapGPoly& SP, string file, bool TPInputCeoffFlag, bool MPInputCoeffFlag) {
    ifstream fin;
    string line, c1, c2, c3;
    uint32_t temp = 0, tempdegk = 0, tempcoeff = 0;

    fin.open(file, ios_base::in);
    if ( !fin.is_open() )
        return ;

    getline(fin, line);
    fin >> c1 >> TargetRound >> temp;
    cout << line << endl << c1 << " " << TargetRound << " " << temp << endl;
    InPutANF.SetPolyLen(temp);
    InPutANF.setSize(temp);

    time_t starttime = time(nullptr);
    if (TPInputCeoffFlag)
        for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++)
        {
            fin >> hex >> tempdegk >> tempcoeff;
            for (uint8_t pd = 0; pd < 8; pd++)
                fin >> hex >> InPutANF.poly[pt].pterm[pd];
            fin >> hex >> temp;

            if (tempdegk == 0xffffffff)
                InPutANF.poly[pt].setdegk(-1);
            else if (tempdegk > SecParaG::MODELVARLEN)
                InPutANF.poly[pt].setdegk(SecParaG::MODELVARLEN);
            else
                InPutANF.poly[pt].setdegk(tempdegk);

            InPutANF.poly[pt].setCoeff(tempcoeff);
            InPutANF.poly[pt].setdeg(temp);
        }
    else
        for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++)
        {
            fin >> hex >> tempdegk;
            for (uint8_t pd = 0; pd < 8; pd++)
                fin >> hex >> InPutANF.poly[pt].pterm[pd];
            fin >> hex >> temp;

            if (tempdegk == 0xffffffff)
                InPutANF.poly[pt].setdegk(-1);
            else if (tempdegk > SecParaG::MODELVARLEN)
                InPutANF.poly[pt].setdegk(SecParaG::MODELVARLEN);
            else
                InPutANF.poly[pt].setdegk(tempdegk);

            InPutANF.poly[pt].setCoeff(1);
            InPutANF.poly[pt].setdeg(temp);
        }
    InPutANF.DiscardEvenCoeff();


    int value = 0, ssize = 0;
    fin >> line;
    ssize = stoi(line);
    getline(fin, line);
    cout << ssize << line << endl;

    fin >> dec;
    while (ssize--) {
        if (MPInputCoeffFlag)
            fin >> value;
        
        int cc = 0, tvalue = 0;
        fin >> cc;

        SecParaG::MGTerm termtemp;

        while(cc--) {
            fin >> tvalue;
            termtemp.insert(tvalue);
        }

        if (MPInputCoeffFlag)
            SP.InSert(SecParaG::MapGPair(termtemp, value));
        else
            SP.InSert(termtemp);
    }

    time_t endtime = time(nullptr);
    cout << "Load ANF: " << double(endtime - starttime) << " s" << endl;
    fin.close();

    if (false)
        InPutANF.show(TargetRound);
}


void TestBalanced(SecParaG::MapGPoly Poly[], int Len,  string file) {
    const int ThreadNum = 32, shift = 20;
    int totalnum = (1 << shift);

    unordered_set< Keyterm> keysets;
    vector< Keyterm> keyvalues;

    Arr1Int count(Len+1, 0);

    while (keyvalues.size() < totalnum) {
        random_device rd;
        uniform_int_distribution<int > u(0, 1);
        Keyterm tmpkey(0);
        for (int i = 0; i < 128; i++)
            tmpkey[i] = u(rd);

        auto it = keysets.find(tmpkey);

        if (it == keysets.end()) {
            keysets.insert(tmpkey);
            keyvalues.push_back(tmpkey);
        }
    }
    keysets.clear();
    cout << "Random Keys have been completed!" << endl;


    #pragma omp parallel for num_threads (ThreadNum)
    for (auto PPT = keyvalues.begin(); PPT != keyvalues.end(); PPT++) {

        bool keyflag = 0;

        for (int ppt = 0; ppt < Len; ppt++) {
            int polyvalue = 0;
            for (auto pt = Poly[ppt].rbegin(); pt != Poly[ppt].rend(); pt++) {
                if ( (pt->second & 1) == 0 ) continue;

                int termvalue = 1;
                for (auto pr = pt->first.begin(); pr != pt->first.end(); pr++) {
                    termvalue &= (*PPT)[*pr];
                }
                polyvalue ^= termvalue;
            }

            #pragma omp critical
            count[ppt] += polyvalue;

            keyflag |= polyvalue;
        }

        #pragma omp critical
        count[Len] += keyflag;
    }
    keyvalues.clear();

    double *ret = new double[Len];
    for (int i = 0; i < Len + 1; i++)
        ret[i] = (double) count[i] / (double) totalnum;

    fstream fout; fout.open(file, ios_base::app);
    fout << endl << "Balancedness: " << endl;
    for (int i = 0; i < Len; i++)
        fout << "Poly" << i << ": " << ret[i] << endl;
    fout << "OneFlag: " << ret[Len] << endl;
    fout.close();

    cout << endl << "Balancedness: " << endl;
    for (int i = 0; i < Len; i++)
        cout << "Poly" << i << ": " << ret[i] << endl;
    cout << "OneFlag: " << ret[Len] << endl;
    cout << endl;
}



// --------------------------------------------- Test --------------------------------------------- 

int DegEstForLowBound(GPoly ANF, int IRound, IvGterm Cube, string files, int ModelType, IvGterm DCube, bool guassflag, int guassloc, int wrongiv, bool AEAD_FLAG) {
    int ParallelNum = 4;
    int SingleThread = 7;
    int mindeg = 999;

    string ofile;
    if (AEAD_FLAG) ofile = "NewState(Grain128AEAD).txt"; 
    else ofile = "NewState(Grain128).txt";

    SecParaG::ParameterSelection(Cube, ModelType, DCube, guassflag, guassloc, wrongiv, "ModelRequired.txt", ofile, AEAD_FLAG);

    SecParaG::MapGPoly TmpSp; G_CCount.store(0); G_AllNum.store(ANF.getSize());
    #pragma omp parallel for num_threads(ParallelNum) schedule(dynamic, 3)
    for (int pt = 0; pt < ANF.getSize(); pt++) {

        int mindeg = Grain128AEADTest(ANF.poly[pt], Cube, IRound, SingleThread, ModelType, DCube, AEAD_FLAG);
        if (mindeg >= 0) {
            #pragma omp critical
            {
                if (mindeg > ANF.poly[pt].getdegk())
                    mindeg = ANF.poly[pt].getdegk();
            }
        }
    }
    if (mindeg == 999) mindeg = -1;
    
    if (false) {
        ofstream fout; fout.open(files, ios_base::app);
        fout << "Cube(" << Cube.count() << "); zvar:";
        IvGterm TmpC = Cube | DCube;
        for (int i = 0; i < 96; i++)
            if (!TmpC.test(i)) 
                fout << " v" << i;
        if (DCube.count()){
            fout << "; dvar:";
            for (int i = 0; i < 96; i++)
                if (DCube.test(i))
                    fout << " v" << i;
            if (guassflag) 
                fout << "; Guass Right!";
            else{
                fout << "; Guass Wrong (v" << guassloc + 60 * SecParaG::DyVarShiftFlag << ")";
            }
        }
        fout << "; deg_lowbound = " << mindeg << endl;
    }
    return mindeg;
}


int Grain128AEADTest(GTerm Pterm, IvGterm &Cube, int IRound, int ThreadNum, int ModelType, IvGterm DCube, bool AEAD_FLAG) {

    if ((Pterm.getCoeff() & 1) == 0) {
        return -1;
    }
    else
        Pterm.setCoeff(1);

    int StartRound = 0;
    GRBEnv Env = GRBEnv();
    Env.set(GRB_IntParam_LogToConsole, 0);
    GRBModel Model = GRBModel(Env);
    if (ThreadNum != 0) Model.set(GRB_IntParam_Threads, ThreadNum);
    // if (TimeLimit != 0) Model.set(GRB_DoubleParam_TimeLimit, TimeLimit);

    GRBVar *kvar = Model.addVars(SecParaG::ACTKEYLEN, 'B');
    GRBVar *vvar = Model.addVars(96 , 'B');
    GRBVar *svar = Model.addVars(128, 'B');
    GRBVar *bvar = Model.addVars(128, 'B');

    GRBLinExpr key_sum;
    for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
        key_sum += kvar[i];
    Model.setObjective(key_sum, GRB_MINIMIZE);
    // -----------------------------

    for (int i = 0; i < 96; i++) {
        if (Cube.test(i))        Model.addConstr(vvar[i] == 1);
        else if (!DCube.test(i)) Model.addConstr(vvar[i] == 0);
    }

    // ---------------------------------------------------------
    // Model.addConstr(key_sum == 0);
    // GRBLinExpr vsum;
    // for (int i = 0; i < 96; i++)
    //     vsum += vvar[i];
    // Model.setObjective(vsum, GRB_MAXIMIZE);
    // ---------------------------------------------------------

    if (ModelType == 0) {
        for (int i = 0; i < 96; i++)
            Model.addConstr(svar[i] == vvar[i]);

        if (AEAD_FLAG)
            Model.addConstr(svar[127] == 0);

        for (int i = 0; i < 128; i++)
            Model.addConstr(bvar[i] == kvar[i]);
    }
    else {
        StartRound = SecParaG::REDUCEROUND;
        GInitilization(Model, svar, bvar, kvar, vvar);
    }

    for (int r = StartRound; r < IRound; r++) {
        GRBVar z = funcZ(Model, bvar, svar, AEAD_FLAG);
        GRBVar *zs = Model.addVars(2, 'B');
        Model.addGenConstrOr(z, zs, 2);
        
        GRBVar f = funcF(Model, svar);
        GRBVar g = funcG(Model, bvar, AEAD_FLAG);

        GRBVar news = Model.addVar(0, 1, 0, GRB_BINARY);
        Model.addConstr(news == zs[0] + f);

        GRBVar newb = Model.addVar(0, 1, 0, GRB_BINARY);
        Model.addConstr(newb == zs[1] + g);

        for (int i = 0; i < 127; i++) {
            bvar[i] = bvar[i + 1];
            svar[i] = svar[i + 1];
        }
        bvar[127] = newb;
        svar[127] = news;
    }

    for (int pt = 0; pt < 128; pt++) {
        if ((Pterm.pterm[pt >> 5] >> (31 - (pt & 31))) & 1)
            Model.addConstr(bvar[pt] == 1);
        else
            Model.addConstr(bvar[pt] == 0);
    }

    for (int pt = 128; pt < 256; pt++) {
        if ((Pterm.pterm[pt >> 5] >> (31 - (pt & 31))) & 1)
            Model.addConstr(svar[pt - 128] == 1);
        else
            Model.addConstr(svar[pt - 128] == 0);
    }

    Model.update();
    Model.optimize();

    if (Model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
        return round(Model.get(GRB_DoubleAttr_ObjVal));

    }
    else {
        return -1;
    }
}