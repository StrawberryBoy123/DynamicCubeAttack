#include "ParameterSelection.h"

// ------------------------------------ SecParaG ------------------------------------

int SecParaG::REDUCEROUND = 0;
int SecParaG::ACTKEYLEN = 128;
int SecParaG::ACTIVLEN = 96;
int SecParaG::MODELVARLEN = 224;
Arr1Int SecParaG::WrongIV(2, 0);
int SecParaG::WrongLocation = 0;  // (0: constant; 1: k_i_1 * v_i_1; 2: k_i_2 * v_i_2)
bool SecParaG::DyVarShiftFlag = false;   // false: dynamic cube variables belong to [0, 31]; true: dynamic cube variables belong to [60, 91]
Arr3Int SecParaG::NewIVANFs;
Arr3Int SecParaG::XKEYs;
Arr1Int SecParaG::IVCOUNT;
Arr2Int SecParaG::IVCOUNTs;
Arr3Int SecParaG::ANFS(256);
Arr1Int SecParaG::VARCOUNT;
Arr3Int SecParaG::VTOK;
Arr3Int SecParaG::CONDITIONS;
Arr4Int SecParaG::MODELXV;
Arr4Int SecParaG::NewIVANFsARR;
vector<string> SecParaG::STRPOLY;
vector<vector<string>> SecParaG::STRPOLYARR;


void SecParaG::ParameterClear()
{
    REDUCEROUND = 0;
    ACTKEYLEN = 128;
    ACTIVLEN = 96;
    MODELVARLEN = 224;
    WrongIV = {0, 0};
    WrongLocation = 0;
    NewIVANFs.clear();
    XKEYs.clear(); 
    IVCOUNT.clear();
    IVCOUNTs.clear();
    VARCOUNT.clear();
    VTOK.clear();
    CONDITIONS.clear();
    MODELXV.clear();
    NewIVANFsARR.clear();
    STRPOLY.clear();
    STRPOLYARR.clear();

    for (int i = 0; i < 256; i++)
        ANFS[i].clear();
} 


void SecParaG::ParameterSelection(IvGterm CubeFlag, int LOOP, IvGterm DCube, bool guassflag, int guassloc, int wrongiv, string ofile1, string ofile2, bool AEAD_FLAG) {
    ParameterClear();
    if (LOOP == 0) return ;

    bool Outputflag1 = false;  // process phase
    bool Outputflag2 = true;   // final phase

    cout << "Model " << LOOP << " are selected! ParameterSelection OK!" << endl;
    REDUCEROUND = 32 * LOOP;
    WrongLocation = wrongiv;
    
    if (DCube.count())
        ParameterGenerator(CubeFlag, DCube, ANFS, NewIVANFsARR, LOOP, guassflag, guassloc, Outputflag1, ofile2, AEAD_FLAG);
    else 
        ParameterGenerator(CubeFlag, ANFS, NewIVANFsARR, LOOP, Outputflag1, ofile2, AEAD_FLAG);
  
    ACTIVLEN += (WrongLocation > 0);
    for (auto ppt = NewIVANFsARR.begin(); ppt != NewIVANFsARR.end(); ppt++)
        ACTIVLEN += (*ppt).size();
    MODELVARLEN = ACTKEYLEN + 96 + (WrongLocation > 0);

    IVCOUNTs.clear();
    int tempivlen = MODELVARLEN;
    for (auto ppt = NewIVANFsARR.begin(); ppt != NewIVANFsARR.end(); ppt++){
        Arr1Int tmpIVCOUNT(tempivlen, 0);

        for (auto ppd = ppt->begin(); ppd != ppt->end(); ppd++) {
            for (int j = 1; j < (*ppd).size(); j++) {
                for (auto pt = (*ppd)[j].begin(); pt != (*ppd)[j].end(); pt++)
                    tmpIVCOUNT[*pt] += 1;
            }
        }

        IVCOUNTs.push_back(tmpIVCOUNT);
        tempivlen += ppt->size();
    }

    for (int i = 0; i < tempivlen; i++)
        VARCOUNT.push_back(0);

    for (int i = 0; i < 256; i++)
        for (int j = 0; j < ANFS[i].size(); j++)
            for (Arr1Int::iterator pt = ANFS[i][j].begin(); pt != ANFS[i][j].end(); pt++)
                VARCOUNT[*pt] += 1;
            
    for (int i = 0; i < 128; i++)
        STRPOLY.push_back("k" + to_string(i));

    for (int i = 0; i < XKEYs.size(); i++) {
        string temp = "(";
        for (int j = 0; j < XKEYs[i].size(); j++) {
            if (j > 0)
                temp += " + ";

            if (XKEYs[i][j].size() == 0)
                temp += "1";
            else
                for (int k = 0; k < XKEYs[i][j].size(); k++) {
                    if (k > 0)
                        temp += "*";
                    temp += "k" + to_string(XKEYs[i][j][k]);
                }
        }
        temp += ")";
        STRPOLY.push_back( temp );
    }

    if (Outputflag2) {
        ofstream fout;
        fout.open(ofile1, ios_base::app);

        fout << "-------------- Cube --------------" << endl;
        fout << "Cube(" << CubeFlag.count() << "): ";
        for (int i = 0 ; i < 96; i++)
            if (CubeFlag.test(i))
                fout << "v" << i << " ";

        fout << endl << endl << " ----------------------- State ANFs ----------------------- " << endl;
        for (int i = 0; i < ANFS.size(); i++) {
            if (i < 128)
                fout << 's' << i << " = ";
            else
                fout << 'b' << i - 128 << " = ";

            if (!ANFS[i].size()){
                fout << 0 << endl;
                continue;
            }
            for (int j = 0; j < ANFS[i].size(); j++) {
                if (j > 0)
                    fout << " + ";
                
                if (ANFS[i][j].size() == 0)
                    fout << '1';
                else
                    for (int k = 0; k < ANFS[i][j].size(); k++) {
                        if (k > 0)
                            fout << "*";
                        if (ANFS[i][j][k] < ACTKEYLEN)
                            fout << 'k' << ANFS[i][j][k];
                        else if (ANFS[i][j][k] >= ACTKEYLEN)
                            fout << 'v' << ANFS[i][j][k] - ACTKEYLEN;
                    }
            }
            fout << endl;
        }

        fout << endl << endl << " ----------------------- CONDITIONS ----------------------- " << endl;
        for (auto ppt = CONDITIONS.begin(); ppt != CONDITIONS.end(); ppt++) {
            Arr2Int TmpC = *ppt;
            fout << "Dynamic Cube Vars: v" << TmpC[0][0] << " = ";
            for (auto ppd = TmpC.begin() + 1; ppd != TmpC.end(); ppd++) {
                if (ppd != TmpC.begin() + 1) fout << " + ";
                if (ppd->size() == 0) fout << "1";
                else 
                    for (auto ppf = ppd->begin(); ppf != ppd->end(); ppf++){
                        if (ppf != ppd->begin()) fout << " * ";
                        if ((*ppf) < ACTKEYLEN) fout << "k" << (*ppf);
                        else fout << "v" << (*ppf) - ACTKEYLEN;
                    }
            }
            fout << endl;
        }
        
        fout << endl << endl << " ----------------------- NewIVANFs ----------------------- " << endl;
        int co = 0;
        for (auto ppt = NewIVANFsARR.begin(); ppt != NewIVANFsARR.end(); ppt++) {
            fout << endl << " ------------- Arr " << co++ << " ------------- " << endl;
            for (int i = 0; i < (*ppt).size(); i++) {
                fout << 'v' << (*ppt)[i][0][0] << " = "; 
                for (int j = 1; j < (*ppt)[i].size(); j++) {
                    if (j > 1)
                        fout << " + ";
                    
                    if ((*ppt)[i][j].size() == 0)
                        fout << '1';
                    else
                        for (int k = 0; k < (*ppt)[i][j].size(); k++) {
                            if (k > 0)
                                fout << "*";
                            if ((*ppt)[i][j][k] < ACTKEYLEN)
                                fout << 'k' << (*ppt)[i][j][k];
                            else
                                fout << 'v' << (*ppt)[i][j][k] - ACTKEYLEN;
                        }
                }
                fout << endl;
            }
        }

        fout << endl << endl << " ----------------------- xKey ----------------------- " << endl;
        for (int i = 0; i < XKEYs.size(); i++) {
            fout << 'k' << i+128 << " = ";
            for (int j = 0; j < XKEYs[i].size(); j++) {
                if (j > 0)
                    fout << " + ";
                
                if (XKEYs[i][j].size() == 0)
                    fout << '1';
                else
                    for (int k = 0; k < XKEYs[i][j].size(); k++) {
                        if (k > 0)
                            fout << "*"; 
                        fout << 'k' << XKEYs[i][j][k];
                    }
            }
            fout << endl;
        }

        fout << endl << endl << "-------------- STRPOLY --------------" << endl;
        for (int i = 0; i < ACTKEYLEN; i++)
            fout << "k" << i << " = " << STRPOLY[i] << endl;


        fout << endl << endl << "-------------- COUNT --------------" << endl;
        co = 0;
        for (auto ppt = IVCOUNTs.begin(); ppt != IVCOUNTs.end(); ppt++){
            fout << endl << " -IVCOUNT" << co << "(k vars): ";
            for (int i = 0; i < ACTKEYLEN; i++)
                fout << "( k" << i << ", " << (*ppt)[i] << ") ";
            fout << endl << " -IVCOUNT" << co++ << "(v vars): ";
            for (int i = ACTKEYLEN, j = 0; i < (*ppt).size(); i++, j++)
                fout << "( v" << j << ", " << (*ppt)[i] << ") ";
        }           
        
        fout << endl << " - VARCOUNT(k vars): ";
        for (int i = 0; i < ACTKEYLEN; i++)
            fout << "( k" << i << ", " << VARCOUNT[i] << ") ";
        fout << endl << " - VARCOUNT(v vars): ";
        for (int i = ACTKEYLEN, j = 0; i < ACTKEYLEN + ACTIVLEN; i++, j++)
            fout << "( v" << j << ", " << VARCOUNT[i] << ") ";
        fout << endl << "*************************** END ***************************" << endl << endl << endl;
        fout.close();
    }
}


// for Superpoly Recovery of Dynamic Cube Attack
void SecParaG::ParameterGenerator(IvGterm Cube, IvGterm DCube, Arr3Int& xS, Arr4Int& xIv, int LOOP, bool guassflag, int guassloc, bool outputflag, string file, bool AEAD_FLAG) {
    
    ofstream fout;
    xPoly *s = new xPoly [128];
    xPoly *b = new xPoly [128];
    xPoly *TempP = new xPoly [LOOP * 96];
    xPoly **xpf = new xPoly* [3];
    xPoly *g, *f, *z;
    IvGterm CubeFlag = Cube | DCube;

    int DyVarShift = DyVarShiftFlag * 60; 
    cout << "Dynamic Cube Attack" << endl;
    xS.clear();
    int kcount = 128, nkcount = 0, vcount = 96, Loop = 0;

    if (WrongLocation){
        WrongIV[1] = vcount;
        vcount += 1;
    }

    while (Loop < LOOP) {
        g = new xPoly [32]; f = new xPoly [32]; z = new xPoly [32];

        if (AEAD_FLAG)
            xGrain128AEAD_32R(CubeFlag, s, b, g, f, z, Loop * 32, file, Loop == 0);
        else
            xGrain128_32R(CubeFlag, s, b, g, f, z, Loop * 32, file, Loop == 0);

        xpf[0] = g; xpf[1] = f; xpf[2] = z; xIv.push_back({});
        for (int ppt = 0; ppt < 3; ppt++) {
            for (int loc = 0; loc < 32; loc++) {
                if (xpf[ppt][loc].Size > 1) {
                    xPoly txpoly;
                    
                    int tkeynum = 0, tivnum = 0;
                    for (int j = 0; j < xpf[ppt][loc].Size; j++)
                        if (xpf[ppt][loc].poly[j].is_const())
                            tkeynum += 1;
                        else
                            tivnum += 1;
                    
                    if (tkeynum > 1) {
                        for (int j = 0; j < xpf[ppt][loc].Size; j++) {
                            if (xpf[ppt][loc].poly[j].is_const())
                                TempP[nkcount].poly[TempP[nkcount].Size++] = xpf[ppt][loc].poly[j];
                        }
                        quickSort(TempP[nkcount].poly, 0, int(TempP[nkcount].Size) - 1);

                        bool newkeyflag = true;
                        int keyloc = 128;
                        for (int pt = 0; pt < nkcount; pt++) {
                            if (TempP[nkcount] == TempP[pt]) {
                                keyloc += pt;
                                newkeyflag = false;
                                TempP[nkcount].Clear();
                                break;
                            }
                        }

                        if (newkeyflag) {
                            txpoly.poly[txpoly.Size].pterm[(kcount + 640) >> 5] |= (1 << (0x1f ^ (0x1f & (kcount + 640))));
                            txpoly.poly[txpoly.Size++].setdeg(0);
                            kcount++; nkcount++;
                        } else {
                            txpoly.poly[txpoly.Size].pterm[(keyloc + 640) >> 5] |= (1 << (0x1f ^ (0x1f & (keyloc + 640))));
                            txpoly.poly[txpoly.Size++].setdeg(0);
                        }

                    } else if (tkeynum == 1)
                        for (int j = 0; j < xpf[ppt][loc].Size; j++)
                            if (xpf[ppt][loc].poly[j].is_const())
                                txpoly.poly[txpoly.Size++] = xpf[ppt][loc].poly[j];

                    for (int j = 0; j < xpf[ppt][loc].Size; j++)
                        if (!xpf[ppt][loc].poly[j].is_const())
                            txpoly.poly[txpoly.Size++] = xpf[ppt][loc].poly[j];
                    
                    // --------------- DCA ---------------
                    if ((Loop == 0) && (ppt == 2) && DCube.test(loc + DyVarShift)) {
                        int Wrongloc = 1;
                        // txpoly.show(32, "Round(0:32)");

                        xTerm tm; tm.pterm[(loc + DyVarShift) >> 5] = 1 << (0x1f ^ ((loc + DyVarShift) & 0x1f)); tm.setdeg(1);
                        txpoly.AddTerm(tm); txpoly.RemoveDup();
                        
                        Arr2Int tepCondition = { { loc + DyVarShift }, };
                        // cout << "v" << loc + DyVarShift << " = ";
                        for (int j = 0; j < txpoly.Size; j++) {
                            // if (j > 0) cout << " + ";
                            bool flag = false;
                            Arr1Int tterm;
                            for (int i = 0; i < 1280; i++) {
                                if ((txpoly.poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1) {
                                    // if (flag) cout << "*";
                                    if (i < 640) { tterm.push_back(i + 640); } // flag = true; cout << "v" << i;
                                    else { tterm.push_back(i - 640); } // flag = true; cout << "k" << i - 640;
                                }
                            }

                            if ((tterm.size() == 2) && ( ( (tterm[0] < 640) && (tterm[1] >= 640) ) || ( (tterm[0] >= 640) && (tterm[1] < 640) ) ) ) {
                                if ((WrongLocation == Wrongloc) && (!guassflag) && (guassloc == loc) ) {
                                    if (tterm[0] >= 640) WrongIV[0] = tterm[0] - 640;
                                    else                 WrongIV[0] = tterm[1] - 640;
                                    // cout << "(" << WrongIV[0] << ")";
                                    tepCondition.push_back({WrongIV[1] + 640});
                                }
                                Wrongloc += 1;
                            }
                            tepCondition.push_back(tterm);
                        }

                        if ((WrongLocation == 0) && ((!guassflag) && (guassloc == loc)) )
                            tepCondition.push_back({});
                           
                        // cout << endl;
                        CONDITIONS.push_back(tepCondition);
                        xpf[ppt][loc].Size = 0;
                        txpoly.Size = 0;
                    }
                    // --------------- DCA ---------------

                    if(txpoly.Size > 1) {
                        Arr2Int tpoly = { {vcount++} };
                        for (int j = 0; j < txpoly.Size; j++) {
                            Arr1Int tterm;
                            for (int i = 0; i < 1280; i++)
                                if ((txpoly.poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                                {
                                    if (i < 640)
                                        tterm.push_back(i + 640);
                                    else
                                        tterm.push_back(i - 640);
                                }
                            tpoly.push_back(tterm);
                        }

                        xPoly txpoly2(1);
                        txpoly2.poly[0].pterm[tpoly[0][0] >> 5] |= (1 << (0x1f ^ (tpoly[0][0] & 0x1f)));
                        txpoly2.poly[0].setdeg(1);
                        txpoly2.Size = 1;
                        xIv[2*Loop].push_back(tpoly);
                        xpf[ppt][loc].PolyCopy(txpoly2);
                    }
                    else
                        xpf[ppt][loc].PolyCopy(txpoly);
                }
            }
        }

        if (Loop == 0)
        for (int ppf = 0, l = 0; ppf < 32; ppf++){
            if (DCube.test(ppf + DyVarShift)) {
                for (int j = 0; j < g[ppf].Size; j++) {
                    Arr1Int tterm;
                    for (int i = 0; i < 1280; i++)
                        if ((g[ppf].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1) {
                            if (i < 640)
                                tterm.push_back(i + 640);
                            else
                                tterm.push_back(i - 640);
                        }
                    CONDITIONS[l++].push_back(tterm);
                }
            }
        }
        // cout << "Loop = " << Loop << endl;

        if (Loop == LOOP - 1){
            for (int i = 0, j = 96; i < 32; i++, j++){
                if ((Loop == 0) && DCube.test(i + DyVarShift)) {
                    if ((!guassflag) && (guassloc == i)){
                        xPoly TmpP; TmpP.Size = 1;

                        if (WrongLocation)
                        {
                            TmpP.poly[0].pterm[(WrongIV[1]) >> 5] |= 1 << (31 - (WrongIV[1] & 31));   // 标注错误位置
                            TmpP.poly[0].setdeg(1);
                        }

                        s[j] = f[i] + g[i] + TmpP;
                        b[j] = TmpP;
                    }
                    else {
                        s[j] = f[i] + g[i];
                        b[j].Clear();
                    }
                }
                else {
                    s[j] = f[i] + z[i];
                    b[j] = g[i] + z[i];
                }
            }
        }
        else {
            xIv.push_back({});
            for (int loc = 96, pt = 0; loc < 128; loc++, pt++) {
                if ( (Loop == 0) && DCube.test(pt + DyVarShift) && (guassflag || ( (!guassflag) && (pt != guassloc) ) ) )
                    s[loc] = f[pt] + g[pt];
                else if ( (Loop == 0) && DCube.test(pt + DyVarShift) && (!guassflag) && (pt == guassloc) ) {
                    xPoly ErrorTerm; ErrorTerm.Size = 1;

                    if (WrongLocation) {
                        ErrorTerm.poly[0].pterm[(WrongIV[1]) >> 5] |= 1 << (31 - ((WrongIV[1]) & 31));   // 标注错误位置
                        ErrorTerm.poly[0].setdeg(1);
                    }

                    s[loc] = f[pt] + g[pt] + ErrorTerm;
                }
                else 
                    s[loc] = f[pt] + z[pt];
                
                if (s[loc].Size > 1) {
                    Arr2Int tpoly = { {vcount++} };
                    for (int j = 0; j < s[loc].Size; j++) {
                        Arr1Int tterm;
                        for (int i = 0; i < 1280; i++)
                            if ((s[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1) {
                                if (i < 640)
                                    tterm.push_back(i + 640);
                                else
                                    tterm.push_back(i - 640);
                            }
                        tpoly.push_back(tterm);
                    }

                    xPoly txpoly(1);
                    txpoly.poly[0].pterm[tpoly[0][0] >> 5] |= (1 << (0x1f ^ (tpoly[0][0] & 0x1f)));
                    txpoly.poly[0].setdeg(1);
                    txpoly.Size = 1;
                    xIv[2 * Loop + 1].push_back(tpoly);
                    s[loc].PolyCopy(txpoly);
                }
            }

            for (int loc = 96, pt = 0; loc < 128; loc++, pt++){
                if ( (Loop == 0) && DCube.test(pt + DyVarShift) && (guassflag || ( (!guassflag) && (pt != guassloc) ) ) )
                    b[loc].Clear();
                else if ( (Loop == 0) && DCube.test(pt + DyVarShift) && (!guassflag) && (pt == guassloc) ){
                    b[loc].Clear();
                    b[loc].Size = 1;

                    if (WrongLocation) {
                        b[loc].poly[0].pterm[(WrongIV[1]) >> 5] |= 1 << (31 - (31 & (WrongIV[1])));
                        b[loc].poly[0].setdeg(1);
                    }
                }
                else 
                    b[loc] = g[pt] + z[pt];

                if (b[loc].Size > 1) {
                    Arr2Int tpoly = { {vcount++} };
                    for (int j = 0; j < b[loc].Size; j++) {
                        Arr1Int tterm;
                        for (int i = 0; i < 1280; i++)
                            if ((b[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1) {
                                if (i < 640)
                                    tterm.push_back(i + 640);
                                else
                                    tterm.push_back(i - 640);
                            }
                        tpoly.push_back(tterm);
                    }

                    xPoly txpoly(1);
                    txpoly.poly[0].pterm[tpoly[0][0] >> 5] |= (1 << (0x1f ^ (tpoly[0][0] & 0x1f)));
                    txpoly.poly[0].setdeg(1);
                    txpoly.Size = 1;
                    xIv[2 * Loop + 1].push_back(tpoly);
                    b[loc].PolyCopy(txpoly);
                }
            }
        }

        if (outputflag) {
            cout << "Write to file now...";
            ofstream fout;
            fout.open(file, ios_base::app);
            if (Loop == 0){
                fout << "-------------- Cube(" << CubeFlag.count() << ") --------------" << endl;
                for (int i = 0; i < CubeFlag.size(); i++)
                    if (CubeFlag.test(i))
                        fout << 'v' << i << ' ';
                fout << endl;
            }
            fout << endl << "-------------- After "<< (Loop+1)*32 <<"-Round State (updata variables) --------------" << endl << endl;
            fout.close();

            for (int pd = 0; pd < 32; pd++)
                g[pd].WritePolyToFile_Simple(file, "g" + to_string(pd));
            for (int pd = 0; pd < 32; pd++)
                f[pd].WritePolyToFile_Simple(file, "f" + to_string(pd));
            for (int pd = 0; pd < 32; pd++)
                z[pd].WritePolyToFile_Simple(file, "z" + to_string(pd));
            for (int pd = 0; pd < 128; pd++)
                s[pd].WritePolyToFile_Simple(file, "s" + to_string(pd));
            for (int pd = 0; pd < 128; pd++)
                b[pd].WritePolyToFile_Simple(file, "b" + to_string(pd));

            fout.open(file, ios_base::app);
            int co = 0;
            for (auto ppt = xIv.begin(); ppt != xIv.end(); ppt++) {
                fout << "-------------- updata variables " << co++ << " --------------" << endl;
                for (int i = 0; i < (int) (*ppt).size(); i++) {
                    fout << 'v' << (*ppt)[i][0][0] << " = ";
                    for (int j = 1; j < (*ppt)[i].size(); j++) {
                        if (j > 1)
                            fout << " + ";

                        if ((*ppt)[i][j].size() == 0)
                            fout << '1';
                        else
                            for (int k = 0; k < (*ppt)[i][j].size(); k++) {
                                if (k > 0)
                                    fout << " * ";
                                if ((*ppt)[i][j][k] < 640)
                                    fout << 'k' << (*ppt)[i][j][k];
                                if ((*ppt)[i][j][k] >= 640)
                                    fout << 'v' << (*ppt)[i][j][k] - 640;
                            }
                    }
                    fout << endl;
                }
                fout << endl << endl;
            }

            fout << endl << "-------------- Conditions --------------" << endl;
            for (auto ppt = CONDITIONS.begin(); ppt != CONDITIONS.end(); ppt++) {
                Arr2Int TmpC = *ppt;
                fout << "Dynamic Cube Vars: v" << TmpC[0][0] << " = ";
                for (auto ppd = TmpC.begin() + 1; ppd != TmpC.end(); ppd++) {
                    if (ppd != TmpC.begin() + 1) fout << " + ";
                    if (ppd->size() == 0) fout << "1";
                    else 
                        for (auto ppf = ppd->begin(); ppf != ppd->end(); ppf++){
                            if (ppf != ppd->begin()) fout << " * ";
                            if ((*ppf) < 640) fout << "k" << (*ppf);
                            else fout << "v" << (*ppf) - 640;
                        }
                }
                fout << endl;
            }
            fout << endl << "-------------- New Key Variables --------------" << endl;  
            fout.close();

            for (int i = 0; i < nkcount; i++)
                TempP[i].WritePolyToFile_Simple(file, "k" + to_string(128+i));
            
            cout << " OK!" << endl;
        }

        delete [] g; delete [] f; delete [] z;
        Loop += 1;
    }

    for (int pt = 0; pt < nkcount; pt++) {
        xPoly tpoly;
        for (int pd = 0; pd < TempP[pt].Size; pd++) {
            Arr1Int tt;
            for (int i = 640+128; i < 1280; i++)
                if (TempP[pt].poly[pd].pterm[i >> 5] >> (0x1f ^ (0x1f & i)) & 1)
                    tt.push_back(i-640);
            
            if (!tt.size())
                tpoly.poly[tpoly.Size++] = TempP[pt].poly[pd];
            else if (tt.size() == 1)
                tpoly.Merge(TempP[tt[0]-128]);
            else if (tt.size() == 2)
            {
                xPoly tp;
                PolyMul(tp, TempP[tt[0]-128], TempP[tt[1]-128]);
                tpoly.Merge(tp);
            }
        }
        TempP[pt] = tpoly;
    }

    for (int pt = 0; pt < nkcount; pt++) {
        Arr2Int vtpoly;
        for (int pd = 0; pd < TempP[pt].Size; pd++) {
            Arr1Int tterm;
            for (int i = 640; i < 1280; i++)
                if ((TempP[pt].poly[pd].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i - 640);
            vtpoly.push_back(tterm);
        }
        XKEYs.push_back(vtpoly);
    }
    ACTKEYLEN = XKEYs.size() + 128;

    for (auto ppt = xIv.begin(); ppt != xIv.end(); ppt++)
        for (int loc = 0; loc < (*ppt).size(); loc++){
            for (int j = 1; j < (*ppt)[loc].size(); j++){
                for (int i = 0; i < (*ppt)[loc][j].size(); i++)
                    if ((*ppt)[loc][j][i] >= 640)
                        (*ppt)[loc][j][i] = (*ppt)[loc][j][i] - 640 + ACTKEYLEN;
            }
        }
    
    for (int loc = 0; loc < 128; loc++) {
        Arr2Int tpoly;
        for (int j = 0; j < s[loc].Size; j++) {
            Arr1Int tterm;
            for (int i = 0; i < 640; i++)
                if ((s[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i + ACTKEYLEN);
            for (int i = 640; i < 1280; i++)
                if ((s[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i - 640);
            tpoly.push_back(tterm);
        }
        xS.push_back(tpoly);
    }

    for (int loc = 0; loc < 128; loc++) {
        Arr2Int tpoly;
        for (int j = 0; j < b[loc].Size; j++) {
            Arr1Int tterm;
            for (int i = 0; i < 640; i++)
                if ((b[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i + ACTKEYLEN);
            for (int i = 640; i < 1280; i++)
                if ((b[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i - 640);
            tpoly.push_back(tterm);
        }
        xS.push_back(tpoly);
    }

    for (auto ppt = CONDITIONS.begin(); ppt != CONDITIONS.end(); ppt++) {
        for (auto ppd = ppt->begin() + 1; ppd != ppt->end(); ppd++)
            for (auto ppf = ppd->begin(); ppf != ppd->end(); ppf++)
                if ((*ppf) >= 640) (*ppf) = (*ppf) - 640 + ACTKEYLEN;
    }

    delete [] s;
    delete [] b;
    delete [] TempP;
}


// For Superpoly Recovery of General Cube Attack 
void SecParaG::ParameterGenerator(IvGterm CubeFlag, Arr3Int& xS, Arr4Int& xIv, int LOOP, bool outputflag, string file, bool AEAD_FLAG) {
    
    ofstream fout;
    xPoly *s = new xPoly [128];
    xPoly *b = new xPoly [128];
    xPoly *TempP = new xPoly [LOOP * 96];
    xPoly **xpf = new xPoly* [3];
    xPoly *g, *f, *z;

    cout << "General Cube Attack" << endl;

    xS.clear();
    int kcount = 128, nkcount = 0, vcount = 96, Loop = 0;
    // string file = "NewState(" + to_string(32 * LOOP) + "R-Grain128AEAD).txt";

    while (Loop < LOOP) {
        g = new xPoly [32]; f = new xPoly [32]; z = new xPoly [32];
        if (AEAD_FLAG)
            xGrain128AEAD_32R(CubeFlag, s, b, g, f, z, Loop * 32, file, Loop == 0);
        else
            xGrain128_32R(CubeFlag, s, b, g, f, z, Loop * 32, file, Loop == 0);

        xpf[0] = g; xpf[1] = f; xpf[2] = z; xIv.push_back({});

        for (int ppt = 0; ppt < 3; ppt++) {
            for (int loc = 0; loc < 32; loc++) {
                if (xpf[ppt][loc].Size > 1) {
                    xPoly txpoly;
                    
                    int tkeynum = 0, tivnum = 0;
                    for (int j = 0; j < xpf[ppt][loc].Size; j++)
                        if (xpf[ppt][loc].poly[j].is_const())
                            tkeynum += 1;
                        else
                            tivnum += 1;
                    
                    if (tkeynum > 1) {
                        for (int j = 0; j < xpf[ppt][loc].Size; j++) {
                            if (xpf[ppt][loc].poly[j].is_const())
                                TempP[nkcount].poly[TempP[nkcount].Size++] = xpf[ppt][loc].poly[j];
                        }
                        quickSort(TempP[nkcount].poly, 0, int(TempP[nkcount].Size) - 1);

                        bool newkeyflag = true;
                        int keyloc = 128;
                        for (int pt = 0; pt < nkcount; pt++) {
                            if (TempP[nkcount] == TempP[pt]) {
                                keyloc += pt;
                                newkeyflag = false;
                                TempP[nkcount].Clear();
                                break;
                            }
                        }

                        if (newkeyflag) {
                            txpoly.poly[txpoly.Size].pterm[(kcount + 640) >> 5] |= (1 << (0x1f ^ (0x1f & (kcount + 640))));
                            txpoly.poly[txpoly.Size++].setdeg(0);
                            kcount++; nkcount++;
                        } else {
                            txpoly.poly[txpoly.Size].pterm[(keyloc + 640) >> 5] |= (1 << (0x1f ^ (0x1f & (keyloc + 640))));
                            txpoly.poly[txpoly.Size++].setdeg(0);
                        }

                    } else if (tkeynum == 1)
                        for (int j = 0; j < xpf[ppt][loc].Size; j++)
                            if (xpf[ppt][loc].poly[j].is_const())
                                txpoly.poly[txpoly.Size++] = xpf[ppt][loc].poly[j];

                    for (int j = 0; j < xpf[ppt][loc].Size; j++)
                        if (!xpf[ppt][loc].poly[j].is_const())
                            txpoly.poly[txpoly.Size++] = xpf[ppt][loc].poly[j];

                    if(txpoly.Size > 1){
                        Arr2Int tpoly = { {vcount++} };
                        for (int j = 0; j < txpoly.Size; j++)
                        {
                            Arr1Int tterm;
                            for (int i = 0; i < 1280; i++)
                                if ((txpoly.poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                                {
                                    if (i < 640)
                                        tterm.push_back(i + 640);
                                    else
                                        tterm.push_back(i - 640);
                                }
                            tpoly.push_back(tterm);
                        }

                        xPoly txpoly2(1);
                        txpoly2.poly[0].pterm[tpoly[0][0] >> 5] |= (1 << (0x1f ^ (tpoly[0][0] & 0x1f)));
                        txpoly2.poly[0].setdeg(1);
                        txpoly2.Size = 1;
                        xIv[2*Loop].push_back(tpoly);
                        xpf[ppt][loc].PolyCopy(txpoly2);
                    }
                    else
                        xpf[ppt][loc].PolyCopy(txpoly);
                }
            }
        }

        if (Loop == LOOP - 1){
            for (int i = 0, j = 96; i < 32; i++, j++){
                s[j] = f[i] + z[i];
                b[j] = g[i] + z[i];
            }
        }
        else {
            xIv.push_back({});
            for (int loc = 96, pt = 0; loc < 128; loc++, pt++) {
                s[loc] = f[pt] + z[pt];

                if (s[loc].Size > 1) {
                    Arr2Int tpoly = { {vcount++} };
                    for (int j = 0; j < s[loc].Size; j++) {
                        Arr1Int tterm;
                        for (int i = 0; i < 1280; i++)
                            if ((s[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1) {
                                if (i < 640)
                                    tterm.push_back(i + 640);
                                else
                                    tterm.push_back(i - 640);
                            }
                        tpoly.push_back(tterm);
                    }

                    xPoly txpoly(1);
                    txpoly.poly[0].pterm[tpoly[0][0] >> 5] |= (1 << (0x1f ^ (tpoly[0][0] & 0x1f)));
                    txpoly.poly[0].setdeg(1);
                    txpoly.Size = 1;
                    xIv[2 * Loop + 1].push_back(tpoly);
                    s[loc].PolyCopy(txpoly);
                }
            }

            for (int loc = 96, pt = 0; loc < 128; loc++, pt++){
                b[loc] = g[pt] + z[pt];

                if (b[loc].Size > 1) {
                    Arr2Int tpoly = { {vcount++} };
                    for (int j = 0; j < b[loc].Size; j++) {
                        Arr1Int tterm;
                        for (int i = 0; i < 1280; i++)
                            if ((b[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1) {
                                if (i < 640)
                                    tterm.push_back(i + 640);
                                else
                                    tterm.push_back(i - 640);
                            }
                        tpoly.push_back(tterm);
                    }

                    xPoly txpoly(1);
                    txpoly.poly[0].pterm[tpoly[0][0] >> 5] |= (1 << (0x1f ^ (tpoly[0][0] & 0x1f)));
                    txpoly.poly[0].setdeg(1);
                    txpoly.Size = 1;
                    xIv[2 * Loop + 1].push_back(tpoly);
                    b[loc].PolyCopy(txpoly);
                }
            }        
        }

        if (outputflag) {
            cout << "Write to file now..." << endl;
            ofstream fout;
            fout.open(file, ios_base::app);
            if (Loop == 0){
                fout << "-------------- Cube(" << CubeFlag.count() << ") --------------" << endl;
                for (int i = 0; i < CubeFlag.size(); i++)
                    if (CubeFlag.test(i))
                        fout << 'v' << i << ' ';
                fout << endl;
            }
            fout << endl << "-------------- After "<< (Loop+1)*32 <<"-Round State (updata variables) --------------" << endl << endl;
            fout.close();

            for (int pd = 0; pd < 32; pd++)
                g[pd].WritePolyToFile_Simple(file, "g" + to_string(pd));
            for (int pd = 0; pd < 32; pd++)
                f[pd].WritePolyToFile_Simple(file, "f" + to_string(pd));
            for (int pd = 0; pd < 32; pd++)
                z[pd].WritePolyToFile_Simple(file, "z" + to_string(pd));
            for (int pd = 0; pd < 128; pd++)
                s[pd].WritePolyToFile_Simple(file, "s" + to_string(pd));
            for (int pd = 0; pd < 128; pd++)
                b[pd].WritePolyToFile_Simple(file, "b" + to_string(pd));

            fout.open(file, ios_base::app);
            int co = 0;
            for (auto ppt = xIv.begin(); ppt != xIv.end(); ppt++) {
                fout << "-------------- updata variables " << co++ << " --------------" << endl;
                for (int i = 0; i < (int) (*ppt).size(); i++) {
                    fout << 'v' << (*ppt)[i][0][0] << " = ";
                    for (int j = 1; j < (*ppt)[i].size(); j++) {
                        if (j > 1)
                            fout << " + ";

                        if ((*ppt)[i][j].size() == 0)
                            fout << '1';
                        else
                            for (int k = 0; k < (*ppt)[i][j].size(); k++) {
                                if (k > 0)
                                    fout << " * ";
                                if ((*ppt)[i][j][k] < 640)
                                    fout << 'k' << (*ppt)[i][j][k];
                                if ((*ppt)[i][j][k] >= 640)
                                    fout << 'v' << (*ppt)[i][j][k] - 640;
                            }
                    }
                    fout << endl;
                }
                fout << endl << endl;
            }
            fout << "-------------- New Key Variables --------------" << endl;  
            fout.close();

            for (int i = 0; i < nkcount; i++)
                TempP[i].WritePolyToFile_Simple(file, "k" + to_string(128+i));
            cout << "Have written file" << endl;
        }

        delete [] g; delete [] f; delete [] z;
        Loop += 1;
    }

    for (int pt = 0; pt < nkcount; pt++) {
        xPoly tpoly;
        for (int pd = 0; pd < TempP[pt].Size; pd++) {
            Arr1Int tt;
            for (int i = 640+128; i < 1280; i++)
                if (TempP[pt].poly[pd].pterm[i >> 5] >> (0x1f ^ (0x1f & i)) & 1)
                    tt.push_back(i-640);
            
            if (!tt.size())
                tpoly.poly[tpoly.Size++] = TempP[pt].poly[pd];
            else if (tt.size() == 1)
                tpoly.Merge(TempP[tt[0]-128]);
            else if (tt.size() == 2)
            {
                xPoly tp;
                PolyMul(tp, TempP[tt[0]-128], TempP[tt[1]-128]);
                tpoly.Merge(tp);
            }
        }
        TempP[pt] = tpoly;
    }

    for (int pt = 0; pt < nkcount; pt++) {
        Arr2Int vtpoly;
        for (int pd = 0; pd < TempP[pt].Size; pd++) {
            Arr1Int tterm;
            for (int i = 640; i < 1280; i++)
                if ((TempP[pt].poly[pd].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i - 640);
            vtpoly.push_back(tterm);
        }
        XKEYs.push_back(vtpoly);
    }
    ACTKEYLEN = XKEYs.size() + 128;

    for (auto ppt = xIv.begin(); ppt != xIv.end(); ppt++)
        for (int loc = 0; loc < (*ppt).size(); loc++){
            for (int j = 1; j < (*ppt)[loc].size(); j++){
                for (int i = 0; i < (*ppt)[loc][j].size(); i++)
                    if ((*ppt)[loc][j][i] >= 640)
                        (*ppt)[loc][j][i] = (*ppt)[loc][j][i] - 640 + ACTKEYLEN;
            }
        }
    
    for (int loc = 0; loc < 128; loc++) {
        Arr2Int tpoly;
        for (int j = 0; j < s[loc].Size; j++) {
            Arr1Int tterm;
            for (int i = 0; i < 640; i++)
                if ((s[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i + ACTKEYLEN);
            for (int i = 640; i < 1280; i++)
                if ((s[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i - 640);
            tpoly.push_back(tterm);
        }
        xS.push_back(tpoly);
    }

    for (int loc = 0; loc < 128; loc++) {
        Arr2Int tpoly;
        for (int j = 0; j < b[loc].Size; j++) {
            Arr1Int tterm;
            for (int i = 0; i < 640; i++)
                if ((b[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i + ACTKEYLEN);
            for (int i = 640; i < 1280; i++)
                if ((b[loc].poly[j].pterm[i >> 5] >> (0x1f ^ (i&0x1f)) ) & 1)
                    tterm.push_back(i - 640);
            tpoly.push_back(tterm);
        }
        xS.push_back(tpoly);
    }

    delete [] s;
    delete [] b;
    delete [] TempP;
}


// -------------------------------------------------------------------------------
void SecParaG::xGrain128AEAD_32R(IvGterm CubeFlag, xPoly* s, xPoly* b, xPoly* g, xPoly* f, xPoly* z, int Round, string file, bool initflag, int BlockSize) {
    bool OPutInitStateFlag = false;
    bool OPutInteStateFlag = false;
    ofstream fout;

    if (initflag) {
        for (int i = 0; i < 128; i++) {
            xTerm tmp;
            tmp.pterm[(640 + i) >> 5] = (1 << (0x1f ^ ((640 + i) & 0x1f)));
            b[i].poly[0] = tmp;
            b[i].Size = 1;
        }

        for (int i = 0; i < 96; i++) {
            if (CubeFlag.test(i)) {
                xTerm tmp;
                tmp.pterm[i >> 5] = (1 << (0x1f ^ (i & 0x1f)));
                tmp.setdeg(1);
                s[i].poly[0] = tmp;
                s[i].Size = 1;
            }
        }

        xTerm tmp;
        for (int i = 96; i < 127; i++) {
            s[i].poly[0] = tmp;
            s[i].Size = 1;
        }
    }

    if (OPutInitStateFlag * initflag) {
        fout.open(file, ios_base::app);
        fout << "-------------- Initial State --------------" << endl;
        fout.close();

        for (int i = 0; i < 128; i++)
            s[i].WritePolyToFile_Simple(file, "s" + to_string(i));
        for (int i = 0; i < 128; i++)
            b[i].WritePolyToFile_Simple(file, "b" + to_string(i));
    }

    for (uint8_t r = 0; r < BlockSize; r++)
    {
        g[r] = b[0 + r] + b[26 + r] + b[56 + r] + b[91 + r] + b[96 + r] + b[3 + r] * b[67 + r] + b[11 + r] * b[13 + r]
             + b[17 + r] * b[18 + r] + b[27 + r] * b[59 + r] + b[40 + r] * b[48 + r] + b[61 + r] * b[65 + r] 
             + b[68 + r] * b[84 + r] + b[88 + r] * b[92 + r] * b[93 + r] * b[95 + r] + b[22 + r] * b[24 + r] * b[25 + r] 
             + b[70 + r] * b[78 + r] * b[82 + r];

        f[r] = s[7 + r] + s[38 + r] + s[70 + r] + s[81 + r] + s[96 + r];

        z[r] = s[0 + r] + b[12 + r] * s[8 + r] + s[13 + r] * s[20 + r] + b[95 + r] * s[42 + r] + s[60 + r] * s[79 + r] 
             + b[12 + r] * b[95 + r] * s[94 + r] + s[93 + r] + b[2 + r] + b[15 + r] + b[36 + r] + b[45 + r] + b[64 + r] + b[73 + r] + b[89 + r];
    }

    int Len = (128 - BlockSize);

    for (int pd = 0; pd < Len; pd++){
        s[pd] = s[pd + BlockSize];
        b[pd] = b[pd + BlockSize];
    }

    if (OPutInteStateFlag) {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "-------------- After " << Round + BlockSize << "-Round State --------------" << endl;
        fout.close();

        cout << "Write to file now..." << endl;
        time_t all_start = time(NULL);

        for (int pd = 0; pd < Len; pd++)
            s[pd].WritePolyToFile_Simple(file, "s" + to_string(pd));
        for (int pd = 0, pf = Len; pd < BlockSize; pd++, pf++){
            xPoly tmp = f[pd] + z[pd];
            tmp.WritePolyToFile_Simple(file, "s" + to_string(pf));
        }
        for (int pd = 0; pd < Len; pd++)
            b[pd].WritePolyToFile_Simple(file, "b" + to_string(pd));
        for (int pd = 0, pf = Len; pd < BlockSize; pd++, pf++){
            xPoly tmp = g[pd] + z[pd];
            tmp.WritePolyToFile_Simple(file, "b" + to_string(pf));
        }

        time_t all_end = time(NULL);
        cout << "Grain128AEAD Poly write time: " << (double)(all_end - all_start) << " s" << endl;
    }
}


// --------------------------------------- Grain128 ---------------------------------------
void SecParaG::xGrain128_32R(IvGterm CubeFlag, xPoly* s, xPoly* b, xPoly* g, xPoly* f, xPoly* z, int Round, string file, bool initflag, int BlockSize) {
    bool OPutInitStateFlag = false;
    bool OPutInteStateFlag = false;
    ofstream fout;

    if (initflag) {
        for (int i = 0; i < 128; i++) {
            xTerm tmp;
            tmp.pterm[(640 + i) >> 5] = (1 << (0x1f ^ ((640 + i) & 0x1f)));
            b[i].poly[0] = tmp;
            b[i].Size = 1;
        }

        for (int i = 0; i < 96; i++) {
            if (CubeFlag.test(i)) {
                xTerm tmp;
                tmp.pterm[i >> 5] = (1 << (0x1f ^ (i & 0x1f)));
                tmp.setdeg(1);
                s[i].poly[0] = tmp;
                s[i].Size = 1;
            }
        }

        xTerm tmp;
        for (int i = 96; i < 128; i++) {
            s[i].poly[0] = tmp;
            s[i].Size = 1;
        }
    }

    if (OPutInitStateFlag * initflag) {
        fout.open(file, ios_base::app);
        fout << "-------------- Initial State --------------" << endl;
        fout.close();

        for (int i = 0; i < 128; i++)
            s[i].WritePolyToFile_Simple(file, "s" + to_string(i));
        for (int i = 0; i < 128; i++)
            b[i].WritePolyToFile_Simple(file, "b" + to_string(i));
    }

    for (uint8_t r = 0; r < BlockSize; r++)
    {
        g[r] = b[0 + r] + b[26 + r] + b[56 + r] + b[91 + r] + b[96 + r] + b[3 + r] * b[67 + r] + b[11 + r] * b[13 + r]
             + b[17 + r] * b[18 + r] + b[27 + r] * b[59 + r] + b[40 + r] * b[48 + r] + b[61 + r] * b[65 + r] + b[68 + r] * b[84 + r];

        f[r] = s[7 + r] + s[38 + r] + s[70 + r] + s[81 + r] + s[96 + r];

        z[r] = s[0 + r] + s[93 + r] + b[2 + r] + b[15 + r] + b[36 + r] + b[45 + r] + b[64 + r] + b[73 + r] + b[89 + r] + b[12 + r] * s[8 + r] + s[13 + r] * s[20 + r]
             + b[95 + r] * s[42 + r] + s[60 + r] * s[79 + r] + b[12 + r] * b[95 + r] * s[95 + r];
    }

    int Len = (128 - BlockSize);

    for (int pd = 0; pd < Len; pd++){
        s[pd] = s[pd + BlockSize];
        b[pd] = b[pd + BlockSize];
    }

    if (OPutInteStateFlag) {
        ofstream fout;
        fout.open(file, ios_base::app);
        fout << "-------------- After " << Round + BlockSize << "-Round State --------------" << endl;
        fout.close();

        cout << "Write to file now..." << endl;
        time_t all_start = time(NULL);

        for (int pd = 0; pd < Len; pd++)
            s[pd].WritePolyToFile_Simple(file, "s" + to_string(pd));
        for (int pd = 0, pf = Len; pd < BlockSize; pd++, pf++){
            xPoly tmp = f[pd] + z[pd];
            tmp.WritePolyToFile_Simple(file, "s" + to_string(pf));
        }
        for (int pd = 0; pd < Len; pd++)
            b[pd].WritePolyToFile_Simple(file, "b" + to_string(pd));
        for (int pd = 0, pf = Len; pd < BlockSize; pd++, pf++){
            xPoly tmp = g[pd] + z[pd];
            tmp.WritePolyToFile_Simple(file, "b" + to_string(pf));
        }

        time_t all_end = time(NULL);
        cout << "Grain128 Poly write time: " << (double)(all_end - all_start) << " s" << endl;
    }
}
