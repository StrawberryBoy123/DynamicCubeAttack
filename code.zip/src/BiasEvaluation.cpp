#include "Grain128AEAD.h"

extern atomic<int > G_CCount, G_TimeOutTermNum, G_TestNum, G_AllNum;
atomic<bool > GBIAS_FLAG;


// -------------------------------------------------------------------------------------------
bool BiasEvaluation(int ORound, IvGterm Cube, int ModelType, int count, IvGterm DCube, bool guassflag, int guassloc, int wrongiv, bool AEAD_FLAG) {
    const int BackRound = 60;
    string ANFFile = "GExpandingANF" + to_string(BackRound) + ".txt";

    string strfile = "GReSP" + to_string(ORound) + '_' + to_string(count);
    // string strfile = "BiasEva" + to_string(ORound) + '_' + to_string(count);
    if (DCube.count()) {
        if (guassflag)
            strfile += "_RG";
        else 
            strfile += "_EG" + to_string(guassloc);
    }
    string file_str = "mkdir " + strfile;
    system(file_str.c_str());

    string aead_str;
    if (AEAD_FLAG) aead_str = "/NewState(Grain128AEAD).txt";
    else aead_str = "/NewState(Grain128).txt";

    
    string Outfile   = strfile + "/GReSP" + to_string(ORound) + '_' + to_string(count) + ".txt";
    // string Outfile   = strfile + "/BiasEva" + to_string(ORound) + '_' + to_string(count) + ".txt";
    string Parafile1 = strfile + "/ModelRequired.txt";
    string Parafile2 = strfile + aead_str;
    string FileName1 = strfile + "/TestResult.txt";
    string FileName2 = strfile + "/SuperpolyValue.txt";
    string FileName3 = "TestBalancedness.txt";


    SecParaG::MapGPoly Superpoly;
    GPoly InANF(10);
    int TRound = 0;
    string Cubestr = "";
    
    time_t s_t = time(nullptr);
    if (false)
        ExpressRecursivelyForGrain(ORound, BackRound, ANFFile, AEAD_FLAG);

    Superpoly.clear(); InANF.clear();
    int IRound = 0;

    if (false) {
        GReadANF(TRound, InANF, ANFFile);
        IRound = ORound - TRound;
    } else {
        cout << "openfile: " << Outfile << endl;
        ifstream fin; fin.open(Outfile);
        if (!fin.is_open())
            return false;

        GReadANF(TRound, InANF, Superpoly, Outfile);
        IRound = TRound;
    }
 
    SecParaG::ParameterSelection(Cube, ModelType, DCube, guassflag, guassloc, wrongiv, Parafile1, Parafile2, AEAD_FLAG);
    bool Evaflag = BiasEvaluation(Superpoly, InANF, IRound, Cube, Outfile, ModelType, DCube, guassflag, guassloc, AEAD_FLAG);
    time_t e_t = time(nullptr);

    Cubestr = "- No." + to_string(count) + " Round: " + to_string(ORound) 
            + "; RunningTime: " + to_string(e_t - s_t) + " s; Cube(" 
            + to_string(Cube.count()) + "); zvar:";

    IvGterm tmpC = Cube | DCube;
    for (int i = 0; i < 96; i++)
        if (!tmpC.test(i))
            Cubestr += " v" + to_string(i);
    if (DCube.count()) {
        Cubestr += "; dvar: ";
        for (int i = 0; i < 96; i++)
            if (DCube.test(i))
                Cubestr += " v" + to_string(i);
    }

    Superpoly.clear();
    SecParaG::ParameterClear();
    cout << "Successful !" << endl;
    return true;
}


bool BiasEvaluation(SecParaG::MapGPoly RetSuperpoly, GPoly& ANF, int IRound, IvGterm Cube, string files, int ModelType, IvGterm DCube, bool guassflag, int guassloc, bool AEAD_FLAG) {
    
    Arr3Int KeySets = { };
    
    if ((!IRound) && (!ANF.getSize()))
        return false;

    GPoly InPutANF(100000000), OutPutANF(100000000);
    GPoly UpdateFunc[4], ZR(13), TempPoly1(50 * SIZEBw), TempPoly2(50 * SIZEBw);
    GPoly Snullptr(0), updateb(30), updates(30), SAll(900);

    if (AEAD_FLAG) InvExpressInitGAEAD(ZR, updateb, updates, SAll);
    else           InvExpressInitG128( ZR, updateb, updates, SAll);
    
    UpdateFunc[0] = Snullptr;
    UpdateFunc[1] = updates;
    UpdateFunc[2] = updateb;
    UpdateFunc[3] = SAll;

    int AllThread = std::thread::hardware_concurrency();
    const int ParallelNum = 4, SingleThread = 7;   // for superpoly recovery;
    const int ParallelNum2 = 7, SingleThread2 = 4; // for evaluating degree;
    cout << "The total number of threads available to this computer: " << AllThread << endl
        << "ParallelNum = " << ParallelNum << ", SingleThread: " << SingleThread << endl;


    int pos = files.find('/');
    string mfile = files.substr(0, pos) + "/RoundLog/";
    string inst = "mkdir " + mfile;
    system(inst.c_str());
    

    int BACKROUNDBOUND = SecParaG::REDUCEROUND + 1;
    int TimeLimit = 60, MaxDeg = SecParaG::ACTKEYLEN;
    const int LEN = 6;
    const int TRound[LEN] = { 32, BACKROUNDBOUND, BACKROUNDBOUND + 2, 100, 130, 140 };
    const int Ttime[LEN]  = {  0, 240, 180, 120, 90, 60 };
    const int BackExpandNumThr = 20;
    const int BackExpandNumThr2 = 2000;
    const int RecoveryNumThr = 30;
    const int partLen = 1000;
    int SaveTermNum = 1;


    // ----------------------------------------------------------------------
    for (int pt = 0; pt < ANF.getSize(); pt++) {
        if (ANF.poly[pt].getdegk() < 0)
            OutPutANF.AddTerm(ANF.poly[pt]);
        else 
            InPutANF.AddTerm(ANF.poly[pt]);
    }

    if (OutPutANF.getSize()) {
        SecParaG::MapGPoly TmpSp; G_CCount.store(0); G_AllNum.store(OutPutANF.getSize());
        #pragma omp parallel for num_threads(ParallelNum2) schedule(dynamic, 3)
        for (int pt = 0; pt < OutPutANF.getSize(); pt++) {
            Grain128AEADEvalBDPT(TmpSp, OutPutANF.poly[pt], Cube, IRound, false, TimeLimit, SingleThread2, ModelType, DCube, AEAD_FLAG);

            if (OutPutANF.poly[pt].getdegk() > 0) {
                #pragma omp critical
                InPutANF.AddTerm(OutPutANF.poly[pt]);
            }
        }
        OutPutANF.clear();

        if (InPutANF.getSize()) {
            cout << "InPutANF = " << InPutANF.getSize() << endl;
            quickSort(InPutANF.poly, 0, int(InPutANF.getSize()) - 1);
            MaxDeg = InPutANF.poly[InPutANF.getSize() - 1].getdegk();
        }
        else 
            MaxDeg = SaveTermNum = 0;
    }

    while ((SaveTermNum <= 100000) && (SaveTermNum)) {
        int TESTFLAG = true;
        bool computeflag = true;

        time_t TimeOutStart = time(nullptr);
        while (((OutPutANF.getSize() <= RecoveryNumThr)||(TESTFLAG)) && (IRound > BACKROUNDBOUND) && (InPutANF.getSize() <= BackExpandNumThr2) ) {

            TempPoly1.clear(); TempPoly2.clear();
            computeflag = false;

            for (uint32_t pt = 0; pt < InPutANF.getSize(); pt++) {
                uint8_t flag = ((InPutANF.poly[pt].pterm[3] & 1) << 1) | (InPutANF.poly[pt].pterm[7] & 1);
                uint8_t flagweight = (InPutANF.poly[pt].pterm[3] & 1) + (InPutANF.poly[pt].pterm[7] & 1);

                for (int i = 7; i > 0; i--)
                    InPutANF.poly[pt].pterm[i] = (InPutANF.poly[pt].pterm[i] >> 1) | ((InPutANF.poly[pt].pterm[i - 1] << 31) & 0x80000000);
                InPutANF.poly[pt].pterm[0] >>= 1;
                InPutANF.poly[pt].setdeg(InPutANF.poly[pt].getdeg() - flagweight);

                if (flag) {
                    InPutANF.poly[pt].pterm[4] &= 0x7fffffff;
                    PolyMul(TempPoly2, UpdateFunc[flag], InPutANF.poly[pt]);
                }
                else
                    TempPoly1.AddTerm(InPutANF.poly[pt]);
            }
            
            for (uint32_t pt = 0; pt < OutPutANF.getSize(); pt++) {
                uint8_t flag = ((OutPutANF.poly[pt].pterm[3] & 1) << 1) | (OutPutANF.poly[pt].pterm[7] & 1);
                uint8_t flagweight = (OutPutANF.poly[pt].pterm[3] & 1) + (OutPutANF.poly[pt].pterm[7] & 1);

                for (int i = 7; i > 0; i--)
                    OutPutANF.poly[pt].pterm[i] = (OutPutANF.poly[pt].pterm[i] >> 1) | ((OutPutANF.poly[pt].pterm[i - 1] << 31) & 0x80000000);
                OutPutANF.poly[pt].pterm[0] >>= 1;
                OutPutANF.poly[pt].setdeg(OutPutANF.poly[pt].getdeg() - flagweight);

                if (flag) {
                    OutPutANF.poly[pt].pterm[4] &= 0x7fffffff;
                    PolyMul(TempPoly2, UpdateFunc[flag], OutPutANF.poly[pt]);
                }
                else
                    TempPoly2.AddTerm(OutPutANF.poly[pt]);
            }
            IRound -= 1;
            OutPutANF.clear();
            InPutANF.PolyCopy(TempPoly1);
            cout << endl << "Before Degest: OutPutANF Terms: " << TempPoly2.getSize() << ", SaveTerms: " << InPutANF.getSize() << ", IRound = " << IRound << endl;
            // ---------------------------------------------------------------
            TempPoly2.DiscardEvenCoeff();
            cout << "DegEst1(Pass DiscardEvenCoeff): OutPutANF Terms: " << TempPoly2.getSize() << ", SaveTerms: " << InPutANF.getSize() << ", IRound = " << IRound << endl;
            // ---------------------------------------------------------------

            if ( (TempPoly2.getSize() < BackExpandNumThr) && (IRound > BACKROUNDBOUND) ) {
                OutPutANF.PolyCopy(TempPoly2);
                TESTFLAG = true;
                continue;
            }
            TESTFLAG = false;


            SecParaG::MapGPoly TmpSp; G_CCount.store(0); G_AllNum.store(TempPoly2.getSize());
            #pragma omp parallel for num_threads(ParallelNum2) schedule(dynamic, 3)
            for (int pt = 0; pt < TempPoly2.getSize(); pt++) {
                if (TempPoly2.poly[pt].getdegk() <= 0)
                    Grain128AEADEvalBDPT(TmpSp, TempPoly2.poly[pt], Cube, IRound, false, TimeLimit, SingleThread2, ModelType, DCube, AEAD_FLAG);

                if (TempPoly2.poly[pt].getdegk() > 0) {
                    #pragma omp critical
                    OutPutANF.AddTerm(TempPoly2.poly[pt]);
                }
            }

            if (OutPutANF.getSize() > 0) {
                quickSort(OutPutANF.poly, int64_t(0), int64_t(OutPutANF.getSize()) - 1);
                MaxDeg = OutPutANF.poly[OutPutANF.getSize() - 1].getdegk();
            }
            else
                MaxDeg = 0;

            time_t local_time;
            struct tm *local_tm;
            char buf_tmp[64];
            time (&local_time);
            local_tm = localtime(&local_time);
            strftime(buf_tmp, 64, "%Y_%m_%d_%H_%M_%S", local_tm);
            string Date1 = buf_tmp;
            string filec1 = mfile + "TempFile(" + to_string(IRound) + "_" + Date1 + ").txt";
            OutPutANF.WriteValueToFile(IRound, filec1, "TermNum: " + to_string(OutPutANF.getSize()));
            InPutANF.WriteValueToFile(IRound, filec1, "SaveTerm: " + to_string(InPutANF.getSize()));
            RetSuperpoly.WriteValueToFile(filec1, "Recovered Superpoly");

            ofstream fo; fo.open(filec1, ios_base::app);
            fo << endl << "KeySetToZero: " << endl;
            for (auto pt = KeySets.begin(); pt != KeySets.end(); pt++){
                for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
                    fo << *pd << " ";
                fo << "; mindeg = " << (*pt)[1][0] << endl;
            }
            fo.close();

            // ------------------------------------------------------------
            cout << "DegEst2(Pass DegEst): OutPutANF Terms: " << OutPutANF.getSize() << ", SaveTerms: " << InPutANF.getSize() << ", IRound = " << IRound << endl;
            if (IRound <= BACKROUNDBOUND) {
                OutPutANF.Merge(InPutANF);
                InPutANF.clear();
                break;
            }
        }
        

        if ((InPutANF.getSize() + OutPutANF.getSize()) == 0) {
            string OutFile1 = files.substr(0, files.length() - 4) + '(' + to_string(IRound) + ").txt";
            InPutANF.WriteValueToFile(IRound, OutFile1, "Terms: " + to_string(InPutANF.getSize()), true);
            RetSuperpoly.WriteValueToFile(OutFile1, "Recovered Superpoly");

            ofstream fo; fo.open(OutFile1, ios_base::app);
            fo << endl << "KeySetToZero: " << endl;
            for (auto pt = KeySets.begin(); pt != KeySets.end(); pt++){
                for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
                    fo << *pd << " ";
                fo << "; mindeg = " << (*pt)[1][0] << endl;
            }
            fo.close();
            break;

        } else if (IRound < BACKROUNDBOUND + 1) {
            OutPutANF.Merge(InPutANF);
            InPutANF.clear();
        }
        else if ((computeflag) && (InPutANF.getSize() > 0) && (OutPutANF.getSize() == 0)) {
            OutPutANF.Merge(InPutANF);
            InPutANF.clear();
        }

        if (OutPutANF.getSize() > 0)
            quickSort(OutPutANF.poly, 0, int(OutPutANF.getSize()) - 1);
        MaxDeg = OutPutANF.poly[OutPutANF.getSize() - 1].getdegk();
        time_t TotalStartTime = time(nullptr);


        Arr1Int TermNum(MaxDeg, 0);
        for (uint32_t i = 0; i < OutPutANF.getSize(); i++)
            TermNum[OutPutANF.poly[i].getdegk() - 1] += 1;
        cout << "(deg, MonomialNumber): ";
        for (int i = 0; i < MaxDeg; i++)
            if (TermNum[i] > 0)
                cout << '(' << i << ", " << TermNum[i] << ") ";
        cout << endl;


        int AllTermNum = OutPutANF.getSize();
        G_AllNum.store(AllTermNum);

        for (int i = 0; i < LEN; i++)
            if (IRound >= TRound[i])
                TimeLimit = Ttime[i];

        // Part I: Superpoly Recovery
        for (int ppt = 0; ppt < AllTermNum; ppt += partLen) {
            int tarppt = ((ppt + partLen) >= AllTermNum) * AllTermNum + ((ppt + partLen) < AllTermNum) * (ppt + partLen);
            G_CCount.store(0); G_TimeOutTermNum.store(0); G_TestNum.store(tarppt - ppt);
            int d1 = OutPutANF.poly[ppt].getdegk(), d2 = OutPutANF.poly[tarppt - 1].getdegk();

            cout << "Start Superpoly Rrcovery!" << endl;
            // #pragma omp parallel for num_threads(6) schedule(dynamic, 1)
            #pragma omp parallel for num_threads(ParallelNum) schedule(dynamic, 1)
            for (int ppd = ppt; ppd < tarppt; ppd++) {
                Grain128AEADEvalBDPT(RetSuperpoly, OutPutANF.poly[ppd], Cube, IRound, true, TimeLimit, SingleThread, ModelType, DCube, AEAD_FLAG);

                if (OutPutANF.poly[ppd].getdegk()){
                    #pragma omp critical
                    InPutANF.AddTerm(OutPutANF.poly[ppd]);
                }
            }
            G_AllNum -= G_TestNum;

            time_t local_time;
            struct tm *local_tm;
            char buf_tmp[64];
            time (&local_time);
            local_tm = localtime(&local_time);
            strftime(buf_tmp, 64, "%Y_%m_%d_%H_%M_%S", local_tm);
            string Date = buf_tmp;
            string filec = mfile + "TempFile(" + to_string(IRound) + "_" + Date + ").txt";
            OutPutANF.WriteValueToFile(IRound, filec, to_string(tarppt) + "/" + to_string(OutPutANF.getSize()), 1, tarppt);
            InPutANF.WriteValueToFile(IRound, filec, "SaveTerm: " + to_string(InPutANF.getSize()));
            RetSuperpoly.WriteValueToFile(filec, "Recovered Superpoly");

            cout << "Round: " << IRound << ", Termdeg: " << d1 << " - " << d2 << ", The size of the Superpoly: " 
                << RetSuperpoly.size() << ", Accepted Terms: " << InPutANF.getSize() 
                << endl;
        }
        time_t TotalEndTime = time(nullptr);

        // -----------------------------------------------------------------------------------------------------
        OutPutANF.clear();
        InPutANF.DiscardEvenCoeff();
        cout << "Save Terms(Pass BDPT_MILP): " << InPutANF.getSize() << ", Rumtime: " << double(TotalEndTime - TotalStartTime) << " s" << endl;

        Arr3Int TmpKSet(InPutANF.getSize());
        #pragma omp parallel for num_threads(ParallelNum) schedule(dynamic, 1)
        for (int ppt = 0; ppt < InPutANF.getSize(); ppt++) {
            TmpKSet[ppt].push_back(DegEst(InPutANF.poly[ppt], Cube, IRound, SingleThread, ModelType, DCube, AEAD_FLAG) );
            TmpKSet[ppt].push_back( { Grain128AEADTest(InPutANF.poly[ppt], Cube, IRound, SingleThread, ModelType, DCube, AEAD_FLAG) - TmpKSet[ppt][0].size() } );
        
            #pragma omp critical
            {
                cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() 
                    << ", Have Tested Terms(" << InPutANF.poly[ppt].getdegk() << ", "
                    << TmpKSet[ppt][1][0] << "):";
                for (int i = 0; i < 8; i++)
                    cout <<  " 0x" << hex << InPutANF.poly[ppt].pterm[i];        
                cout << dec << "; SetKeyToZero:";
                for (auto pt = TmpKSet[ppt][0].begin(); pt != TmpKSet[ppt][0].end(); pt++)
                    cout << " k" << (*pt);
                if (TmpKSet[ppt][0].size() == 0)
                    cout << " false";
                
                cout << endl;
            }
        }
 
        TempPoly1 = InPutANF;

        bool TestFlag0 = true;  // true: 表示没有空集;  false: 表示存在空集
        bool TestFlag1 = true;  // true: 表示没有size小于1的集合; false: 表示存在size小于1的集合.
        // bool TestFlag3 = false;  // true: 表示有size大于等于3的集合; false: 表示不存在size大于等于3的集合.
        // Arr3Int LambdaSet = {};
        for (auto pt = TmpKSet.begin(); pt != TmpKSet.end(); pt++){
            if ((*pt)[0].size() == 0) TestFlag0 = false;
            if ((*pt)[0].size() <= 1) TestFlag1 = false;
            // if (pt->size() >= 3) TestFlag3 = true;
            
            // if (pt->size() > 1) {
            //     bool flag = true;
            //     for (auto pd = LambdaSet.begin(); pd != LambdaSet.end(); pd++){
            //         if (*pt == (*pd)[0]) { (*pd)[1][0] += 1; flag = false; break; }
            //     }
            //     if (flag)
            //         LambdaSet.push_back({*pt, { { 1 } }});
            // }
        }

        // if (TestFlag1 || ((IRound <= BACKROUNDBOUND) && TestFlag0)){
        //     // for (auto pt = TmpKSet.begin(); pt != TmpKSet.end(); pt++)
        //     //     KeySets.push_back(*pt);
        //     KeySets = TmpKSet;
        //     break;
        // }
        // else if (TestFlag0) {
        //     for (auto pt = LambdaSet.begin(); pt != LambdaSet.end(); pt++){
                
        //         cout << "Term: ";
        //         for (auto pf = (*pt)[0].begin(); pf != (*pt)[0].end(); pf++)
        //             cout << " k" << *pf;
        //         cout << "; count: " << (*pt)[1][0] << "; Set degree to 0: ";

        //         if ((*pt)[1][0] > 3) {
        //             KeySets.push_back((*pt)[0]);
        //             for (int ppt = 0; ppt < InPutANF.getSize(); ppt++) {
        //                 if (TmpKSet[ppt].size() < 2)
        //                     continue;

        //                 if ((*pt)[0] == TmpKSet[ppt]) {
        //                     OutPutANF.AddTerm(InPutANF.poly[ppt]);
        //                     InPutANF.poly[ppt].setdegk(0);
        //                     cout << ppt << " ";
        //                     continue;
        //                 }

        //                 if (TmpKSet[ppt].size() > (*pt)[0].size()) {
        //                     set<int > tmpset;
        //                     for (auto pd = TmpKSet[ppt].begin(); pd != TmpKSet[ppt].end(); pd++)
        //                         tmpset.insert(*pd);
        //                     for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
        //                         tmpset.insert(*pd);
        //                     if (tmpset.size() == TmpKSet[ppt].size()){
        //                         OutPutANF.AddTerm(InPutANF.poly[ppt]);
        //                         InPutANF.poly[ppt].setdegk(0);
        //                         cout << ppt << " ";
        //                         continue;
        //                     }
        //                 }
        //             }
        //             cout << endl;
        //         }
        //     }

        //     int ppd = 0;
        //     for (int ppt = 0; ppt < InPutANF.getSize(); ppt++){
        //         if (InPutANF.poly[ppt].getdegk() > 0)
        //             InPutANF.poly[ppd++] = InPutANF.poly[ppt];
        //     }
        //     InPutANF.setSize(ppd);
        // }
        // else if (TestFlag3) {

        //     for (auto pt = LambdaSet.begin(); pt != LambdaSet.end(); pt++) {
                
        //         cout << "Term: ";
        //         for (auto pf = (*pt)[0].begin(); pf != (*pt)[0].end(); pf++)
        //             cout << " k" << *pf;
        //         cout << "; count: " << (*pt)[1][0] << "; Set degree to 0: ";

        //         if ((*pt)[1][0] >= 3) {
        //             KeySets.push_back((*pt)[0]);
        //             for (int ppt = 0; ppt < InPutANF.getSize(); ppt++) {
        //                 if (TmpKSet[ppt].size() < 3)
        //                     continue;

        //                 if ((*pt)[0] == TmpKSet[ppt]) {
        //                     OutPutANF.AddTerm(InPutANF.poly[ppt]);
        //                     InPutANF.poly[ppt].setdegk(0);
        //                     cout << ppt << " ";
        //                     continue;
        //                 }

        //                 if (TmpKSet[ppt].size() > (*pt)[0].size()) {
        //                     set<int > tmpset;
        //                     for (auto pd = TmpKSet[ppt].begin(); pd != TmpKSet[ppt].end(); pd++)
        //                         tmpset.insert(*pd);
        //                     for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
        //                         tmpset.insert(*pd);
        //                     if (tmpset.size() == TmpKSet[ppt].size()) {
        //                         OutPutANF.AddTerm(InPutANF.poly[ppt]);
        //                         InPutANF.poly[ppt].setdegk(0);
        //                         cout << ppt << " ";
        //                         continue;
        //                     }
        //                 }
        //             }
        //             cout << endl;
        //         }
        //     }

        //     int ppd = 0;
        //     for (int ppt = 0; ppt < InPutANF.getSize(); ppt++){
        //         if (InPutANF.poly[ppt].getdegk() > 0)
        //             InPutANF.poly[ppd++] = InPutANF.poly[ppt];
        //     }
        //     InPutANF.setSize(ppd);
        // }

        string OutFile = files.substr(0, files.length() - 4) + '(' + to_string(IRound) + ").txt";
        InPutANF.WriteValueToFile(IRound, OutFile, "Terms: " + to_string(InPutANF.getSize()), true);
        RetSuperpoly.WriteValueToFile(OutFile, "Recovered Superpoly");
        OutPutANF.WriteValueToFile(IRound, OutFile, "Discarded Terms: " + to_string(OutPutANF.getSize()));
        OutPutANF.clear();
        ofstream fo; fo.open(OutFile, ios_base::app);
        int count = 0;
        for (auto pt = TmpKSet.begin(); pt != TmpKSet.end(); pt++) {
            fo << "Term " << count << ":";
            for (auto pf = (*pt)[0].begin(); pf != (*pt)[0].end(); pf++)
                fo << " k" << *pf;
            fo << " g" << count++ << "; mindeg = " << (*pt)[1][0] << endl;
        }
        fo.close();
        TempPoly1.WriteValueToFile(IRound, OutFile, "RoundSave Terms: " + to_string(TempPoly1.getSize()));
        TempPoly1.clear();
        

        // if (TestFlag1 || ((IRound <= BACKROUNDBOUND) && TestFlag0)){
        if (TestFlag0 || ((IRound <= BACKROUNDBOUND) && TestFlag0)){
            // for (auto pt = TmpKSet.begin(); pt != TmpKSet.end(); pt++)
            //     KeySets.push_back(*pt);
            KeySets = TmpKSet;
            break;
        }

        // -----------------------------------------------------------------------------------------------------
        SaveTermNum = InPutANF.getSize();
        if (SaveTermNum == 0)
            break;
        if (IRound <= BACKROUNDBOUND)
            return false;
        // -----------------------------------------------------------------------------------------------------
    }

    // SecParaG::MapGPoly RetSP;
    // RetSuperpoly.ConvertNKvarsTo128Kvars(RetSP);

    int mincount = 999;
    int maxcount = 0;

    Arr3Int MergeSet, DivSet;

    for (auto pt = KeySets.begin(); pt != KeySets.end(); pt++){
        if (mincount > (*pt)[0].size()) mincount = (*pt)[0].size();
        if (maxcount < (*pt)[0].size()) maxcount = (*pt)[0].size();

        bool flag = true;
        for (auto pd = MergeSet.begin(); pd != MergeSet.end(); pd++){
            if ((*pt)[0] == (*pd)[0]) {
                flag = false;
                if ( (*pt)[1][0] < (*pd)[1][0] )
                    (*pd)[1][0] = (*pt)[1][0];
                break;
            }
        }

        if (flag) MergeSet.push_back(*pt);
    }
    
    // for (auto pt = MergeSet.begin(); pt != MergeSet.end(); pt++)
    //     if ((*pt)[0].size() == mincount)
    //         DivSet.push_back(*pt);
    
    for (int vecsize = mincount; vecsize <= maxcount; vecsize++) {
        for (auto pt = MergeSet.begin(); pt != MergeSet.end(); pt++) {
            if ((*pt)[0].size() != vecsize) continue;

            Keyterm ptterm(0); 
            for (auto it = (*pt)[0].begin(); it != (*pt)[0].end(); it++)
                ptterm.set(*it);

            bool divflag = false;
            for (auto pd = DivSet.begin(); pd != DivSet.end(); pd++) {

                if ((*pt)[0].size() == (*pd)[0].size()) break;

                Keyterm pdterm(0);
                for (auto it = (*pd)[0].begin(); it != (*pd)[0].end(); it++)
                    pdterm.set(*it);
                
                if ((pdterm | ptterm) == ptterm) {
                    divflag = true;
                    if ( (ptterm.count() - pdterm.count() + (*pt)[1][0]) < (*pd)[1][0] )
                        (*pd)[1][0] = ptterm.count() - pdterm.count() + (*pt)[1][0];
                    break;
                }
            }

            if (!divflag)
                DivSet.push_back(*pt);
        }
    }

    fstream tmpfout; tmpfout.open("TmpTestBiasFile.txt", ios_base::app);
    tmpfout << "KeySets: " << endl;
    for (auto pt = KeySets.begin(); pt != KeySets.end(); pt++){
        for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
            tmpfout << " k" << *pd;
        tmpfout << "; " << (*pt)[1][0] << endl;
    }
    tmpfout << endl << "MergeSet: " << endl;
    for (auto pt = MergeSet.begin(); pt != MergeSet.end(); pt++){
        for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
            tmpfout << " k" << *pd;
        tmpfout << "; " << (*pt)[1][0] << endl;
    }
    tmpfout << endl << "DivSet: " << endl;
    for (auto pt = DivSet.begin(); pt != DivSet.end(); pt++){
        for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
            tmpfout << " k" << *pd;
        tmpfout << "; " << (*pt)[1][0] << endl;
    }
    tmpfout.close();



    // int mincount = 999;
    // set<Arr1Int> CoeffInt;
    // vector<Keyterm> Coeff;
    // for (auto pt = KeySets.begin(); pt != KeySets.end(); pt++){
    //     CoeffInt.insert((*pt)[0]);
    //     if (pt->size() < mincount) mincount = pt->size();    
    // }

    // cout << "All different LambdaSets: " << endl;
    // for (auto pt = CoeffInt.begin(); pt != CoeffInt.end(); pt++) {
    //     for (auto pd = pt->begin(); pd != pt->end(); pd++)
    //         cout << " k" << *pd;
    //     cout << endl;
    // }

    // for (auto pt = CoeffInt.begin(); pt != CoeffInt.end(); pt++){
    //     if (pt->size() == mincount){
    //         Keyterm Tmpterm(0);
    //         for (auto pd = pt->begin(); pd != pt->end(); pd++)
    //             Tmpterm.set(*pd);
    //         Coeff.push_back(Tmpterm);
    //     }
    // }

    // for (auto pt = CoeffInt.begin(); pt != CoeffInt.end(); pt++) {
    //     if (pt->size() > mincount){
    //         Keyterm Tmpterm(0);
    //         for (auto pd = pt->begin(); pd != pt->end(); pd++)
    //             Tmpterm.set(*pd);
    //         bool divflag = true;
    //         for (auto pd = Coeff.begin(); pd != Coeff.end(); pd++)
    //             if (((*pd) | Tmpterm) == Tmpterm){
    //                 divflag = false;
    //                 break;
    //             }
    //         if (divflag)
    //             Coeff.push_back(Tmpterm);
    //     }
    // }
    
    int tmpwrongiv = SecParaG::WrongLocation;
    SecParaG::ParameterSelection(Cube, 3, DCube, guassflag, guassloc, tmpwrongiv, "ModelRequired.txt", "NewState(Grain128AEAD).txt", AEAD_FLAG);

    // int newkey = 128;
    Arr1Int BiasSet;
    int newkey = SecParaG::ACTKEYLEN;
    for (auto ppt = DivSet.begin(); ppt != DivSet.end(); ppt++){
        SecParaG::MGTerm tmpterm;     
        for (auto pd = (*ppt)[0].begin(); pd != (*ppt)[0].end(); pd++)
            tmpterm.insert(*pd);
        tmpterm.insert(newkey++);
        BiasSet.push_back((*ppt)[1][0]);
        // RetSP.InSert(SecParaG::MapGPair(tmpterm, 1));
        RetSuperpoly.InSert(SecParaG::MapGPair(tmpterm, 1));
    }
    // cout << endl << "KeySetToZero: " << endl;
    // for (auto pt = Coeff.begin(); pt != Coeff.end(); pt++){
    //     for (int i = 0; i < 128; i++)
    //         if ((*pt).test(i))
    //             cout << i << " ";
    //     cout << endl;
    // }

    string BiasFile = files.substr(0, files.length() - 4) + "(bias_evaluation).txt";
    // double Bias1 = RetSP.TestBalanced3(BiasFile, "Bias of p with assumption(0)", true);
    // double Bias2 = RetSP.TestBalanced3(BiasFile, "Bias of p with assumption(1/4)", false);

    string BiasMessage = "pr[p=1]=2^{-n}, n:";
    for (auto pt = BiasSet.begin(); pt != BiasSet.end(); pt++)
        BiasMessage += " " + to_string(*pt);

    double Bias1 = RetSuperpoly.TestBalanced4(BiasFile, BiasSet, BiasMessage);
    // double Bias2 = RetSuperpoly.TestBalanced2(BiasFile, "Bias of p with assumption(1/4)", false);

    ofstream fo; fo.open(BiasFile, ios_base::app);
    fo << endl << "KeySetToZero: " << endl;
    for (auto pt = DivSet.begin(); pt != DivSet.end(); pt++){
        for (auto pd = (*pt)[0].begin(); pd != (*pt)[0].end(); pd++)
            fo << " k" << *pd;
        fo << "; mindeg(g) = " << (*pt)[1][0] << endl;
    }
    fo.close();

    InPutANF.WriteValueToFile(IRound, BiasFile, "Terms: " + to_string(InPutANF.getSize()));
    RetSuperpoly.WriteValueToFile(BiasFile, "Recovered Superpoly N-kvars");

    return true;
}


Arr1Int DegEst(GTerm &Pterm, IvGterm &Cube, int IRound, int ThreadNum, int ModelType, IvGterm DCube, bool AEAD_FLAG) {
       
    GRBEnv Env = GRBEnv();
    Env.set(GRB_IntParam_LogToConsole, 0);
    GRBModel Model = GRBModel(Env);

    if (ThreadNum != 0) Model.set(GRB_IntParam_Threads, ThreadNum);
    // if (TimeLimit != 0) Model.set(GRB_DoubleParam_TimeLimit, TimeLimit);

    GRBVar *kvar = Model.addVars(SecParaG::ACTKEYLEN, 'B');
    GRBVar *vvar = Model.addVars(96 , 'B');
    GRBVar *svar = Model.addVars(128, 'B');
    GRBVar *bvar = Model.addVars(128, 'B');

    GRBLinExpr key_sum;
    for (int i = 0; i < SecParaG::ACTKEYLEN; i++)
        key_sum += kvar[i];
    Model.setObjective(key_sum, GRB_MAXIMIZE);

    for (int i = 0; i < 96; i++) {
        if (Cube.test(i))        Model.addConstr(vvar[i] == 1);
        else if (!DCube.test(i)) Model.addConstr(vvar[i] == 0);
    }

    int StartRound = 0;
    if (ModelType == 0) {
        for (int i = 0; i < 96; i++)
            Model.addConstr(svar[i] == vvar[i]);

        if (AEAD_FLAG)
            Model.addConstr(svar[127] == 0);

        for (int i = 0; i < 128; i++)
            Model.addConstr(bvar[i] == kvar[i]);
    }
    else {
        StartRound = SecParaG::REDUCEROUND;
        GInitilization(Model, svar, bvar, kvar, vvar);
    }

    for (int r = StartRound; r < IRound; r++) {
        GRBVar z = funcZ(Model, bvar, svar, AEAD_FLAG);
        GRBVar *zs = Model.addVars(2, 'B');
        Model.addGenConstrOr(z, zs, 2);
        
        GRBVar f = funcF(Model, svar);
        GRBVar g = funcG(Model, bvar, AEAD_FLAG);

        GRBVar news = Model.addVar(0, 1, 0, GRB_BINARY);
        Model.addConstr(news == zs[0] + f);

        GRBVar newb = Model.addVar(0, 1, 0, GRB_BINARY);
        Model.addConstr(newb == zs[1] + g);

        for (int i = 0; i < 127; i++) {
            bvar[i] = bvar[i + 1];
            svar[i] = svar[i + 1];
        }
        bvar[127] = newb;
        svar[127] = news;
    }

    for (int pt = 0; pt < 128; pt++) {
        if ((Pterm.pterm[pt >> 5] >> (31 - (pt & 31))) & 1)
            Model.addConstr(bvar[pt] == 1);
        else
            Model.addConstr(bvar[pt] == 0);
    }

    for (int pt = 128; pt < 256; pt++) {
        if ((Pterm.pterm[pt >> 5] >> (31 - (pt & 31))) & 1)
            Model.addConstr(svar[pt - 128] == 1);
        else
            Model.addConstr(svar[pt - 128] == 0);
    }

    Model.optimize();
    Arr1Int Kset = {};
    if (Model.get(GRB_IntAttr_Status) == GRB_OPTIMAL) {
        for (int k = 0; k < 128; k++)
            if (kvar[k].get(GRB_DoubleAttr_Xn) >= 0.5)
                Kset.push_back(k);
    }

    // Arr1Int TmpKeySetTo0 = {};
    Arr1Int KeySetTo0 = {};
    for (auto pk = Kset.begin(); pk != Kset.end(); pk++) {
        GRBConstr TmpConstr = Model.addConstr(kvar[*pk] == 0);
        
        Model.update();
        Model.optimize();
        
        if (Model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE)
            KeySetTo0.push_back(*pk);
        Model.remove(TmpConstr);
    }

    // Arr2Int KeySetTo0 = {};
    // if (TmpKeySetTo0.size() == 0){
    //     GBIAS_FLAG.store(true);
    // }
    // else if (TmpKeySetTo0.size() > TargetFlag) {
    //     KeySetTo0.push_back(TmpKeySetTo0);
    // }
    // else if (TmpKeySetTo0.size() == TargetFlag) {
    //     GRBConstr TmpConstr0 = Model.addConstr(kvar[TmpKeySetTo0[0]] == 1);

    //     for (int keyloc = 127; keyloc >= 0; keyloc--){
    //         if (keyloc == TmpKeySetTo0[0]) continue;
    //         GRBConstr TmpConstr1 = Model.addConstr(kvar[keyloc] == 0);
            
    //         for (auto pt = Kset.begin(); pt != Kset.end(); pt++) {
    //             if ((*pt >= keyloc) || (*pt == TmpKeySetTo0[0]))
    //                 continue;
                
    //             GRBConstr TmpConstr2 = Model.addConstr(kvar[*pt] == 0);

    //             Model.update();
    //             Model.optimize();
        
    //             if (Model.get(GRB_IntAttr_Status) == GRB_INFEASIBLE){
    //                 KeySetTo0.push_back({TmpKeySetTo0[0], *pt});
    //                 KeySetTo0.push_back({TmpKeySetTo0[0], keyloc});
    //             }
    //             Model.remove(TmpConstr2);

    //             if ((KeySetTo0.size() > 1) || (GBIAS_FLAG == true))
    //                 break;
    //         }
    //         Model.remove(TmpConstr1);
    //         if ((KeySetTo0.size() > 1) || (GBIAS_FLAG == true))
    //             break;
    //     }
    // }
       
    // #pragma omp critical
    // {
    //     cout << "Round: " << IRound << ", ThreadId: " << omp_get_thread_num() 
    //         << ", Have Tested Terms(" << Pterm.getdegk() << "):";
    //     for (int i = 0; i < 8; i++)
    //         cout <<  " 0x" << hex << Pterm.pterm[i];        
    //     cout << dec << "; SetKeyToZero:";
    //     for (auto pt = KeySetTo0.begin(); pt != KeySetTo0.end(); pt++)
    //         cout << " k" << (*pt);
    //     if (KeySetTo0.size() == 0)
    //         cout << " false";
        
    //     // if (KeySetTo0.size() == 0){
    //     //     cout << "(false)";
    //     //     for (auto pt = TmpKeySetTo0.begin(); pt != TmpKeySetTo0.end(); pt++)
    //     //         cout << " k" << *pt;
    //     //     cout << ", ";
    //     // }
    //     cout << endl;
    // }

    // if ((KeySetTo0.size() < 1) || (KeySetTo0[0].size() <= 1))
    //     KeySetTo0.clear();

    return KeySetTo0;
}